<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US" sourcelanguage="es_ES">
<context>
    <name>GeoMineralAI</name>
    <message>
        <source>Análisis avanzado de prospectividad · ASTER</source>
        <translation>Advanced prospectivity analysis · ASTER</translation>
    </message>
    <message>
        <source>Ayuda</source>
        <translation>Help</translation>
    </message>
    <message>
        <source>Anterior</source>
        <translation>Back</translation>
    </message>
    <message>
        <source>Siguiente</source>
        <translation>Next</translation>
    </message>
    <message>
        <source>Ejecutar</source>
        <translation>Run</translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation>Cancel</translation>
    </message>
    <message>
        <source>Registro</source>
        <translation>Log</translation>
    </message>
    <message>
        <source>Listo</source>
        <translation>Ready</translation>
    </message>
    <message>
        <source>Proyecto</source>
        <translation>Project</translation>
    </message>
    <message>
        <source>sin guardar</source>
        <translation>unsaved</translation>
    </message>
    <message>
        <source>Tema claro</source>
        <translation>Light theme</translation>
    </message>
    <message>
        <source>Tema oscuro</source>
        <translation>Dark theme</translation>
    </message>
    <message>
        <source>Modo compacto</source>
        <translation>Compact mode</translation>
    </message>
    <message>
        <source>Idioma</source>
        <translation>Language</translation>
    </message>
    <message>
        <source>Configuración</source>
        <translation>Setup</translation>
    </message>
    <message>
        <source>Normalizar</source>
        <translation>Normalize</translation>
    </message>
    <message>
        <source>Stack</source>
        <translation>Stack</translation>
    </message>
    <message>
        <source>K-Means</source>
        <translation>K-Means</translation>
    </message>
    <message>
        <source>Fav. mineral</source>
        <translation>Mineral fav.</translation>
    </message>
    <message>
        <source>Prosp. integrada</source>
        <translation>Integrated prosp.</translation>
    </message>
    <message>
        <source>Targets</source>
        <translation>Targets</translation>
    </message>
    <message>
        <source>Validación</source>
        <translation>Validation</translation>
    </message>
    <message>
        <source>Reportes</source>
        <translation>Reports</translation>
    </message>
    <message>
        <source>Imagen ASTER, radiometría, área de estudio y capas auxiliares</source>
        <translation>ASTER image, radiometry, study area and auxiliary layers</translation>
    </message>
    <message>
        <source>Cálculo de índices minerales y normalización a 0–1</source>
        <translation>Mineral index calculation and 0–1 normalization</translation>
    </message>
    <message>
        <source>Selección y orden de bandas para el análisis multivariado</source>
        <translation>Band selection and order for multivariate analysis</translation>
    </message>
    <message>
        <source>Clasificación no supervisada del stack de índices</source>
        <translation>Unsupervised classification of the index stack</translation>
    </message>
    <message>
        <source>Suma ponderada de índices según el modelo de depósito</source>
        <translation>Weighted sum of indices by deposit model</translation>
    </message>
    <message>
        <source>Integración de evidencia mineral y estructural</source>
        <translation>Integration of mineral and structural evidence</translation>
    </message>
    <message>
        <source>Zonas de alta prospectividad clasificadas por prioridad</source>
        <translation>High-prospectivity zones ranked by priority</translation>
    </message>
    <message>
        <source>Contraste de targets con ocurrencias conocidas</source>
        <translation>Targets checked against known occurrences</translation>
    </message>
    <message>
        <source>Reporte técnico PDF/HTML y exportaciones</source>
        <translation>Technical PDF/HTML report and exports</translation>
    </message>
    <message>
        <source>Validar configuración</source>
        <translation>Check setup</translation>
    </message>
    <message>
        <source>Calcular índices</source>
        <translation>Compute indices</translation>
    </message>
    <message>
        <source>Crear stack</source>
        <translation>Build stack</translation>
    </message>
    <message>
        <source>Ejecutar K-Means</source>
        <translation>Run K-Means</translation>
    </message>
    <message>
        <source>Calcular favorabilidad</source>
        <translation>Compute favorability</translation>
    </message>
    <message>
        <source>Calcular prospectividad</source>
        <translation>Compute prospectivity</translation>
    </message>
    <message>
        <source>Generar targets</source>
        <translation>Generate targets</translation>
    </message>
    <message>
        <source>Validar targets</source>
        <translation>Validate targets</translation>
    </message>
    <message>
        <source>Generar PDF</source>
        <translation>Generate PDF</translation>
    </message>
    <message>
        <source>Autodetectar capas ASTER</source>
        <translation>Auto-detect ASTER layers</translation>
    </message>
    <message>
        <source>Añadir archivo…</source>
        <translation>Add file…</translation>
    </message>
    <message>
        <source>Examinar…</source>
        <translation>Browse…</translation>
    </message>
    <message>
        <source>Guardar configuración</source>
        <translation>Save setup</translation>
    </message>
    <message>
        <source>Cargar configuración</source>
        <translation>Load setup</translation>
    </message>
    <message>
        <source>Acercar al target</source>
        <translation>Zoom to target</translation>
    </message>
    <message>
        <source>Exportar CSV</source>
        <translation>Export CSV</translation>
    </message>
    <message>
        <source>Abrir carpeta</source>
        <translation>Open folder</translation>
    </message>
    <message>
        <source>Exportar HTML</source>
        <translation>Export HTML</translation>
    </message>
    <message>
        <source>Proyecto y salida</source>
        <translation>Project and output</translation>
    </message>
    <message>
        <source>Nombre del proyecto</source>
        <translation>Project name</translation>
    </message>
    <message>
        <source>Analista</source>
        <translation>Analyst</translation>
    </message>
    <message>
        <source>Carpeta de salida</source>
        <translation>Output folder</translation>
    </message>
    <message>
        <source>Bandas ASTER</source>
        <translation>ASTER bands</translation>
    </message>
    <message>
        <source>Radiometría</source>
        <translation>Radiometry</translation>
    </message>
    <message>
        <source>Área de estudio y auxiliares</source>
        <translation>Study area and auxiliary data</translation>
    </message>
    <message>
        <source>Máscaras</source>
        <translation>Masks</translation>
    </message>
    <message>
        <source>Índices</source>
        <translation>Indices</translation>
    </message>
    <message>
        <source>Normalización</source>
        <translation>Normalization</translation>
    </message>
    <message>
        <source>Vista previa del histograma</source>
        <translation>Histogram preview</translation>
    </message>
    <message>
        <source>Parámetros</source>
        <translation>Parameters</translation>
    </message>
    <message>
        <source>Distribución de clusters</source>
        <translation>Cluster distribution</translation>
    </message>
    <message>
        <source>Resumen</source>
        <translation>Summary</translation>
    </message>
    <message>
        <source>Evidencias</source>
        <translation>Evidence</translation>
    </message>
    <message>
        <source>Matriz de confusión</source>
        <translation>Confusion matrix</translation>
    </message>
    <message>
        <source>Secciones del reporte</source>
        <translation>Report sections</translation>
    </message>
    <message>
        <source>Plantilla</source>
        <translation>Template</translation>
    </message>
    <message>
        <source>Recomendaciones</source>
        <translation>Recommendations</translation>
    </message>
    <message>
        <source>Resultados</source>
        <translation>Results</translation>
    </message>
</context>
</TS>
