# -*- coding: utf-8 -*-
"""
GeoMineral AI v2 — clase del plugin (registro de acción, menú y barra de herramientas).

Cambios frente a v1:
  * Carga diferida: nada pesado (numpy/scipy/sklearn/GDAL) se importa al iniciar QGIS.
    En v1, main.py importaba analysis_engine, que hacía `from sklearn.cluster import KMeans`
    a nivel de módulo: sin scikit-learn el plugin entero fallaba al cargar.
  * Una sola acción ("GeoMineral AI"); el dock heredado se integró en los 9 pasos.
  * Errores de importación mostrados con causa y solución, no un traceback crudo.
"""
import os
import traceback

from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QMessageBox
from qgis.core import QgsSettings, QgsMessageLog

from .compat import QAction, msg_level
from . import i18n

MENU = '&GeoMineral AI'


class MineralExplorationAI(object):
    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(os.path.abspath(__file__))
        self.action = None
        self.dlg = None
        lang = QgsSettings().value('GeoMineralAI/language', '')
        if not lang:
            loc = QgsSettings().value('locale/userLocale', 'es') or 'es'
            lang = 'en' if str(loc).lower().startswith('en') else 'es'
        i18n.set_language(lang, self.plugin_dir)

    def initGui(self):  # noqa: N802
        svg = os.path.join(self.plugin_dir, 'icon.svg')
        icon = QIcon(svg if os.path.exists(svg) else os.path.join(self.plugin_dir, 'icon.png'))
        self.action = QAction(icon, 'GeoMineral AI', self.iface.mainWindow())
        self.action.setObjectName('GeoMineralAI_open')
        self.action.setStatusTip(i18n.tr('Análisis avanzado de prospectividad · ASTER'))
        self.action.setWhatsThis('ASTER · K-Means · prospectividad · targets · validación · PDF')
        self.action.triggered.connect(self.run)
        self.iface.addRasterToolBarIcon(self.action)
        self.iface.addPluginToRasterMenu(MENU, self.action)

    def unload(self):
        if self.dlg is not None:
            self.dlg.close()              # closeEvent cancela y espera al hilo de trabajo
            self.dlg.deleteLater()
            self.dlg = None
        if self.action is not None:
            self.iface.removePluginRasterMenu(MENU, self.action)
            self.iface.removeRasterToolBarIcon(self.action)
            self.action.deleteLater()
            self.action = None

    def _missing_deps(self):
        missing = []
        for mod, hint in (('numpy', 'numpy'), ('scipy', 'scipy'), ('osgeo.gdal', 'GDAL')):
            try:
                __import__(mod)
            except Exception:
                missing.append(hint)
        return missing

    def run(self):
        missing = self._missing_deps()
        if missing:
            QMessageBox.critical(
                self.iface.mainWindow(), 'GeoMineral AI',
                'Faltan dependencias de Python: %s.\n\nEn Windows (OSGeo4W Shell):\n'
                '    python -m pip install %s\n\nVer README.md → Requisitos.'
                % (', '.join(missing), ' '.join(m.lower() for m in missing)))
            return
        if self.dlg is None:
            try:
                from .ui.dialog import GeoMineralDialog
                self.dlg = GeoMineralDialog(self.iface, self.plugin_dir, self.iface.mainWindow())
                self.dlg.rebuild_requested.connect(self._rebuild)
            except Exception as e:     # noqa: BLE001
                tb = traceback.format_exc()
                QgsMessageLog.logMessage(tb, 'GeoMineral AI', msg_level('Critical'))
                QMessageBox.critical(self.iface.mainWindow(), 'GeoMineral AI',
                                     'No se pudo abrir la interfaz:\n%s\n\nDetalle en Registro de '
                                     'mensajes → GeoMineral AI.' % e)
                self.dlg = None
                return
        self.dlg.show()
        self.dlg.raise_()
        self.dlg.activateWindow()

    def _rebuild(self):
        """Reconstruye la ventana tras cambiar el idioma."""
        if self.dlg is not None:
            self.dlg.close()
            self.dlg.deleteLater()
            self.dlg = None
        i18n.set_language(QgsSettings().value('GeoMineralAI/language', 'es'), self.plugin_dir)
        self.run()
