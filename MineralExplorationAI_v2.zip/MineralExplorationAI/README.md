# GeoMineral AI v2.0 (MineralExplorationAI)

Plugin de QGIS para mapear alteración hidrotermal con imágenes **ASTER** (VNIR/SWIR/TIR) y
generar targets de exploración: índices minerales, K-Means, favorabilidad mineral,
prospectividad integrada con evidencia estructural, targets priorizados, validación
estadística y reporte PDF.

Spatial Mind S.R.L. — M.Sc. Edwin Calle Condori.

## Requisitos

| Componente | Versión | Nota |
|---|---|---|
| QGIS | 3.22 – 4.x | Qt5 (PyQt 5.15) y Qt6 (PyQt6), GDAL 3.4–3.12, NumPy 1.x y 2.x |
| numpy, scipy, GDAL | incluidos en QGIS | obligatorios |
| scikit-learn | opcional | K-Means; sin él se usa una implementación NumPy equivalente |
| earthengine-api | opcional | solo para descargar ASTER L1T desde Google Earth Engine |

ReportLab, matplotlib y pandas **ya no son necesarios** (el PDF se genera con Qt).

## Instalación

### Opción A: desde ZIP (recomendada)

1. QGIS → **Complementos → Administrar e instalar complementos… → Instalar a partir de ZIP**.
2. Seleccione `MineralExplorationAI_v2.zip` → **Instalar complemento**.
3. Si tenía la versión 1 instalada, QGIS la reemplaza (misma carpeta `MineralExplorationAI`).
   Reinicie QGIS si el plugin antiguo estaba cargado.
4. Verifique: menú **Ráster → GeoMineral AI**, o el icono de la gema en la barra ráster.

### Opción B: generar el ZIP desde la carpeta

```
cd D:\SPATIALMIND_AI\codigo_geoia\MineralExplorationAI
python crear_zip.py        # crea ..\MineralExplorationAI_v2.zip
```

### Opción C: manual

```
# Windows: abrir "OSGeo4W Shell" (usa el Python de QGIS)
cd ruta\donde\descomprimio\MineralExplorationAI
python install.py            # perfil 'default' de QGIS 3
python install.py --qgis4    # QGIS 4
python install.py --check    # solo verificar dependencias
```

Carpetas de plugins por sistema:

- Windows: `%APPDATA%\QGIS\QGIS3\profiles\default\python\plugins\`
- macOS: `~/Library/Application Support/QGIS/QGIS3/profiles/default/python/plugins/`
- Linux: `~/.local/share/QGIS/QGIS3/profiles/default/python/plugins/`

Dependencias opcionales (OSGeo4W Shell): `python -m pip install scikit-learn earthengine-api`

## Compatibilidad QGIS 3 / QGIS 4

Todo el código usa APIs válidas en ambas generaciones y `compat.py` resuelve las
diferencias en tiempo de ejecución:

| Diferencia | QGIS 3.22–3.40 (Qt5) | QGIS 4.x (Qt6) | Solución |
|---|---|---|---|
| Enums Qt | `Qt.AlignCenter` o con alcance | solo con alcance | Siempre con alcance (`Qt.AlignmentFlag.AlignCenter`) |
| `QAction`, `QShortcut` | QtWidgets | QtGui | `compat.QAction`, `compat.QShortcut` |
| `exec_()`, `print_()` | existen | eliminados | `exec()` / `print()` con respaldo |
| Tipo de capa | `QgsMapLayerType` (≤ 3.28), `Qgis.LayerType` (≥ 3.30) | `Qgis.LayerType` | `compat.is_raster()` |
| Filtros de capa | `QgsMapLayerProxyModel.Filter` | `Qgis.LayerFilter` | `compat.RASTER`, `POINT`… |
| Rampas de color | `QgsColorRampShader.Type` | `Qgis.ShaderInterpolationMethod` | `compat.ramp_type()` |
| Error de escritura vectorial | `QgsVectorFileWriter.NoError` | enum reubicado | `compat.writer_ok()` (por nombre) |
| Márgenes PDF | `setPageMargins(l,t,r,b,unit)` | `setPageMargins(QMarginsF, unit)` | `setPageLayout(QPageLayout)` en ambos |
| Driver OGR en memoria | `Memory` | `MEM` (GDAL ≥ 3.11) | detección automática |
| NumPy | 1.x | 2.x | sin APIs retiradas |

`metadata.txt` declara `qgisMinimumVersion=3.22`, `qgisMaximumVersion=4.99` y
`supportsQt6=True`, que QGIS 4 exige para habilitar el plugin.

## Flujo de trabajo (9 pasos)

| Paso | Qué hace | Salida |
|---|---|---|
| 1 Configuración | Asigna bandas ASTER (autodetección), radiometría, AOI, DEM, ocurrencias, máscaras | grilla de trabajo |
| 2 Normalizar | Calcula índices (división segura, float32, TIR 90→30 m) y los normaliza a 0–1 | `indices/idx_*.tif`, `normalizados/norm_*.tif` |
| 3 Stack | Selección y orden de bandas (arrastrar y soltar) | `Stack_ML.tif` |
| 4 K-Means | Clusters con interpretación por firma espectral | `Clusters_KMeans.tif` |
| 5 Fav. mineral | Suma ponderada según modelo (AS, BS, pórfido o personalizado) | `Favorabilidad_Mineral.tif` |
| 6 Prosp. integrada | Mineral + densidad de lineamientos del DEM + otras evidencias | `Prospectividad_Integrada.tif`, `Favorabilidad_Estructural.tif`, `Pendiente_grados.tif` |
| 7 Targets | Umbral, área mínima, estadísticas zonales, prioridad 1/2/3 | `targets/Targets.gpkg/.shp/.geojson` |
| 8 Validación | Aciertos, matriz de confusión, OA, Kappa, F1, ganancia | tabla en pantalla y reporte |
| 9 Reportes | PDF/HTML con mapas, tablas y recomendaciones; CSV | `reportes/*.pdf`, `*.html` |

Atajos: **Ctrl+R** ejecutar paso · **Ctrl+S / Ctrl+O** guardar/cargar configuración
(`.geominer`) · **Alt+←/→** navegar · **Ctrl+L** registro · **F1** ayuda del paso.

### Datos de entrada recomendados

- **AST_07XT** (reflectancia con corrección de crosstalk) para SWIR; **AST_05** o L1T en
  radiancia para TIR. Con L1T en DN active *Calibrar a → Radiancia*.
- Escenas **anteriores a abril de 2008**: el SWIR de ASTER falló después (el plugin avisa).
- Puede usar un stack de 14/19 bandas (p.ej. el GEE de v1), archivos VNIR/SWIR/TIR separados
  o subdatasets HDF: *Autodetectar capas ASTER* los reconoce.

## Verificación rápida tras instalar

1. Abra GeoMineral AI. Debe ver la cabecera, la barra lateral con 9 pasos y el pie con
   el botón ámbar *Validar configuración*.
2. Opcional: genere la escena sintética de prueba en la Consola de Python de QGIS:
   ```python
   from MineralExplorationAI.tests import synthetic
   p = synthetic.make_scene(r'C:\temp\gmai_demo')
   for k in ('vnir', 'swir', 'tir', 'dem'): iface.addRasterLayer(p[k], k)
   iface.addVectorLayer(p['occ'], 'ocurrencias', 'ogr')
   ```
3. Paso 1: *Autodetectar* (14/14 bandas), DEM = `dem`, Ocurrencias = `ocurrencias`.
   Ejecute Ctrl+R en cada paso (en el paso 7 use umbral 0.55). Resultado esperado: el target
   principal TGT_001, de unas 195 ha y máximo ≈ 0.79, sobre el sistema de alta sulfuración
   controlado por la falla N-S, que contiene Mina_1 y Mina_2.

## Pruebas automatizadas

```
python tests/test_core.py                              # núcleo: 48 pruebas (sin QGIS)
QT_QPA_PLATFORM=offscreen python tests/test_ui.py      # UI completa dentro de QGIS 3 o 4
QT_QPA_PLATFORM=offscreen python tests/test_qt6.py     # Qt6 real + API QGIS 4 simulada
```

`test_qt6.py` necesita `pip install PyQt6` en un entorno de pruebas, **no** en el Python de
QGIS 3. Ejecuta los 9 pasos sobre PyQt6 con una simulación estricta de la API de QGIS 4
(`tests/qt6sim/`). La validación definitiva es `test_ui.py` dentro de QGIS 4.

## Estructura

```
MineralExplorationAI/
├── __init__.py, main.py, metadata.txt, compat.py, i18n.py, icon.svg
├── install.py, crear_zip.py, requirements.txt, README.md, CHANGELOG.md
├── core/          # cálculo puro (sin Qt): aster, indices, raster_io, normalize, kmeans,
│                  # structural, prospectivity, targets, validation, advisor, report, gee
├── ui/            # dialog (dashboard), pages_data/model/results, widgets, layers, theme, icons, worker
├── resources/     # styles/geomineral.qss, compact.qss
├── i18n/          # GeoMineralAI_en.ts (+ .qm compilado en el ZIP)
├── tests/         # synthetic.py, test_core.py, test_ui.py, test_qt6.py, qt6sim/
└── docs/          # DIAGNOSTICO.md, INDICES.md, UI_MOCKUPS.md, screenshots/ (en el ZIP)
```

## Solución de problemas

| Síntoma | Causa / solución |
|---|---|
| "Faltan dependencias: scipy" | `python -m pip install scipy` en OSGeo4W Shell |
| Índices SWIR planos o ruidosos | Escena posterior a 2008 o sin corrección de crosstalk: use AST_07XT pre-2008 |
| Banda no aparece en los combos | La capa debe ser GDAL (archivo). Para HDF, añada cada subdataset desde el Administrador de fuentes |
| Ningún target | Baje el umbral o el área mínima (el paso 7 indica el % de área sobre el umbral) |
| Error inesperado | Ver → Paneles → Registro de mensajes → pestaña *GeoMineral AI* (traceback completo) |

## Limitaciones

Los índices por cociente son semicuantitativos: confirme con espectrometría de campo
(ASD/TerraSpec) y DRX. Los pesos de los modelos son de criterio experto y deben calibrarse
con ocurrencias locales. Los puntos de fondo de la validación son pseudo-negativos.
