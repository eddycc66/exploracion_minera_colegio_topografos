# Índices minerales ASTER en GeoMineral AI v2

## Convenciones

- Todos los índices **crecen con la abundancia del mineral**: la banda de absorción va en el
  denominador y los hombros en el numerador.
- División segura: `sdiv(a, b)` = NaN si `|b| < 1e-6` o si hay NaN/Inf. No se suma épsilon.
- Cálculo en float32 sobre una grilla común de 30 m. VNIR 15 m → 30 m por promedio;
  TIR 90 m → 30 m bilineal; NoData unificado antes de remuestrear.
- Se recomienda reflectancia (AST_07XT) para VNIR/SWIR y radiancia o emisividad para TIR.
  Con DN, active la calibración: `L = (DN − 1)·UCC` (ASTER User Handbook v2) y, si se
  desea, `ρ = π·L·d² / (ESUN·cos θs)`.

Centros de banda (µm): B1 0.556 · B2 0.661 · B3N 0.807 · B4 1.656 · B5 2.167 · B6 2.209 ·
B7 2.262 · B8 2.336 · B9 2.400 · B10 8.29 · B11 8.63 · B12 9.08 · B13 10.66 · B14 11.32.

## Antes y después

| Objetivo | v1 / tabla del encargo | v2 | Justificación |
|---|---|---|---|
| Alunita | B7/B5 | **ALI = (B7/B5)·(B7/B8)** | Alunita: Al–OH a 2.165 µm (B5) + rasgo a ~2.32 µm (B8). El factor B7/B8 suprime minerales que solo absorben en B5 |
| Argílica avanzada | — | **RBD5 = (B4+B6)/(2·B5)** | Profundidad de banda a 2.17 µm: ensamble alunita + caolinita + pirofilita |
| Caolinita | B6/B5 (código), B5/B6 (tabla) | **KLI = (B4/B5)·(B8/B6)** | Doblete a 2.165 y 2.205 µm: absorbe en B5 y B6. B6/B5 ≈ 1 y B5/B6 es la fórmula de sericita |
| Sericita/illita | B5/B6 | **RBD6 = (B5+B7)/(2·B6)** | Absorción a ~2.20 µm (B6) entre dos hombros. Con uno solo (B5), la caolinita contamina |
| Minerales OH | — | OHI = (B7/B6)·(B4/B6) *(opcional)* | Absorción centrada en B6 |
| "Halos OH" / Mg–OH, CO₃ | (B6+B9)/(2·B8) | **RBD8 = (B7+B9)/(2·B8)** | Absorción a 2.33 µm con hombros B7 y B9. B6 no es hombro de B8 y la illita absorbe en B6 |
| Propilítica | B4/B5 | **(B6+B9)/(B7+B8)** | Clorita: Fe–OH 2.25 µm (B7) y Mg–OH 2.33 µm (B8); epidota 2.34 µm. B4/B5 detecta alunita |
| Clorita (propuesta) | (B7+B8)/B6 | *rechazada* | Crece cuando B6 absorbe (sericita) y decrece con clorita. Es la inversa de lo buscado |
| Calcita (SWIR) | — | CLI = (B6/B8)·(B9/B8) *(opcional)* | Absorción CO₃ a 2.33–2.34 µm |
| Óxidos Fe³⁺ | B2/B1 | **B2/B1** (se mantiene) | Transferencia de carga Fe³⁺ bajo 0.55 µm |
| Fe²⁺ | — | (B5/B3)+(B1/B2) *(opcional)* | Absorción ancha del Fe²⁺ en ~0.9–1.1 µm |
| Gossan | — | B4/B2 *(opcional)* | Óxidos con alta reflectancia en 1.65 µm |
| Cuarzo | (B13/B12)+(B13/B14) | **QI = B11²/(B10·B12)** | Doblete Reststrahlen del cuarzo en 8.3 (B10) y 9.1 µm (B12) con B11 entre ambos |
| SiO₂ | idem | **B13/B10** | La emisividad a 8.3 µm cae con el SiO₂ y a 10.6 µm se mantiene |
| Carbonatos (TIR) | (B13+B11)/(2·B12) | **CI = B13/B14** | Mínimo de emisividad de calcita/dolomita a ~11.3 µm (B14). B12 es mínimo del cuarzo |
| Máfico | — | MI = B12·B14³/B13⁴ *(opcional)* | Rocas pobres en SiO₂ |
| Vegetación | — | NDVI (máscara) | Excluye píxeles con NDVI > umbral |

## Falsos positivos por índice

| Índice | Falsos positivos típicos | Mitigación en el plugin |
|---|---|---|
| ALI, RBD5 | caolinita supergénica, dickita, pirofilita, jarosita | Combinar con QI/SiO₂ en el modelo AS; validación en campo |
| KLI | alunita, halloysita; suelos caoliníticos | Máscara NDVI; interpretación K-Means por firma |
| RBD6 | montmorillonita/esmectita; arcillas de suelos | Usar con QI/B2/B1 en el modelo BS |
| RBD8, clorita | calizas y mármoles, rocas máficas frescas | Contrastar con CI (TIR) y MI |
| B2/B1 | suelos rojos, lateritas, capas rojas | Peso moderado (0.15) |
| QI, B13/B10 | arenas cuarzosas, cuarcitas, chert, aluviales | Área mínima de target; revisión geológica |
| CI | suelos calcáreos | — |
| Todos | vegetación, sombras, nubes, píxeles saturados o casi nulos | NDVI, percentil de albedo, DN 0, división segura, normalización por percentiles |

## Validación con escena sintética (`tests/test_core.py`)

Cada zona deprime **solo** las bandas de absorción de su mineral (ruido 1 %, bordes DN = 0,
un píxel saturado y otro con B5 ≈ 0). Valor = media en la zona / media del fondo:

```
                alunita  caolinita   sericita    clorita        fe3     cuarzo  carbonato
alunita           1.903      1.432      1.000      0.914      1.000      1.000      0.999
aaa_rbd5          1.616      1.230      0.824      1.000      0.999      1.000      1.000
caolinita         1.374      1.992      1.541      0.700      1.000      1.001      1.001
sericita          0.810      1.181      1.543      0.900      1.001      1.000      1.000
clorita           1.081      0.859      0.824      1.334      0.999      0.999      1.000
mgoh_co3          1.177      0.999      1.000      1.287      1.000      1.000      0.999
fe3               1.000      1.000      0.999      0.999      1.825      0.999      0.999
cuarzo            0.999      0.997      0.997      0.999      0.997      1.516      0.998
silice            1.000      0.999      1.000      1.000      0.999      1.248      1.000
carbonatos        1.001      1.000      1.001      1.000      1.000      1.000      1.177
```

- Todos los índices tienen su máximo en su zona objetivo.
- KLI separa caolinita de sericita con una razón de 1.29.
- Fórmulas v1 confirmadas como erróneas:
  - B4/B5 alcanza su máximo en la zona de **alunita**, no en la de clorita.
  - (B13+B11)/(2·B12) alcanza su máximo en la zona de **cuarzo**, no en la de carbonato.
  - (B13/B12)+(B13/B14) sube ×1.088 sobre carbonatos.
- RBD8 también responde en la zona de alunita (×1.18) por su rasgo a 2.32 µm. Es esperable y
  por eso ALI usa B7/B8.

## Referencias

- Abrams, M., Hook, S. & Ramachandran, B. (2002). *ASTER User Handbook v2*. JPL/NASA.
- Corbett, G.J. & Leach, T.M. (1998). *Southwest Pacific Rim Gold-Copper Systems*. SEG Spec. Publ. 6.
- Hedenquist, J.W., Arribas, A. & Gonzalez-Urien, E. (2000). Exploration for epithermal gold deposits. *Rev. Econ. Geol.* 13.
- Kalinowski, A. & Oliver, S. (2004). *ASTER Mineral Index Processing Manual*. Geoscience Australia.
- Landis, J.R. & Koch, G.G. (1977). The measurement of observer agreement for categorical data. *Biometrics* 33.
- Ninomiya, Y. (2003). A stabilized vegetation index and several mineralogic indices defined for ASTER VNIR and SWIR data. *IGARSS 2003*.
- Ninomiya, Y. (2003). Rock type mapping with indices defined for multispectral thermal infrared ASTER data. *Proc. SPIE* 4886.
- Ninomiya, Y., Fu, B. & Cudahy, T.J. (2005). Detecting lithology with ASTER multispectral TIR data. *Remote Sens. Environ.* 99.
- Rowan, L.C. & Mars, J.C. (2003). Lithologic mapping in the Mountain Pass, California area using ASTER data. *Remote Sens. Environ.* 84.
- Rowan, L.C., Hook, S.J., Abrams, M.J. & Mars, J.C. (2003). Mapping hydrothermally altered rocks at Cuprite, Nevada, using ASTER. *Econ. Geol.* 98.
- Sabins, F.F. (1999). Remote sensing for mineral exploration. *Ore Geol. Rev.* 14.
- Sillitoe, R.H. (2010). Porphyry copper systems. *Econ. Geol.* 105.
- Thome, K. et al. (2001). ASTER preflight and inflight calibration. *IEEE TGRS* 36.
