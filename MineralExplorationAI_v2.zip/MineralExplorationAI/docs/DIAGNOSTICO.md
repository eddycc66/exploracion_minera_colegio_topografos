# Diagnóstico de MineralExplorationAI v1 → correcciones en v2

Las referencias apuntan a archivo y función o método de la v1 revisada en
`D:\SPATIALMIND_AI\codigo_geoia\MineralExplorationAI`. Severidad: **C** crítico (falla o
resultado incorrecto), **A** alto (resultado sesgado), **M** medio (robustez/UX).

## 1. Instalación y carga

| # | Archivo / función | Sev. | Problema | Corrección v2 |
|---|---|---|---|---|
| 1 | `metadata.txt` | C | `qgisMinimumVersion=4.0`: QGIS 3.22–3.40 rechaza el plugin | `3.22`, `qgisMaximumVersion=4.99`, `supportsQt6=True` |
| 2 | `main.py` (imports) → `analysis_engine.py` | C | `from sklearn.cluster import KMeans` a nivel de módulo: sin scikit-learn el plugin no carga | Carga diferida; K-Means con motor NumPy si falta sklearn (`core/kmeans.py`) |
| 3 | `geominer_dialog.GeoMinerDialog.__init__` | C | `KMeansEngine()` lanza ImportError sin sklearn y el diálogo no abre | Idem |
| 4 | `processing/reporting.py` (cuerpo de `ReportGenerator`) | C | `COLORS = {... colors.HexColor ...}` se evalúa al importar: `NameError` si falta ReportLab; el `try/except ImportError` no lo cubre | PDF con `QTextDocument` + `QPrinter` (`ui/pages_results.py`), sin ReportLab |
| 5 | `metadata.txt` | M | Versión 8.3.0 con changelog de un script GEE JS; nombre distinto al visible | Versión 2.0.0, changelog real |
| 6 | `qt_compat.py`, `mineral_exploration_ui.py` | M | `QgsMapLayerProxyModel.RasterLayer` obsoleto en 3.34 y eliminado en QGIS 4 | `compat.py`: `Qgis.LayerFilter` con respaldo |

## 2. Lectura raster, NoData y tipos

| # | Archivo / función | Sev. | Problema | Corrección v2 |
|---|---|---|---|---|
| 7 | `analysis_engine.get_raster_data` | C | Mapeo de `Qgis.DataType` invertido (6=Float32, 7=Float64) | Lectura directa con GDAL (`core/raster_io.read_band`) |
| 8 | idem | C | Byte/UInt16 caen en `float32` → tamaño de buffer distinto → bucle `block.value(r, c)` píxel a píxel (minutos por banda) | idem, vectorizado |
| 9 | idem | C | `np.frombuffer` devuelve un array de solo lectura; `data[...] = nan` falla. En enteros NaN no es representable | Copia float32 escribible |
| 10 | idem | A | `sourceNoDataValue` usado sin `sourceHasNoDataValue`; DN = 0 de relleno ASTER no enmascarado | NoData declarado + DN 0 + NaN/Inf unificados |
| 11 | `stack_builder._open_and_resample` | A | `ReprojectImage` bilineal sin NoData de origen: −9999 se mezcla en los bordes | `warp_band_to_grid`: NoData unificado antes de interpolar |
| 12 | `prospectivity._resample_to_reference` | A | `scipy.ndimage.zoom` escala por forma e ignora extensión, origen y CRS | `gdal.Warp` a la grilla exacta de referencia |
| 13 | `identify_priority_zones`, `identify_structural_targets` | A | Recorte `[:h, :w]` por forma mínima: arrays desalineados | Alineación por coordenadas |
| 14 | `analysis_engine.save_raster` | M | Geotransform tomado de `gdal.Open(reference_layer.source())`; falla con capas no GDAL; `writer`/`pipe` sin uso | `write_float(path, arr, grid)` con la grilla explícita |

## 3. Índices y favorabilidad

Ver `INDICES.md` para la física y las referencias.

| # | Archivo / función | Sev. | Problema | Corrección v2 |
|---|---|---|---|---|
| 15 | `calculate_indices` | C | `x / (y + 0.001)`: el épsilon no evita valores enormes con y≈0 ni cambios de signo con y<0 | `sdiv`: NaN si \|den\| < 1e-6 |
| 16 | idem, `'Propilitica'` B4/B5 | C | Mide la absorción Al–OH a 2.17 µm (alunita/caolinita), la zona opuesta | `(B6+B9)/(B7+B8)` |
| 17 | idem, `'Caolinita'` B6/B5 | A | B6 también absorbe en caolinita; la tabla del encargo (B5/B6) es igual a la de sericita | KLI `(B4/B5)·(B8/B6)` |
| 18 | idem, `'Silice'` (B13/B12)+(B13/B14) | A | B13/B14 es el índice de carbonatos: falso positivo en calizas (×1.088 en la prueba) | QI `B11²/(B10·B12)` y `B13/B10` |
| 19 | Carbonatos del encargo (B13+B11)/(2·B12) | A | B12 es mínimo del cuarzo: el índice crece con la sílice | CI `B13/B14` |
| 20 | `'OH'` (B6+B9)/(2·B8) | A | B6 no es hombro de B8; la illita absorbe en B6 y queda penalizada | RBD8 `(B7+B9)/(2·B8)` |
| 21 | `calculate_indices` (normalización interna 5–95) | A | Se pierden los valores físicos y después se vuelve a normalizar | Índice crudo guardado aparte; normalización explícita |
| 22 | `calculate_favorability` modo `'Polimetalico'` | C | Claves (`Carbonatos`, `Dolomita`, `Plata`…) que nunca se calculan: favorabilidad vacía | Presets con claves reales del registro |
| 23 | `generate_favorability` | C | `.get(k, 0)` devuelve el escalar 0: `final_score[~mask]` falla si faltan índices | Superposición con evidencias existentes |
| 24 | idem | A | `get_raster_stack` carga las 19 bandas; mean + 0.5σ y doble estiramiento: umbrales dependientes de la escena | Sin doble normalización |
| 25 | `mineral_exploration_ui.run_favorability` | A | Solo usa silice/alunita/sericita/oxidos; omite caolinita y OH | Todas las evidencias activas |
| 26 | `prospectivity.calculate_mineral_favorability` | A | NaN → 0 (el NoData entra como "fondo"); pesos por subcadena (`'oh'` coincide en otros nombres) | NaN preservado; claves exactas |
| 27 | (integración) | A | Donde no hay imagen, la estructura sola genera puntaje (falsos targets de borde) | Sin evidencia mineral válida → NaN |

## 4. Estructural, targets y validación

| # | Archivo / función | Sev. | Problema | Corrección v2 |
|---|---|---|---|---|
| 28 | `extract_lineaments`, `identify_priority_zones`, `run_slope` | C | `np.gradient` con espaciado de 1 píxel: pendientes ~30 veces mayores en 30 m y sin sentido en grados | `np.gradient(dem, dy_m, dx_m)` con metros reales |
| 29 | `extract_lineaments` | M | Solo la magnitud del gradiente al percentil 85; sin direcciones ni densidad | Sobel en 4 azimuts + densidad circular (radio en m) |
| 30 | `targets.generate_targets` | A | Puntaje por centroide (puede caer fuera del polígono cóncavo) | Máximo y media zonales sobre todos los píxeles |
| 31 | idem y `vectorize_to_geojson` | A | Área en CRS geográfico = grados² × 111320² (asume el ecuador; en La Paz +4 %, a 40° +30 %) | Área por fila según la latitud |
| 32 | `targets.generate_targets` | M | `PRIORITY_THRESHOLDS` sin uso; línea muerta `raw_val = ... if False else None` | Reglas explícitas y documentadas |
| 33 | `vectorize_to_geojson` | M | `Polygonize` sin máscara: el NoData podría poligonizarse; área < 0.1 "probablemente grados" | Máscara y CRS explícitos |
| 34 | `validation.validate_against_known` | A | Distancia al centroide (un punto dentro de un target grande "falla") | Distancia al borde (0 si está dentro) |
| 35 | idem | A | Ocurrencias no reproyectadas al CRS de los targets | Transformación OSR con orden de ejes tradicional |
| 36 | idem | A | Solo % de aciertos; sin negativos ni métricas de clasificación | Matriz de confusión, OA, Kappa, precisión, recall, F1, ganancia |
| 37 | `geo_ai_advisor.analyze_cluster_geology` | A | Clusters interpretados por tamaño ("pequeño = anomalía", "grande = nieve") | Firma del centroide (puntaje z por índice) |
| 38 | `generate_exploration_recommendations` | M | Presupuesto USD/ha fijo sin base | Eliminado; fases por prioridad y confianza según la validación |

## 5. Interfaz, hilos y GEE

| # | Archivo / función | Sev. | Problema | Corrección v2 |
|---|---|---|---|---|
| 39 | `geominer_dialog.closeEvent` | C | `quit()` + `wait(3000)` en un hilo sin bucle de eventos: "QThread destroyed while running" puede cerrar QGIS | Cancelación cooperativa y espera completa |
| 40 | `mineral_exploration_ui.download_sentinel` | C | `QgsCoordinateReferenceSystem`/`QgsCoordinateTransform` sin importar: `NameError` | GEE reescrito (`core/gee.py`) |
| 41 | `mineral_exploration_ui.run_indices`, `run_ml`, `run_favorability`… | A | Procesamiento pesado en el hilo de la GUI: QGIS se congela | Todos los pasos en `Worker` (QThread) |
| 42 | `mineral_exploration_ui.inspect_point` | A | Muestra B10/B11/B13 crudas como "Sílice/Alunita/Óxidos"; bandas ausentes = 1 | Inspector retirado (hoja de ruta) |
| 43 | `mineral_exploration_ui` (mapeo de bandas) | A | El mapeo avanzado solo se usa en `run_ml`; `calculate_aster_indices` lo ignora | Mapeo único en el paso 1 para todos los cálculos |
| 44 | `geominer_dialog._tab1_config` | M | Etiquetas con fórmulas incorrectas (Caolinita B6/B5) | Tooltips desde el registro de índices |
| 45 | `geominer_dialog._run_pdf` | M | `prospectivity_stats: {}` e imágenes de mapa `None`: PDF con ceros | Contexto completo y mapas renderizados |
| 46 | Dock: campo de contraseña | M | Credenciales en texto sin uso ni almacenamiento seguro | Eliminado |
| 47 | `analysis_engine.init_ee` | A | `ee.Authenticate()` dentro de QGIS bloquea la interfaz | Solo `ee.Initialize(project)` |
| 48 | `analysis_engine.get_aster_gee` | A | Mediana de DN de escenas con ganancias distintas; máscara `DN·0.001 < 1` siempre cierta; índices en la nube con fórmulas v1 | Una escena con SWIR (menor nubosidad), bandas crudas e índices locales |

## 6. Sin cambios necesarios

- Índice de óxidos férricos B2/B1: correcto.
- `normalize.py`: correcto en lo esencial (NaN preservado); integrado y ampliado.
- La advertencia del fallo SWIR de 2008 se conserva, ahora ligada a la fecha de la escena.
