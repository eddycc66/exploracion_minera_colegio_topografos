# Interfaz de GeoMineral AI v2

## Estructura general

```
┌─────────────────────────────────────────────────────────────────────────────────────┐
│ ◆ GeoMineral AI [v2.0.0]                      Proyecto: X   💾 ⤒ ☀ ⤡  [ES▾] (?)Ayuda │  Header
│   Análisis avanzado de prospectividad · ASTER  C:\salidas                              │
├──────────────────────┬──────────────────────────────────────────────────────────────┤
│ ✓ 1 Configuración    │ [QgsMessageBar: avisos, errores, confirmaciones]              │
│▌⚙ 2 Normalizar       │ Paso 2 de 9                                                   │
│  ≡ 3 Stack           │ Normalizar                                                    │
│  ⁘ 4 K-Means         │ Cálculo de índices minerales y normalización a 0–1            │
│  ◇ 5 Fav. mineral    │ ┌ Índices ───────────────────┐ ┌ Normalización ─────────────┐ │
│  ◎ 6 Prosp. integrada│ │ ▾ VNIR · óxidos y hierro   │ │ Método [Percentil ▾]       │ │
│  ⊕ 7 Targets         │ │   ☑ Óxidos Fe³⁺   B2/B1    │ │ P. inferior ●──────  2.0 % │ │
│  ✓ 8 Validación      │ │ ▾ SWIR · arcillas, micas   │ │ P. superior ──────● 98.0 % │ │
│  ▤ 9 Reportes        │ │   ☑ Alunita (ALI) …        │ └────────────────────────────┘ │
│                      │ │ ▾ TIR · sílice, carbonatos │ ┌ Vista previa ──────────────┐ │
│                      │ │   ☑ Cuarzo (QI) …          │ │ ▁▂▅█▆▃▁   ¦Pl        Ph¦   │ │
│ Ctrl+R · Ctrl+S      │ └────────────────────────────┘ └────────────────────────────┘ │
│ Alt+←/→ · F1         │ ┌ Resultados: Índice | Mín | P2 | Mediana | P98 | Máx | ND% ┐ │
├──────────────────────┴──────────────────────────────────────────────────────────────┤
│ 20:09:28 OK  10 índices guardados en …/indices                          (registro)    │  Log (Ctrl+L)
├─────────────────────────────────────────────────────────────────────────────────────┤
│ ‹ Anterior  ≡  [██████░░ 72%]  Guardando cuarzo…   [■ Cancelar] [▶ Calcular índices] Siguiente: Stack › │ Footer
└─────────────────────────────────────────────────────────────────────────────────────┘
```

- **Barra lateral** (`QListWidget#StepList`) sincronizada con `QStackedWidget`. El paso activo
  lleva una barra ámbar a la izquierda (el único acento fuerte de la interfaz) y los pasos
  completados muestran ✓ verde. Si cambian los datos de un paso, los pasos posteriores
  se marcan como pendientes.
- **Botón principal**: cambia de texto según el paso (Validar configuración, Calcular índices,
  Crear stack…). Ctrl+R lo ejecuta.
- **Ejecución**: en segundo plano, con barra de progreso, estado y Cancelar. QGIS no se congela.

## Componentes por paso

| Paso | Componentes |
|---|---|
| 1 Configuración | Formulario en grilla con validación en vivo (borde rojo); tabla de 14 bandas (combo de capa + nº de banda); **Autodetectar capas ASTER**; radiometría (unidades, calibración, ganancia, fecha con aviso SWIR 2008, elevación solar); AOI/DEM/ocurrencias; máscaras NDVI/sombras; GEE opcional; KPIs de la grilla |
| 2 Normalizar | Árbol de índices por subsistema con casillas, fórmula y tooltip (física, referencia y falsos positivos); método; sliders + spinbox sincronizados; histograma en vivo con cortes Pl/Ph; tabla de estadísticas; "Solo re-normalizar" |
| 3 Stack | Lista con casillas y **arrastrar y soltar**; Subir/Bajar; KPIs de bandas, dimensiones y MB |
| 4 K-Means | Clusters, inicialización, iteraciones, semilla, muestra; barras coloreadas; tabla con interpretación por firma y relevancia |
| 5 Fav. mineral | Modelo (AS/BS/pórfido/personalizado); tabla: usar · color editable · índice · fórmula · peso · barra de peso relativo; modo estricto; KPIs |
| 6 Prosp. integrada | Evidencias con pesos y barras; añadir raster externo; parámetros estructurales; histograma; KPIs |
| 7 Targets | Umbral (slider + spinbox) con % de área estimado; área mínima; KPIs por prioridad; tabla ordenable con coordenadas; doble clic → zoom + destello; CSV; abrir carpeta |
| 8 Validación | Buffer, puntos de fondo, semilla; KPIs coloreados (OA, Kappa, F1, precisión, éxito, ganancia); matriz de confusión; interpretación Landis & Koch; tabla de ocurrencias |
| 9 Reportes | Casillas de secciones; plantilla completa/ejecutiva; capturas de mapa; **Generar PDF**; HTML; CSV; recomendaciones |

## Tokens de diseño (`resources/styles/geomineral.qss`)

| Token | Oscuro | Claro | Uso |
|---|---|---|---|
| `@bg` | `#1e2229` | `#eef1f5` | Fondo |
| `@panel` | `#252a33` | `#ffffff` | Tarjetas, cabecera, barra lateral |
| `@raised` | `#2c323d` | `#f6f8fa` | Campos, hover, KPI |
| `@border` | `#3a3f4b` | `#d3d8e0` | Bordes (radio 6–8 px) |
| `@text` / `@muted` | `#e6e6e6` / `#9aa3b2` | `#1e2229` / `#5c6370` | Texto |
| `@accent` | `#f39c12` | `#c77c0a` | Acción principal, paso activo |
| `@ok` / `@err` | `#00b894` / `#e74c3c` | `#00a383` / `#d63031` | Éxito / error |

- Tipografía: Inter → Segoe UI → Roboto, en **pt** para ser DPI-aware.
- Iconos: SVG vectoriales coloreados por tema, nítidos en HiDPI.
- Modo compacto: `compact.qss` reduce rellenos para pantallas de 1366×768.
- Etiquetas en tipo oración, sin mayúsculas sostenidas.

## Capturas (QGIS 3.34, escena sintética)

| Archivo | Contenido |
|---|---|
| `screenshots/01_configuracion.png` | Paso 1 tras autodetectar 14 bandas |
| `screenshots/02_normalize.png` | Árbol de índices, sliders e histograma |
| `screenshots/03_stack.png` | Lista con arrastrar y soltar |
| `screenshots/04_kmeans.png` | Distribución e interpretación |
| `screenshots/05_mineral.png` | Pesos del modelo AS |
| `screenshots/06_integrated.png` | Evidencias e histograma |
| `screenshots/07_targets.png` | Tabla de targets y KPIs |
| `screenshots/08_validation.png` | KPIs y matriz de confusión |
| `screenshots/09_reportes.png` | Secciones y recomendaciones |
| `screenshots/claro_*.png` | Tema claro |
| `screenshots/compacto_02_normalize.png` | Modo compacto |
| `screenshots/en_04_kmeans.png` | Interfaz en inglés |
| `screenshots/qt6_validacion_claro_compacto.png` | Qt6 (PyQt6 6.11), tema claro y modo compacto |

Las capturas están en el ZIP (`docs/screenshots/`); no se copian a la carpeta de trabajo
porque el acceso a disco solo admite texto.

## Cómo personalizar

- **Colores**: edite los valores de `PALETTES` en `ui/theme.py`. El QSS usa tokens `@nombre`.
- **Nuevo índice**: añada un `IndexDef` en `core/indices.py`. Aparece automáticamente en los
  pasos 2, 3 y 5, con tooltip y color.
- **Nuevo modelo de pesos**: añada una entrada a `PRESETS` en `core/prospectivity.py`.
- **Traducciones**: agregue cadenas a `EN` en `i18n.py` o edite `i18n/GeoMineralAI_en.ts`
  con Qt Linguist y compile con `lrelease`.
