# -*- coding: utf-8 -*-
"""
Compatibilidad QGIS 3.22+ (Qt5 / PyQt 5.15) y QGIS 4.x (Qt6 / PyQt6).

Reglas usadas en todo el plugin:
  * Enums SIEMPRE con alcance (Qt.AlignmentFlag.AlignCenter): válido en PyQt 5.15 y PyQt6.
  * QAction / QShortcut se importan desde aquí (QtGui en Qt6, QtWidgets en Qt5).
  * exec_dialog() en lugar de exec_() (eliminado en Qt6).
  * Filtros de capa: Qgis.LayerFilter (>= 3.34) o QgsMapLayerProxyModel.* (3.22-3.32).
  * Tipo de capa: Qgis.LayerType (>= 3.30, 4.x) o QgsMapLayerType (3.22-3.28).
  * Interpolación de rampas: Qgis.ShaderInterpolationMethod (4.x) o QgsColorRampShader.Type.
  * Códigos de QgsVectorFileWriter comparados por nombre (el enum se movió en 4.x).
"""
from qgis.core import Qgis, QgsMapLayerProxyModel, QgsColorRampShader

try:                                    # QGIS 3.x <= 3.28
    from qgis.core import QgsMapLayerType as _QgsMapLayerType
except ImportError:                     # QGIS 4.x
    _QgsMapLayerType = None

try:                                    # Qt6
    from qgis.PyQt.QtGui import QAction, QShortcut, QKeySequence
except ImportError:                     # Qt5
    from qgis.PyQt.QtWidgets import QAction, QShortcut
    from qgis.PyQt.QtGui import QKeySequence


def _layer_filter(name):
    lf = getattr(Qgis, 'LayerFilter', None)
    if lf is not None and hasattr(lf, name):
        return getattr(lf, name)
    flt = getattr(QgsMapLayerProxyModel, 'Filter', None)
    if flt is not None and hasattr(flt, name):
        return getattr(flt, name)
    return getattr(QgsMapLayerProxyModel, name)


RASTER = _layer_filter('RasterLayer')
VECTOR = _layer_filter('VectorLayer')
POINT = _layer_filter('PointLayer')
POLYGON = _layer_filter('PolygonLayer')


def _layer_type(new, old):
    """Qgis.LayerType.Raster (>= 3.30 y 4.x) o QgsMapLayerType.RasterLayer (3.22-3.28)."""
    lt = getattr(Qgis, 'LayerType', None)
    if lt is not None and hasattr(lt, new):
        return getattr(lt, new)
    return getattr(_QgsMapLayerType, old)


RASTER_LAYER = _layer_type('Raster', 'RasterLayer')
VECTOR_LAYER = _layer_type('Vector', 'VectorLayer')


def is_raster(layer):
    return layer is not None and layer.type() == RASTER_LAYER


def writer_ok(code):
    """True si el código de QgsVectorFileWriter es NoError (el enum cambia entre versiones)."""
    name = getattr(code, 'name', None)
    if name is not None:
        return name == 'NoError'
    try:
        return int(code) == 0
    except Exception:
        return False


def msg_level(name):
    """'Info' | 'Warning' | 'Critical' | 'Success' para QgsMessageBar/QgsMessageLog."""
    ml = getattr(Qgis, 'MessageLevel', None)
    if ml is not None and hasattr(ml, name):
        return getattr(ml, name)
    return getattr(Qgis, name)


def ramp_type(name):
    """'Interpolated' | 'Discrete' | 'Exact' para QgsColorRampShader."""
    sim = getattr(Qgis, 'ShaderInterpolationMethod', None)
    if sim is not None:
        return getattr(sim, {'Interpolated': 'Linear'}.get(name, name))
    crt = getattr(QgsColorRampShader, 'Type', None)
    if crt is not None and hasattr(crt, name):
        return getattr(crt, name)
    return getattr(QgsColorRampShader, name)


def exec_dialog(dlg):
    return dlg.exec() if hasattr(dlg, 'exec') else dlg.exec_()


QGIS_INT = Qgis.QGIS_VERSION_INT
