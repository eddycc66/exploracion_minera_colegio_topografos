# -*- coding: utf-8 -*-
"""
GeoMineral AI v2 — ventana principal (dashboard).

  ┌ Header: logo · título · subtítulo · versión · proyecto · tema · compacto · idioma · ayuda
  ├ Sidebar (QListWidget, 9 pasos) ─┬─ QgsMessageBar
  │                                 ├─ Cabecera de página (paso, título, descripción)
  │                                 └─ QStackedWidget (páginas con scroll)
  ├ Log colapsable (INFO/OK/WARN/ERROR coloreado)
  └ Footer: ◀ Anterior · barra de progreso · estado · Cancelar · Ejecutar (Ctrl+R) · Siguiente ▶
"""
import json
import os

from qgis.PyQt.QtCore import Qt, QSize, pyqtSignal, QUrl, QTimer
from qgis.PyQt.QtGui import QDesktopServices
from qgis.PyQt.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QFrame, QLabel,
                                 QListWidget, QListWidgetItem, QStackedWidget, QPushButton,
                                 QToolButton, QProgressBar, QWidget, QScrollArea, QComboBox,
                                 QFileDialog, QSplitter, QTextBrowser, QSizePolicy)
from qgis.core import QgsProject, QgsSettings, QgsMessageLog
from qgis.gui import QgsMessageBar

from ..compat import QShortcut, QKeySequence, msg_level
from ..i18n import tr, language
from . import theme as th
from .icons import icon, STEP_ICONS
from .widgets import LogPanel
from .worker import Worker

VERSION = '2.0.0'
SETTINGS = 'GeoMineralAI/'


class GeoMineralDialog(QDialog):
    rebuild_requested = pyqtSignal()

    def __init__(self, iface, plugin_dir, parent=None):
        super(GeoMineralDialog, self).__init__(parent)
        self.iface = iface
        self.plugin_dir = plugin_dir
        self.setObjectName('GeoMineralDialog')
        self.setWindowTitle('GeoMineral AI — ' + tr('Análisis avanzado de prospectividad · ASTER'))
        self.setWindowFlags(self.windowFlags() | Qt.WindowType.WindowMaximizeButtonHint
                            | Qt.WindowType.WindowMinimizeButtonHint)
        s = QgsSettings()
        self.theme_name = s.value(SETTINGS + 'theme', 'dark')
        self.compact = s.value(SETTINGS + 'compact', False, type=bool)
        self.pal = th.palette(self.theme_name)
        self.state = {'done': set()}
        self._worker = None
        self._busy_page = None

        self._build()
        self._apply_theme()
        self._shortcuts()
        self._restore()
        self.log('INFO', 'GeoMineral AI v%s listo. Siga los pasos 1 → 9 (Ctrl+R ejecuta el paso actual).' % VERSION)

    # ------------------------------------------------------------------ estructura
    def _build(self):
        from .pages_data import ConfigPage, NormalizePage, StackPage
        from .pages_model import KMeansPage, MineralFavPage, IntegratedPage
        from .pages_results import TargetsPage, ValidationPage, ReportsPage

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)
        root.addWidget(self._header())

        body = QSplitter(Qt.Orientation.Horizontal)
        body.setHandleWidth(1)
        body.setChildrenCollapsible(False)
        root.addWidget(body, 1)

        # Barra lateral
        side = QFrame()
        side.setObjectName('Sidebar')
        sl = QVBoxLayout(side)
        sl.setContentsMargins(0, 10, 0, 0)
        self.steps = QListWidget()
        self.steps.setObjectName('StepList')
        self.steps.setIconSize(QSize(18, 18))
        self.steps.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        sl.addWidget(self.steps, 1)
        self.side_foot = QLabel('Ctrl+R ejecutar · Ctrl+S guardar\nAlt+←/→ navegar · F1 ayuda')
        self.side_foot.setObjectName('SidebarFoot')
        sl.addWidget(self.side_foot)
        fm = self.fontMetrics()
        side.setMinimumWidth(fm.horizontalAdvance('9   Prosp. integrada   ✓') + 60)
        body.addWidget(side)

        # Centro
        central = QWidget()
        central.setObjectName('Central')
        cl = QVBoxLayout(central)
        cl.setContentsMargins(18, 10, 18, 8)
        cl.setSpacing(6)
        self.bar = QgsMessageBar()
        self.bar.setSizePolicy(QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Fixed)
        cl.addWidget(self.bar)
        head = QVBoxLayout()
        head.setSpacing(0)
        self.lbl_step = QLabel()
        self.lbl_step.setObjectName('PageStep')
        self.lbl_title = QLabel()
        self.lbl_title.setObjectName('PageTitle')
        self.lbl_sub = QLabel()
        self.lbl_sub.setObjectName('PageSubtitle')
        self.lbl_sub.setWordWrap(True)
        head.addWidget(self.lbl_step)
        head.addWidget(self.lbl_title)
        head.addWidget(self.lbl_sub)
        cl.addLayout(head)
        self.stack = QStackedWidget()
        cl.addWidget(self.stack, 1)
        body.addWidget(central)
        body.setStretchFactor(1, 1)

        self.pages = [ConfigPage(self), NormalizePage(self), StackPage(self), KMeansPage(self),
                      MineralFavPage(self), IntegratedPage(self), TargetsPage(self),
                      ValidationPage(self), ReportsPage(self)]
        self.page_by_key = {p.key: p for p in self.pages}
        for i, p in enumerate(self.pages):
            sa = QScrollArea()
            sa.setWidgetResizable(True)
            sa.setFrameShape(QFrame.Shape.NoFrame)
            sa.setWidget(p)
            self.stack.addWidget(sa)
            it = QListWidgetItem('%d   %s' % (i + 1, tr(p.title)))
            it.setToolTip(tr(p.subtitle))
            self.steps.addItem(it)
        self.steps.currentRowChanged.connect(self._go)

        # Registro colapsable
        self.log_panel = LogPanel()
        self.log_panel.setMinimumHeight(70)
        self.log_panel.setMaximumHeight(130)
        root.addWidget(self.log_panel)
        root.addWidget(self._footer())

    def _header(self):
        f = QFrame()
        f.setObjectName('Header')
        lay = QHBoxLayout(f)
        lay.setContentsMargins(16, 8, 12, 8)
        lay.setSpacing(10)
        self.logo = QLabel()
        lay.addWidget(self.logo)
        tb = QVBoxLayout()
        tb.setSpacing(0)
        row = QHBoxLayout()
        row.setSpacing(8)
        t = QLabel('GeoMineral AI')
        t.setObjectName('AppTitle')
        v = QLabel('v' + VERSION)
        v.setObjectName('VersionPill')
        row.addWidget(t)
        row.addWidget(v)
        row.addStretch()
        tb.addLayout(row)
        sub = QLabel(tr('Análisis avanzado de prospectividad · ASTER'))
        sub.setObjectName('AppSubtitle')
        tb.addWidget(sub)
        lay.addLayout(tb)
        lay.addStretch()
        self.lbl_project = QLabel()
        self.lbl_project.setObjectName('ProjectLabel')
        self.lbl_project.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        lay.addWidget(self.lbl_project)

        def hbtn(tip, checkable=False):
            b = QToolButton()
            b.setObjectName('HeaderButton')
            b.setToolTip(tip)
            b.setCheckable(checkable)
            b.setIconSize(QSize(18, 18))
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            lay.addWidget(b)
            return b

        self.btn_save = hbtn(tr('Guardar configuración') + ' (Ctrl+S)')
        self.btn_save.clicked.connect(self.save_project)
        self.btn_load = hbtn(tr('Cargar configuración') + ' (Ctrl+O)')
        self.btn_load.clicked.connect(self.load_project)
        self.btn_theme = hbtn(tr('Tema claro'))
        self.btn_theme.clicked.connect(self.toggle_theme)
        self.btn_compact = hbtn(tr('Modo compacto'), checkable=True)
        self.btn_compact.setChecked(self.compact)
        self.btn_compact.toggled.connect(self.set_compact)
        self.cmb_lang = QComboBox()
        self.cmb_lang.addItems(['ES', 'EN'])
        self.cmb_lang.setCurrentIndex(1 if language() == 'en' else 0)
        self.cmb_lang.setToolTip(tr('Idioma'))
        self.cmb_lang.setFixedWidth(self.fontMetrics().horizontalAdvance('EN') + 44)
        self.cmb_lang.currentIndexChanged.connect(self._lang_changed)
        lay.addWidget(self.cmb_lang)
        self.btn_help = QPushButton(tr('Ayuda'))
        self.btn_help.clicked.connect(self.show_help)
        lay.addWidget(self.btn_help)
        return f

    def _footer(self):
        f = QFrame()
        f.setObjectName('Footer')
        lay = QHBoxLayout(f)
        lay.setContentsMargins(12, 8, 12, 8)
        lay.setSpacing(8)
        self.btn_prev = QPushButton(tr('Anterior'))
        self.btn_prev.clicked.connect(lambda: self.steps.setCurrentRow(max(0, self.steps.currentRow() - 1)))
        lay.addWidget(self.btn_prev)
        self.btn_log = QToolButton()
        self.btn_log.setObjectName('HeaderButton')
        self.btn_log.setCheckable(True)
        self.btn_log.setChecked(True)
        self.btn_log.setToolTip(tr('Registro'))
        self.btn_log.toggled.connect(self.log_panel.setVisible)
        lay.addWidget(self.btn_log)
        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        self.progress.setMaximumWidth(260)
        lay.addWidget(self.progress)
        self.lbl_status = QLabel(tr('Listo'))
        self.lbl_status.setObjectName('StatusLabel')
        self.lbl_status.setMinimumWidth(120)
        lay.addWidget(self.lbl_status, 1)
        self.btn_cancel = QPushButton(tr('Cancelar'))
        self.btn_cancel.setObjectName('Danger')
        self.btn_cancel.setVisible(False)
        self.btn_cancel.clicked.connect(self.cancel)
        lay.addWidget(self.btn_cancel)
        self.btn_run = QPushButton(tr('Ejecutar'))
        self.btn_run.setObjectName('Primary')
        self.btn_run.setToolTip('Ctrl+R')
        self.btn_run.clicked.connect(self.run_current)
        lay.addWidget(self.btn_run)
        self.btn_next = QPushButton(tr('Siguiente'))
        self.btn_next.setLayoutDirection(Qt.LayoutDirection.RightToLeft)
        self.btn_next.clicked.connect(lambda: self.steps.setCurrentRow(
            min(len(self.pages) - 1, self.steps.currentRow() + 1)))
        lay.addWidget(self.btn_next)
        return f

    def _shortcuts(self):
        for seq, fn in (('Ctrl+R', self.run_current), ('Ctrl+S', self.save_project),
                        ('Ctrl+O', self.load_project), ('F1', self.show_help),
                        ('Alt+Right', lambda: self.btn_next.click()),
                        ('Alt+Left', lambda: self.btn_prev.click()),
                        ('Ctrl+L', lambda: self.btn_log.toggle())):
            sc = QShortcut(QKeySequence(seq), self)
            sc.activated.connect(fn)

    # ------------------------------------------------------------------ tema
    def _apply_theme(self):
        self.pal = th.palette(self.theme_name)
        self.setStyleSheet(th.stylesheet(self.theme_name, self.compact))
        c, a = self.pal['text'], self.pal['accent']
        self.logo.setPixmap(icon('mineral', a, 64).pixmap(QSize(30, 30)))
        self.btn_save.setIcon(icon('save', c))
        self.btn_load.setIcon(icon('open', c))
        self.btn_theme.setIcon(icon('sun' if self.theme_name == 'dark' else 'moon', c))
        self.btn_theme.setToolTip(tr('Tema claro') if self.theme_name == 'dark' else tr('Tema oscuro'))
        self.btn_compact.setIcon(icon('compact', c))
        self.btn_help.setIcon(icon('help', c))
        self.btn_prev.setIcon(icon('left', c))
        self.btn_next.setIcon(icon('right', c))
        self.btn_run.setIcon(icon('play', '#1e2229'))
        self.btn_cancel.setIcon(icon('stop', self.pal['err']))
        self.btn_log.setIcon(icon('log', c))
        self._refresh_steps()
        for p in self.pages:
            p.on_theme(self.pal)

    def _refresh_steps(self):
        for i, p in enumerate(self.pages):
            it = self.steps.item(i)
            done = p.key in self.state['done']
            if done:
                it.setIcon(icon('check', self.pal['ok']))
            else:
                it.setIcon(icon(STEP_ICONS[i], self.pal['muted']))
            it.setText('%d   %s' % (i + 1, tr(p.title)))

    def toggle_theme(self):
        self.theme_name = 'light' if self.theme_name == 'dark' else 'dark'
        QgsSettings().setValue(SETTINGS + 'theme', self.theme_name)
        self._apply_theme()

    def set_compact(self, on):
        self.compact = bool(on)
        QgsSettings().setValue(SETTINGS + 'compact', self.compact)
        self.log_panel.setMaximumHeight(96 if on else 130)
        self._apply_theme()

    def _lang_changed(self, i):
        QgsSettings().setValue(SETTINGS + 'language', 'en' if i == 1 else 'es')
        self.save_settings()
        self.notify('Info', 'Idioma cambiado. La ventana se reabrirá para aplicarlo.')
        QTimer.singleShot(300, self.rebuild_requested.emit)

    # ------------------------------------------------------------------ navegación
    def _go(self, row):
        if row < 0:
            return
        self.stack.setCurrentIndex(row)
        p = self.pages[row]
        self.lbl_step.setText('Paso %d de %d' % (row + 1, len(self.pages)))
        self.lbl_title.setText(tr(p.title))
        self.lbl_sub.setText(tr(p.subtitle))
        self.btn_run.setText(tr(p.run_text))
        self.btn_prev.setEnabled(row > 0)
        self.btn_next.setEnabled(row < len(self.pages) - 1)
        if row < len(self.pages) - 1:
            self.btn_next.setText(tr('Siguiente') + ': ' + tr(self.pages[row + 1].title))
        else:
            self.btn_next.setText(tr('Siguiente'))
        self._update_project_label()
        p.refresh()

    def current_page(self):
        return self.pages[self.steps.currentRow()]

    def goto(self, key):
        for i, p in enumerate(self.pages):
            if p.key == key:
                self.steps.setCurrentRow(i)

    def mark_done(self, key, done=True):
        if done:
            self.state['done'].add(key)
        else:
            self.state['done'].discard(key)
        self._refresh_steps()

    def _update_project_label(self):
        prj = QgsProject.instance().baseName() or tr('sin guardar')
        out = self.page_by_key['config'].out_dir() if 'config' in self.page_by_key else ''
        self.lbl_project.setText('%s: %s\n%s' % (tr('Proyecto'), prj, out))

    # ------------------------------------------------------------------ ejecución
    def run_current(self):
        if self.is_busy():
            self.notify('Warning', 'Hay un proceso en curso. Espere o pulse Cancelar.')
            return
        p = self.current_page()
        ok, msg = p.check()
        if not ok:
            self.notify('Warning', msg)
            self.log('WARN', msg)
            return
        self.bar.clearWidgets()
        p.run()

    def is_busy(self):
        return self._worker is not None and self._worker.isRunning()

    def start(self, page, fn, on_done, label):
        """Lanza fn(job) en segundo plano; on_done(result) se ejecuta en el hilo principal."""
        self._busy_page = page
        w = Worker(fn, self)
        w.progress.connect(self._on_progress)
        w.message.connect(self.log)
        w.done.connect(lambda res: self._finish(page, on_done, res))
        w.failed.connect(lambda m, tb: self._fail(page, m, tb))
        w.finished.connect(w.deleteLater)
        self._worker = w
        self._set_busy(True, label)
        self.log('INFO', label)
        w.start()

    def _on_progress(self, pct, msg):
        self.progress.setValue(pct)
        if msg:
            self.lbl_status.setText(msg)
            self.log('INFO', '[%3d%%] %s' % (pct, msg))

    def _finish(self, page, on_done, res):
        self._worker = None
        self._set_busy(False)
        try:
            on_done(res)
            self.mark_done(page.key)
            self.save_settings()
        except Exception as e:           # noqa: BLE001
            import traceback
            self._fail(page, '%s: %s' % (type(e).__name__, e), traceback.format_exc())

    def _fail(self, page, msg, tb):
        self._worker = None
        self._set_busy(False)
        self.progress.setValue(0)
        self.lbl_status.setText('Error')
        self.log('ERROR', msg)
        if tb:
            QgsMessageLog.logMessage(tb, 'GeoMineral AI', msg_level('Critical'))
        self.notify('Critical', msg.split('\n')[0][:300])

    def _set_busy(self, busy, label=''):
        self.btn_run.setEnabled(not busy)
        self.btn_cancel.setVisible(busy)
        self.btn_cancel.setEnabled(busy)
        if busy:
            self.progress.setValue(0)
            self.lbl_status.setText(label)
        else:
            self.progress.setValue(100)
            self.lbl_status.setText(tr('Listo'))

    def cancel(self):
        if self._worker is not None:
            self._worker.cancel()
            self.btn_cancel.setEnabled(False)
            self.log('WARN', 'Cancelando… el proceso se detendrá al terminar el bloque actual.')

    # ------------------------------------------------------------------ mensajes
    def notify(self, level, text, duration=8):
        titles = {'Info': 'Info', 'Warning': 'Atención', 'Critical': 'Error', 'Success': 'Hecho'}
        self.bar.pushMessage(titles.get(level, level), text, msg_level(level), duration)

    def log(self, level, msg):
        self.log_panel.add(level, msg)
        QgsMessageLog.logMessage('[%s] %s' % (level, msg), 'GeoMineral AI',
                                 msg_level({'ERROR': 'Critical', 'WARN': 'Warning'}.get(level, 'Info')))

    # ------------------------------------------------------------------ persistencia
    def collect(self):
        data = {'version': VERSION, 'pages': {}}
        for p in self.pages:
            try:
                data['pages'][p.key] = p.save_settings()
            except Exception as e:        # noqa: BLE001
                self.log('WARN', 'No se guardó la configuración de %s: %s' % (p.key, e))
        return data

    def apply(self, data):
        for p in self.pages:
            if p.key in data.get('pages', {}):
                try:
                    p.load_settings(data['pages'][p.key])
                except Exception as e:    # noqa: BLE001
                    self.log('WARN', 'Configuración de %s no aplicada: %s' % (p.key, e))

    def save_settings(self):
        s = QgsSettings()
        s.setValue(SETTINGS + 'state', json.dumps(self.collect()))
        s.setValue(SETTINGS + 'geometry', self.saveGeometry())
        s.setValue(SETTINGS + 'page', self.steps.currentRow())

    def _restore(self):
        s = QgsSettings()
        geo = s.value(SETTINGS + 'geometry')
        if geo:
            self.restoreGeometry(geo)
        else:
            self.resize(1180, 780)
        self.setMinimumSize(760 if self.compact else 900, 560)
        raw = s.value(SETTINGS + 'state', '')
        if raw:
            try:
                self.apply(json.loads(raw))
            except Exception:
                pass
        self.steps.setCurrentRow(int(s.value(SETTINGS + 'page', 0) or 0))
        self.btn_log.setChecked(s.value(SETTINGS + 'log_visible', True, type=bool))
        self.set_compact(self.compact)

    def save_project(self):
        out = self.page_by_key['config'].out_dir()
        path, _ = QFileDialog.getSaveFileName(self, tr('Guardar configuración'),
                                              os.path.join(out, 'proyecto.geominer'),
                                              'GeoMineral AI (*.geominer)')
        if not path:
            return
        with open(path, 'w', encoding='utf-8') as fh:
            json.dump(self.collect(), fh, indent=2, ensure_ascii=False)
        self.notify('Success', 'Configuración guardada en %s' % os.path.basename(path), 4)

    def load_project(self):
        path, _ = QFileDialog.getOpenFileName(self, tr('Cargar configuración'), '',
                                              'GeoMineral AI (*.geominer *.json)')
        if not path:
            return
        with open(path, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        if 'pages' not in data:          # formato v1
            data = {'pages': {'config': {'project': data.get('project_name', ''),
                                         'analyst': data.get('analyst', ''),
                                         'out_dir': data.get('output_dir', '')}}}
            self.log('WARN', 'Proyecto v1 importado parcialmente (solo nombre, analista y carpeta).')
        self.apply(data)
        self.notify('Success', 'Configuración cargada: %s' % os.path.basename(path), 4)

    # ------------------------------------------------------------------ ayuda
    def show_help(self):
        from qgis.PyQt.QtWidgets import QDialog as _D
        d = _D(self)
        d.setWindowTitle('GeoMineral AI — ' + tr('Ayuda'))
        d.resize(760, 620)
        lay = QVBoxLayout(d)
        tb = QTextBrowser()
        tb.setOpenExternalLinks(True)
        p = self.current_page()
        tb.setHtml(p.help_html() + self._help_common())
        lay.addWidget(tb)
        readme = os.path.join(self.plugin_dir, 'README.md')
        b = QPushButton('Abrir README completo')
        b.clicked.connect(lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(readme)))
        lay.addWidget(b)
        d.setStyleSheet(self.styleSheet())
        d.show()

    def _help_common(self):
        return ('<hr><p><b>Atajos:</b> Ctrl+R ejecutar paso · Ctrl+S guardar configuración · '
                'Ctrl+O cargar · Alt+←/→ navegar · Ctrl+L mostrar/ocultar registro · F1 ayuda.</p>'
                '<p>Los errores completos (traceback) quedan en <i>Ver → Paneles → Registro de '
                'mensajes → GeoMineral AI</i>.</p>')

    # ------------------------------------------------------------------ cierre
    def closeEvent(self, ev):
        if self.is_busy():
            self._worker.cancel()
            self._worker.wait(15000)        # el núcleo consulta la bandera de cancelación
        QgsSettings().setValue(SETTINGS + 'log_visible', self.btn_log.isChecked())
        self.save_settings()
        super(GeoMineralDialog, self).closeEvent(ev)

    def open_folder(self, path=None):
        path = path or self.page_by_key['config'].out_dir()
        if path and os.path.isdir(path):
            QDesktopServices.openUrl(QUrl.fromLocalFile(path))
