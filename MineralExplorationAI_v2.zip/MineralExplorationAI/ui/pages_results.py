# -*- coding: utf-8 -*-
"""Pasos 7-9: targets, validación y reportes."""
import datetime
import os
import tempfile

import numpy as np
from qgis.PyQt.QtCore import Qt, QSize, QUrl, QMarginsF
from qgis.PyQt.QtGui import QColor, QImage, QTextDocument, QPageSize, QPageLayout
from qgis.PyQt.QtWidgets import (QHBoxLayout, QGridLayout, QLabel, QDoubleSpinBox, QSpinBox,
                                 QSlider, QTableWidget, QHeaderView, QAbstractItemView,
                                 QPushButton, QCheckBox, QComboBox, QTextBrowser, QFileDialog)
from qgis.core import (QgsProject, QgsGeometry, QgsCoordinateReferenceSystem,
                       QgsCoordinateTransform, QgsVectorFileWriter, QgsMapSettings,
                       QgsMapRendererSequentialJob, QgsRectangle)

from ..compat import writer_ok
from ..core import targets as tgt_mod, validation as val_mod, advisor, report as rep
from ..core import indices as idx_mod
from .pages_data import BasePage, _ro
from .widgets import Card, KpiCard, ConfusionMatrix, HistogramWidget, muted
from .icons import icon
from . import layers as lyr

PRIO_COL = {1: '#e74c3c', 2: '#f39c12', 3: '#00b894'}


# =============================================================================
# 7. Targets
# =============================================================================

class TargetsPage(BasePage):
    key = 'targets'
    title = 'Targets'
    subtitle = 'Zonas de alta prospectividad clasificadas por prioridad'
    run_text = 'Generar targets'
    help_text = ('<p>Umbral sobre la prospectividad integrada → regiones 8-conexas → filtro de '
                 'área mínima (área real por latitud) → estadísticas zonales (máximo y media '
                 'sobre todos los píxeles del target).</p><p>Prioridad 1: máximo ≥ 0.80, o '
                 'media ≥ 0.70 con área ≥ 5 ha. Prioridad 2: máximo ≥ 0.65 o media ≥ 0.55. '
                 'Resto: prioridad 3.</p><p>Doble clic en una fila para acercar el mapa al target.</p>')

    def build(self):
        c = Card('Parámetros')
        self.sl = QSlider(Qt.Orientation.Horizontal)
        self.sl.setRange(0, 100)
        self.sl.setValue(60)
        self.sp_thr = QDoubleSpinBox()
        self.sp_thr.setRange(0, 1)
        self.sp_thr.setSingleStep(0.01)
        self.sp_thr.setValue(0.60)
        self.sl.valueChanged.connect(lambda v: self.sp_thr.setValue(v / 100.0))
        self.sp_thr.valueChanged.connect(lambda v: (self.sl.blockSignals(True), self.sl.setValue(int(round(v * 100))),
                                                    self.sl.blockSignals(False), self._area_hint()))
        self.sp_area = QDoubleSpinBox()
        self.sp_area.setRange(0.01, 100000)
        self.sp_area.setValue(1.0)
        self.sp_area.setSuffix(' ha')
        g = QGridLayout()
        g.addWidget(QLabel('Umbral de prospectividad'), 0, 0)
        g.addWidget(self.sl, 0, 1)
        g.addWidget(self.sp_thr, 0, 2)
        g.addWidget(QLabel('Área mínima'), 1, 0)
        g.addWidget(self.sp_area, 1, 2)
        g.setColumnStretch(1, 1)
        c.add(g)
        self.lbl_hint = muted('')
        c.add(self.lbl_hint)
        self.root.addWidget(c)

        k = QHBoxLayout()
        self.k_tot = KpiCard('Targets')
        self.k_p1 = KpiCard('Prioridad 1')
        self.k_p2 = KpiCard('Prioridad 2')
        self.k_p3 = KpiCard('Prioridad 3')
        self.k_area = KpiCard('Área total')
        for w in (self.k_tot, self.k_p1, self.k_p2, self.k_p3, self.k_area):
            k.addWidget(w)
        self.root.addLayout(k)

        c2 = Card('Tabla de targets')
        self.tbl = QTableWidget(0, 8)
        self.tbl.setHorizontalHeaderLabels(['ID', 'Prioridad', 'Máx', 'Media', 'Área (ha)',
                                            'Lon', 'Lat', 'Perímetro (m)'])
        self.tbl.verticalHeader().setVisible(False)
        self.tbl.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.tbl.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.tbl.setSortingEnabled(True)
        self.tbl.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.tbl.setMinimumHeight(260)
        self.tbl.cellDoubleClicked.connect(lambda r, _c: self.zoom(r))
        c2.add(self.tbl)
        self.b_zoom = QPushButton('Acercar al target')
        self.b_zoom.clicked.connect(lambda: self.zoom(self.tbl.currentRow()))
        self.b_csv = QPushButton('Exportar CSV')
        self.b_csv.clicked.connect(self.export_csv)
        self.b_dir = QPushButton('Abrir carpeta')
        self.b_dir.clicked.connect(lambda: self.dlg.open_folder(self.out('targets')))
        c2.add(self.hrow(self.b_zoom, self.b_csv, self.b_dir))
        self.root.addWidget(c2)

    def on_theme(self, pal):
        self.b_zoom.setIcon(icon('zoom', pal['text']))
        self.b_csv.setIcon(icon('download', pal['text']))
        self.b_dir.setIcon(icon('folder', pal['text']))

    def _area_hint(self):
        h = self.state.get('prosp_hist')
        if not h or not h[0]:
            return
        counts, edges = np.asarray(h[0], float), np.asarray(h[1], float)
        thr = self.sp_thr.value()
        frac = counts[edges[:-1] >= thr].sum() / max(1.0, counts.sum())
        self.lbl_hint.setText('Con este umbral queda sobre él aproximadamente el %.1f %% del área válida.'
                              % (100 * frac))

    def refresh(self):
        self._area_hint()

    def check(self):
        if not self.state.get('prosp_path'):
            return False, 'Calcule primero la prospectividad integrada (paso 6).'
        return True, ''

    def run(self):
        from ..core import raster_io as rio
        p = self.state['prosp_path']
        thr, area = self.sp_thr.value(), self.sp_area.value()
        out_dir = self.out('targets')

        def work(job):
            grid = rio.Grid.from_path(p)
            return tgt_mod.generate_targets(rio.read_band(p), grid, out_dir, thr, area,
                                            'Targets', job.progress, job.cancelled)

        def done(res):
            feats = res['features']
            self.state['targets'] = feats
            self.state['targets_out'] = res
            self.state['threshold'], self.state['min_area'] = thr, area
            self._fill(feats)
            if res.get('gpkg'):
                lyr.add_targets(res['gpkg'], 'Targets')
                self.dlg.log('OK', '%d targets → %s' % (len(feats), res['gpkg']))
            else:
                self.dlg.notify('Warning', 'Ningún target supera el umbral y el área mínima. '
                                           'Baje el umbral o el área mínima.')
            self.dlg.mark_done('validation', False)

        self.dlg.start(self, work, done, 'Generando targets (umbral %.2f)…' % thr)

    def _fill(self, feats):
        self.tbl.setSortingEnabled(False)
        self.tbl.setRowCount(0)
        for f in feats:
            r = self.tbl.rowCount()
            self.tbl.insertRow(r)
            vals = [f['target_id'], f['prioridad'].title(), f['score_max'], f['score_mean'],
                    f['area_ha'], f['lon'], f['lat'], f['perim_m']]
            for c, v in enumerate(vals):
                it = _ro(('%.4f' % v if c in (2, 3) else '%.6f' % v if c in (5, 6) else
                          '%.2f' % v if c == 4 else '%.0f' % v) if isinstance(v, float) else v)
                if isinstance(v, float):
                    it.setData(Qt.ItemDataRole.UserRole, v)
                if c == 1:
                    it.setForeground(QColor(PRIO_COL[f['prio_num']]))
                self.tbl.setItem(r, c, it)
        self.tbl.setSortingEnabled(True)
        n = [sum(1 for f in feats if f['prio_num'] == i) for i in (1, 2, 3)]
        self.k_tot.set(str(len(feats)))
        self.k_p1.set(str(n[0]), 'bad' if n[0] else None)
        self.k_p2.set(str(n[1]), 'warn' if n[1] else None)
        self.k_p3.set(str(n[2]), 'ok' if n[2] else None)
        self.k_area.set('%.1f ha' % sum(f['area_ha'] for f in feats))

    def zoom(self, row):
        if row < 0:
            return
        tid = self.tbl.item(row, 0).text()
        f = next((x for x in self.state.get('targets', []) if x['target_id'] == tid), None)
        grid = self.state.get('grid')
        if f is None or grid is None or self.dlg.iface is None:
            return
        canvas = self.dlg.iface.mapCanvas()
        geom = QgsGeometry.fromWkt(f['wkt'])
        src = QgsCoordinateReferenceSystem.fromWkt(grid.wkt)
        dst = canvas.mapSettings().destinationCrs()
        if src != dst:
            geom.transform(QgsCoordinateTransform(src, dst, QgsProject.instance()))
        box = geom.boundingBox()
        box.scale(2.5)
        canvas.setExtent(box)
        canvas.refresh()
        try:
            canvas.flashGeometries([geom], dst)
        except Exception:
            pass

    def export_csv(self):
        feats = self.state.get('targets')
        if not feats:
            self.dlg.notify('Warning', 'Genere primero los targets.')
            return
        path, _ = QFileDialog.getSaveFileName(self, 'Exportar CSV', self.out('targets', 'Targets.csv'),
                                              'CSV (*.csv)')
        if path:
            rep.export_csv(feats, path)
            self.dlg.notify('Success', 'CSV exportado: %s' % os.path.basename(path), 4)

    def save_settings(self):
        return {'thr': self.sp_thr.value(), 'area': self.sp_area.value()}

    def load_settings(self, d):
        self.sp_thr.setValue(float(d.get('thr', 0.6)))
        self.sp_area.setValue(float(d.get('area', 1.0)))


# =============================================================================
# 8. Validación
# =============================================================================

def export_layer_gpkg(layer):
    """Exporta cualquier capa vectorial (memoria, WFS, CSV...) a un GPKG temporal."""
    path = os.path.join(tempfile.mkdtemp(prefix='gmai_'), 'ocurrencias.gpkg')
    opts = QgsVectorFileWriter.SaveVectorOptions()
    opts.driverName = 'GPKG'
    opts.fileEncoding = 'UTF-8'
    res = QgsVectorFileWriter.writeAsVectorFormatV3(layer, path,
                                                    QgsProject.instance().transformContext(), opts)
    if not writer_ok(res[0]):
        raise RuntimeError('No se pudo exportar la capa de ocurrencias: %s' % res[1])
    return path


class ValidationPage(BasePage):
    key = 'validation'
    title = 'Validación'
    subtitle = 'Contraste de targets con ocurrencias conocidas'
    run_text = 'Validar targets'
    help_text = ('<p>Cada ocurrencia cuenta como acierto si está dentro de un target o a menos '
                 'del buffer de su <b>borde</b>. Se generan puntos de fondo aleatorios (pseudo-'
                 'negativos) lejos de las ocurrencias para construir la matriz de confusión y '
                 'calcular OA, Kappa de Cohen, precisión, recall y F1.</p><p>La <b>ganancia</b> '
                 'compara el % de ocurrencias capturadas con el % del área marcada como target '
                 '(1 = azar). Los pseudo-negativos pueden estar mineralizados: lea OA y Kappa como '
                 'comparaciones entre modelos, no como exactitud absoluta.</p>')

    def build(self):
        c = Card('Parámetros')
        self.lbl_occ = QLabel()
        self.sp_buf = QDoubleSpinBox()
        self.sp_buf.setRange(0, 10000)
        self.sp_buf.setValue(250)
        self.sp_buf.setSuffix(' m')
        self.sp_ratio = QDoubleSpinBox()
        self.sp_ratio.setRange(1, 50)
        self.sp_ratio.setValue(5)
        self.sp_ratio.setSuffix(' × ocurrencias')
        self.sp_seed = QSpinBox()
        self.sp_seed.setRange(0, 999999)
        self.sp_seed.setValue(42)
        g = QGridLayout()
        g.addWidget(QLabel('Ocurrencias'), 0, 0)
        g.addWidget(self.lbl_occ, 0, 1, 1, 3)
        g.addWidget(QLabel('Buffer de acierto'), 1, 0)
        g.addWidget(self.sp_buf, 1, 1)
        g.addWidget(QLabel('Puntos de fondo'), 1, 2)
        g.addWidget(self.sp_ratio, 1, 3)
        g.addWidget(QLabel('Semilla'), 2, 0)
        g.addWidget(self.sp_seed, 2, 1)
        g.setColumnStretch(1, 1)
        g.setColumnStretch(3, 1)
        c.add(g)
        self.root.addWidget(c)

        g2 = QGridLayout()
        self.k = {}
        for i, (key, lbl) in enumerate((('oa', 'Exactitud global (OA)'), ('kappa', 'Kappa'),
                                        ('f1', 'F1'), ('precision', 'Precisión'),
                                        ('success', 'Éxito (recall)'), ('gain', 'Ganancia vs azar'))):
            self.k[key] = KpiCard(lbl)
            g2.addWidget(self.k[key], i // 3, i % 3)
        self.root.addLayout(g2)

        c2 = Card('Matriz de confusión')
        self.cm = ConfusionMatrix()
        c2.add(self.cm)
        self.lbl_interp = muted('')
        c2.add(self.lbl_interp)
        self.root.addWidget(c2)
        c3 = Card('Ocurrencias')
        self.tbl = QTableWidget(0, 5)
        self.tbl.setHorizontalHeaderLabels(['Ocurrencia', 'Target más cercano', 'Prioridad', 'Distancia (m)', 'Acierto'])
        self.tbl.verticalHeader().setVisible(False)
        self.tbl.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.tbl.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.tbl.setMinimumHeight(220)
        c3.add(self.tbl)
        self.root.addWidget(c3)

    def refresh(self):
        l = self.cfg().cb_occ.currentLayer()
        self.lbl_occ.setText(('%s (%d puntos)' % (l.name(), l.featureCount())) if l else
                             'Seleccione la capa de ocurrencias en el paso 1')

    def check(self):
        if not (self.state.get('targets_out') or {}).get('gpkg'):
            return False, 'Genere primero los targets (paso 7).'
        if self.cfg().cb_occ.currentLayer() is None:
            return False, 'Seleccione la capa de ocurrencias conocidas en el paso 1.'
        return True, ''

    def run(self):
        occ = export_layer_gpkg(self.cfg().cb_occ.currentLayer())   # hilo principal
        t = self.state['targets_out']
        prosp = self.state['prosp_path']
        buf, ratio, seed = self.sp_buf.value(), self.sp_ratio.value(), self.sp_seed.value()

        def work(job):
            return val_mod.validate(t['gpkg'], occ, prosp, buf, ratio, seed, t.get('label_path'),
                                    job.progress)

        def done(res):
            rows, m = res
            self.state['val_rows'], self.state['metrics'] = rows, m
            pal = self.dlg.pal

            def tone(v, good, mid):
                return 'ok' if v >= good else ('warn' if v >= mid else 'bad')
            self.k['oa'].set('%.3f' % m['oa'], tone(m['oa'], 0.8, 0.6))
            self.k['kappa'].set('%.3f' % m['kappa'], tone(m['kappa'], 0.6, 0.4))
            self.k['f1'].set('%.3f' % m['f1'], tone(m['f1'], 0.7, 0.5))
            self.k['precision'].set('%.3f' % m['precision'], tone(m['precision'], 0.7, 0.5))
            self.k['success'].set('%.0f %%' % m['success_pct'], tone(m['success_pct'], 70, 40))
            self.k['gain'].set(('×%.1f' % m['gain']) if m.get('gain') else '—',
                               tone(m.get('gain') or 0, 5, 2))
            self.cm.set_values(m, pal)
            txt = val_mod.interpret(m)
            self.state['validation_text'] = txt
            self.lbl_interp.setText(txt)
            self.tbl.setRowCount(0)
            for r in rows:
                i = self.tbl.rowCount()
                self.tbl.insertRow(i)
                for c, v in enumerate([r['occ_id'], r['target'], str(r['prioridad']).title(), '%.0f' % r['dist_m'],
                                       'Sí' if r['hit'] else 'No']):
                    it = _ro(v)
                    if c == 4:
                        it.setForeground(QColor(pal['ok'] if r['hit'] else pal['err']))
                    self.tbl.setItem(i, c, it)
            self.dlg.log('OK', txt)

        self.dlg.start(self, work, done, 'Validando targets…')

    def save_settings(self):
        return {'buf': self.sp_buf.value(), 'ratio': self.sp_ratio.value(), 'seed': self.sp_seed.value()}

    def load_settings(self, d):
        self.sp_buf.setValue(float(d.get('buf', 250)))
        self.sp_ratio.setValue(float(d.get('ratio', 5)))
        self.sp_seed.setValue(int(d.get('seed', 42)))


# =============================================================================
# 9. Reportes
# =============================================================================

class ReportsPage(BasePage):
    key = 'reports'
    title = 'Reportes'
    subtitle = 'Reporte técnico PDF/HTML y exportaciones'
    run_text = 'Generar PDF'
    help_text = ('<p>El PDF se genera con el motor de impresión de Qt (no requiere ReportLab). '
                 'Incluye capturas de mapa renderizadas con la simbología del plugin, tablas de '
                 'índices, targets, validación y recomendaciones por prioridad.</p>')

    def build(self):
        row = QHBoxLayout()
        c = Card('Secciones del reporte')
        self.chk = {}
        g = QGridLayout()
        for i, (k, lbl) in enumerate(rep.SECTIONS):
            cb = QCheckBox(lbl)
            cb.setChecked(True)
            self.chk[k] = cb
            g.addWidget(cb, i // 2, i % 2)
        c.add(g)
        row.addWidget(c, 3)
        c2 = Card('Plantilla y exportación')
        self.cmb_tpl = QComboBox()
        self.cmb_tpl.addItem('Técnico completo', 'complete')
        self.cmb_tpl.addItem('Ejecutivo (resumen)', 'executive')
        self.chk_maps = QCheckBox('Incluir capturas de mapa')
        self.chk_maps.setChecked(True)
        c2.add(self.cmb_tpl)
        c2.add(self.chk_maps)
        self.b_html = QPushButton('Exportar HTML')
        self.b_html.clicked.connect(lambda: self.generate('html'))
        self.b_csv = QPushButton('Exportar CSV de targets')
        self.b_csv.clicked.connect(lambda: self.dlg.page_by_key['targets'].export_csv())
        self.b_dir = QPushButton('Abrir carpeta de salida')
        self.b_dir.clicked.connect(lambda: self.dlg.open_folder())
        for b in (self.b_html, self.b_csv, self.b_dir):
            c2.add(b)
        self.lbl_out = muted('')
        c2.add(self.lbl_out)
        row.addWidget(c2, 2)
        self.root.addLayout(row)

        c3 = Card('Recomendaciones', 'Generadas a partir de la prioridad de cada target y la validación.')
        self.txt = QTextBrowser()
        self.txt.setMinimumHeight(260)
        c3.add(self.txt)
        self.root.addWidget(c3)

    def on_theme(self, pal):
        self.b_html.setIcon(icon('download', pal['text']))
        self.b_csv.setIcon(icon('download', pal['text']))
        self.b_dir.setIcon(icon('folder', pal['text']))

    def refresh(self):
        t = self.state.get('targets') or []
        if not t:
            self.txt.setHtml('<p>Genere los targets (paso 7) para ver las recomendaciones.</p>')
            return
        recs = advisor.recommendations(t, self.state.get('metrics'))
        self.state['recs'] = recs
        parts = []
        for r in recs[:30]:
            parts.append('<p><b style="color:%s">%s · %s</b> — máx %.3f · %.1f ha · %.5f, %.5f<br>'
                         '<span>Confianza: %s</span><br>%s</p>'
                         % (PRIO_COL[int(r['prioridad'][-1])], r['target_id'], r['prioridad'].title(),
                            r['score_max'], r['area_ha'], r['lon'], r['lat'], r['confianza'],
                            '<br>'.join('%d. %s' % (i + 1, f) for i, f in enumerate(r['fases']))))
        self.txt.setHtml(''.join(parts))

    def check(self):
        if not self.state.get('targets'):
            return False, 'Genere primero los targets (paso 7).'
        return True, ''

    def run(self):
        self.generate('pdf')

    # ---------------------------------------------------------------- imágenes
    def _render_map(self, layers, path, width=1500):
        layers = [l for l in layers if l is not None]
        if not layers:
            return None
        ms = QgsMapSettings()
        ms.setLayers(layers)
        ref = layers[-1]
        ms.setDestinationCrs(ref.crs())
        ext = QgsRectangle(ref.extent())
        ext.scale(1.03)
        h = int(width * ext.height() / max(1e-9, ext.width()))
        ms.setOutputSize(QSize(width, max(200, min(h, 2 * width))))
        ms.setExtent(ext)
        ms.setBackgroundColor(QColor('#ffffff'))
        job = QgsMapRendererSequentialJob(ms)
        job.start()
        job.waitForFinished()
        job.renderedImage().save(path, 'PNG')
        return path

    def _images(self, tmp):
        imgs = {}
        s = self.state
        if self.chk_maps.isChecked():
            if s.get('prosp_path'):
                prosp = lyr.styled_raster(s['prosp_path'], 'Prospectividad', 'fav')
                tg = lyr.styled_targets(s['targets_out']['gpkg']) if (s.get('targets_out') or {}).get('gpkg') else None
                imgs['map_prosp'] = self._render_map([tg, prosp], os.path.join(tmp, 'map_prosp.png'))
            km = s.get('kmeans')
            if km and os.path.exists(km['path']):
                from qgis.core import QgsRasterLayer, QgsPalettedRasterRenderer
                cl = QgsRasterLayer(km['path'], 'Clusters', 'gdal')
                classes = [QgsPalettedRasterRenderer.Class(i, QColor(*km['palette'][i]), 'C%d' % (i + 1))
                           for i in range(km['k'])]
                cl.setRenderer(QgsPalettedRasterRenderer(cl.dataProvider(), 1, classes))
                imgs['map_clusters'] = self._render_map([cl], os.path.join(tmp, 'map_clusters.png'))
        h = s.get('prosp_hist')
        if h and h[0]:
            w = HistogramWidget()
            w.set_theme({'muted': '#5c6370'})
            w.set_data(h[0], h[1], 'Prospectividad integrada', '#f39c12')
            w.set_cuts(s.get('threshold'), None)
            w.resize(900, 280)
            p = os.path.join(tmp, 'hist_prosp.png')
            w.grab().save(p, 'PNG')
            imgs['hist_prosp'] = p
        return imgs

    # ---------------------------------------------------------------- generación
    def _context(self, imgs):
        s = self.state
        cfg = self.cfg()
        rad = cfg.radiometry()
        return {
            'project': cfg.ed_project.text(), 'analyst': cfg.ed_analyst.text() or '—',
            'date': datetime.datetime.now().strftime('%d/%m/%Y %H:%M'),
            'image_name': cfg.image_name(), 'model': s.get('model', '—'),
            'threshold': s.get('threshold', '—'), 'min_area': s.get('min_area', '—'),
            'indices_used': list((s.get('idx_raw') or {}).keys()),
            'data_note': 'Unidades de entrada: %s; calibración: %s; fecha %s. TIR 90 m remuestreado '
                         'a 30 m (bilineal), VNIR 15 m a 30 m (promedio).'
                         % (rad['units'], rad['calibrate_to'] or 'ninguna', rad['acq_date']),
            'weights': s.get('weights') or {}, 'w_integration': s.get('w_integration') or {},
            'kmeans': s.get('kmeans'), 'targets': s.get('targets') or [],
            'metrics': s.get('metrics'), 'validation_text': s.get('validation_text', ''),
            'recs': advisor.recommendations(s.get('targets') or [], s.get('metrics')),
            'images': imgs,
        }

    def generate(self, fmt='pdf'):
        ok, msg = self.check()
        if not ok:
            self.dlg.notify('Warning', msg)
            return
        self.dlg.progress.setValue(10)
        self.dlg.lbl_status.setText('Renderizando mapas…')
        tmp = tempfile.mkdtemp(prefix='gmai_rep_')
        imgs = self._images(tmp)
        self.dlg.progress.setValue(50)
        sections = [k for k, cb in self.chk.items() if cb.isChecked()]
        html_text, imgs = rep.build_report(self._context(imgs), sections, self.cmb_tpl.currentData())
        stamp = datetime.datetime.now().strftime('%Y%m%d_%H%M')
        name = '%s_%s' % (self.cfg().ed_project.text().strip().replace(' ', '_') or 'GeoMineralAI', stamp)
        if fmt == 'html':
            path = rep.export_html(html_text, imgs, self.out('reportes', name + '.html'))
        else:
            path = self.out('reportes', name + '.pdf')
            self._print_pdf(html_text, imgs, path)
        self.dlg.progress.setValue(100)
        self.dlg.lbl_status.setText('Listo')
        self.lbl_out.setText(path)
        self.state['report_path'] = path
        self.dlg.mark_done('reports')
        self.dlg.log('OK', 'Reporte %s generado: %s' % (fmt.upper(), path))
        self.dlg.notify('Success', 'Reporte generado: %s' % os.path.basename(path), 6)
        return path

    def _print_pdf(self, html_text, imgs, path):
        from qgis.PyQt.QtPrintSupport import QPrinter
        doc = QTextDocument()
        for k, p in imgs.items():
            doc.addResource(QTextDocument.ResourceType.ImageResource, QUrl('res://%s' % k), QImage(p))
        doc.setHtml(html_text)
        pr = QPrinter(QPrinter.PrinterMode.HighResolution)
        pr.setOutputFormat(QPrinter.OutputFormat.PdfFormat)
        pr.setOutputFileName(path)
        # setPageLayout tiene la misma firma en Qt5 y Qt6 (setPageMargins no)
        pr.setPageLayout(QPageLayout(QPageSize(QPageSize.PageSizeId.A4),
                                     QPageLayout.Orientation.Portrait,
                                     QMarginsF(16, 16, 16, 16), QPageLayout.Unit.Millimeter))
        pr.setDocName('GeoMineral AI')
        if hasattr(doc, 'print_'):
            doc.print_(pr)
        else:
            doc.print(pr)

    def save_settings(self):
        return {'sections': {k: cb.isChecked() for k, cb in self.chk.items()},
                'template': self.cmb_tpl.currentIndex(), 'maps': self.chk_maps.isChecked()}

    def load_settings(self, d):
        for k, v in (d.get('sections') or {}).items():
            if k in self.chk:
                self.chk[k].setChecked(bool(v))
        self.cmb_tpl.setCurrentIndex(int(d.get('template', 0)))
        self.chk_maps.setChecked(bool(d.get('maps', True)))
