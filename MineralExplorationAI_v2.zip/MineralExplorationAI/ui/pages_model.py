# -*- coding: utf-8 -*-
"""Pasos 4-6: K-Means, favorabilidad mineral y prospectividad integrada."""
import os

import numpy as np
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QColor
from qgis.PyQt.QtWidgets import (QHBoxLayout, QGridLayout, QLabel, QSpinBox, QDoubleSpinBox,
                                 QComboBox, QCheckBox, QTableWidget, QHeaderView, QPushButton,
                                 QAbstractItemView, QWidget)
from qgis.gui import QgsMapLayerComboBox

from ..compat import RASTER
from ..core import (kmeans as km_mod, advisor, prospectivity as prosp, raster_io as rio,
                    normalize as norm_mod, structural, indices as idx_mod)
from .pages_data import BasePage, _ro, _layer_path
from .widgets import (Card, KpiCard, BarChartWidget, HistogramWidget, ColorButton, WeightBar,
                      muted)
from . import layers as lyr


# =============================================================================
# 4. K-Means
# =============================================================================

class KMeansPage(BasePage):
    key = 'kmeans'
    title = 'K-Means'
    subtitle = 'Clasificación no supervisada del stack de índices'
    run_text = 'Ejecutar K-Means'
    help_text = ('<p>Las bandas se estandarizan (media 0, desviación 1). El modelo se ajusta '
                 'sobre una muestra aleatoria y luego se asignan todos los píxeles por bloques, '
                 'lo que permite escenas completas.</p><p>La interpretación de cada cluster se '
                 'basa en su <b>firma</b>: qué índices tiene anómalos respecto al resto '
                 '(puntaje z del centroide). v1 los interpretaba solo por tamaño.</p>'
                 '<p>Si scikit-learn no está instalado se usa una implementación NumPy '
                 'equivalente (Lloyd + k-means++).</p>')

    def build(self):
        c = Card('Parámetros')
        g = QGridLayout()
        self.sp_k = QSpinBox()
        self.sp_k.setRange(2, 20)
        self.sp_k.setValue(8)
        self.cmb_init = QComboBox()
        self.cmb_init.addItem('k-means++ (recomendado)', 'k-means++')
        self.cmb_init.addItem('Aleatoria', 'random')
        self.sp_iter = QSpinBox()
        self.sp_iter.setRange(10, 2000)
        self.sp_iter.setValue(300)
        self.sp_seed = QSpinBox()
        self.sp_seed.setRange(0, 999999)
        self.sp_seed.setValue(42)
        self.sp_sample = QSpinBox()
        self.sp_sample.setRange(10000, 5000000)
        self.sp_sample.setSingleStep(50000)
        self.sp_sample.setValue(200000)
        self.sp_sample.setSuffix(' px')
        for r, (lbl, w) in enumerate((('Número de clusters', self.sp_k), ('Inicialización', self.cmb_init),
                                      ('Iteraciones máximas', self.sp_iter))):
            g.addWidget(QLabel(lbl), r, 0)
            g.addWidget(w, r, 1)
        for r, (lbl, w) in enumerate((('Semilla', self.sp_seed), ('Muestra de ajuste', self.sp_sample))):
            g.addWidget(QLabel(lbl), r, 2)
            g.addWidget(w, r, 3)
        g.setColumnStretch(1, 1)
        g.setColumnStretch(3, 1)
        c.add(g)
        c.add(muted('Motor: ' + ('scikit-learn' if km_mod.SKLEARN else
                                 'NumPy (scikit-learn no instalado; resultados equivalentes)')))
        self.root.addWidget(c)

        c2 = Card('Distribución de clusters')
        self.chart = BarChartWidget()
        c2.add(self.chart)
        self.root.addWidget(c2)
        c3 = Card('Interpretación por firma espectral')
        self.tbl = QTableWidget(0, 5)
        self.tbl.setHorizontalHeaderLabels(['Cluster', '%', 'Interpretación', 'Relevancia', 'Índices dominantes'])
        self.tbl.verticalHeader().setVisible(False)
        self.tbl.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        hh = self.tbl.horizontalHeader()
        for i in (0, 1, 3):
            hh.setSectionResizeMode(i, QHeaderView.ResizeMode.ResizeToContents)
        hh.setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        hh.setSectionResizeMode(4, QHeaderView.ResizeMode.Stretch)
        self.tbl.setWordWrap(True)
        self.tbl.setMinimumHeight(260)
        c3.add(self.tbl)
        self.root.addWidget(c3)

    def on_theme(self, pal):
        self.chart.set_theme(pal)

    def check(self):
        if not self.state.get('stack_path'):
            return False, 'Cree primero el stack (paso 3).'
        return True, ''

    def run(self):
        path = self.state['stack_path']
        names = self.state['stack_names']
        k, init, it, seed, smp = (self.sp_k.value(), self.cmb_init.currentData(), self.sp_iter.value(),
                                  self.sp_seed.value(), self.sp_sample.value())
        out = self.out('Clusters_KMeans.tif')

        def work(job):
            st, _names, grid = rio.read_stack(path)
            job.progress(5, 'Stack leído: %d bandas, %d×%d' % (st.shape[0], grid.width, grid.height))
            res = km_mod.run_kmeans(st, k, init, it, seed, smp, job.progress, job.cancelled)
            rio.write_int(out, res['labels'], grid, nodata=-1, description='cluster')
            res['interp'] = advisor.interpret_clusters(res['centers'], names, res['counts'])
            res['path'] = out
            del res['labels']
            return res

        def done(res):
            pal = km_mod.palette(k)
            self.state['kmeans'] = {'k': k, 'init': init, 'backend': res['backend'],
                                    'interp': res['interp'], 'path': out, 'palette': pal}
            items = []
            self.tbl.setRowCount(0)
            for i, (ci, pct) in enumerate(zip(res['interp'], res['pct'])):
                items.append(('C%d' % (i + 1), float(pct), QColor(*pal[i]), '%.1f %%' % pct))
                r = self.tbl.rowCount()
                self.tbl.insertRow(r)
                c0 = _ro('C%d' % (i + 1))
                c0.setBackground(QColor(*pal[i]))
                c0.setForeground(QColor('#1e2229'))
                self.tbl.setItem(r, 0, c0)
                self.tbl.setItem(r, 1, _ro('%.1f' % pct))
                lab = _ro(ci['label'])
                lab.setToolTip(ci['label'])
                self.tbl.setItem(r, 2, lab)
                rel = _ro(ci['relevancia'])
                rel.setForeground(QColor({'ALTA': self.dlg.pal['err'], 'MEDIA': self.dlg.pal['accent']}
                                         .get(ci['relevancia'], self.dlg.pal['muted'])))
                self.tbl.setItem(r, 3, rel)
                top = _ro(ci['top'])
                top.setToolTip(ci['top'])
                self.tbl.setItem(r, 4, top)
            self.tbl.resizeRowsToContents()
            self.chart.set_items(items)
            labels = ['C%d · %s' % (i + 1, ci['label']) for i, ci in enumerate(res['interp'])]
            lyr.add_clusters(out, 'Clusters K-Means', pal, labels)
            self.dlg.log('OK', 'K-Means (%s): %d clusters, inercia %.3g.'
                         % (res['backend'], k, res['inertia']))

        self.dlg.start(self, work, done, 'Ejecutando K-Means (%d clusters)…' % k)

    def save_settings(self):
        return {'k': self.sp_k.value(), 'init': self.cmb_init.currentIndex(), 'iter': self.sp_iter.value(),
                'seed': self.sp_seed.value(), 'sample': self.sp_sample.value()}

    def load_settings(self, d):
        self.sp_k.setValue(int(d.get('k', 8)))
        self.cmb_init.setCurrentIndex(int(d.get('init', 0)))
        self.sp_iter.setValue(int(d.get('iter', 300)))
        self.sp_seed.setValue(int(d.get('seed', 42)))
        self.sp_sample.setValue(int(d.get('sample', 200000)))


# =============================================================================
# 5. Favorabilidad mineral
# =============================================================================

class MineralFavPage(BasePage):
    key = 'mineral'
    title = 'Fav. mineral'
    subtitle = 'Suma ponderada de índices según el modelo de depósito'
    run_text = 'Calcular favorabilidad'
    help_text = ('<p>F = Σ wᵢ·xᵢ / Σ wᵢ con los índices normalizados del paso 2. Los pesos se '
                 're-normalizan automáticamente a suma 1. <b>Estricto</b>: NaN si falta alguna '
                 'evidencia; desactivado: promedio sobre las evidencias disponibles.</p>'
                 '<p>Los modelos predefinidos siguen la zonación de Corbett & Leach (1998) y '
                 'Sillitoe (2010) y son de criterio experto: calíbrelos con ocurrencias locales.</p>')

    def build(self):
        c = Card('Modelo')
        self.cmb_preset = QComboBox()
        for key, p in prosp.PRESETS.items():
            self.cmb_preset.addItem(p['label'], key)
        self.cmb_preset.addItem('Personalizado', 'custom')
        self.cmb_preset.currentIndexChanged.connect(self._apply_preset)
        self.chk_strict = QCheckBox('Estricto (NaN si falta una evidencia)')
        self.chk_strict.setChecked(False)
        c.add(self.hrow(QLabel('Modelo de depósito'), self.cmb_preset, self.chk_strict))
        self.root.addWidget(c)

        c2 = Card('Índices y pesos', 'Active/desactive índices, ajuste el peso y el color de cada uno.')
        self.tbl = QTableWidget(0, 6)
        self.tbl.setHorizontalHeaderLabels(['Usar', 'Color', 'Índice', 'Fórmula', 'Peso', 'Peso relativo'])
        self.tbl.verticalHeader().setVisible(False)
        self.tbl.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection)
        hh = self.tbl.horizontalHeader()
        for i in (0, 1, 3, 4):
            hh.setSectionResizeMode(i, QHeaderView.ResizeMode.ResizeToContents)
        hh.setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        hh.setSectionResizeMode(5, QHeaderView.ResizeMode.Stretch)
        self.tbl.setMinimumHeight(300)
        c2.add(self.tbl)
        self.lbl_sum = muted('')
        c2.add(self.lbl_sum)
        self.root.addWidget(c2)
        self.rows = {}

        c3 = Card('Resultado')
        k = QHBoxLayout()
        self.k_mean = KpiCard('Media')
        self.k_p90 = KpiCard('Percentil 90')
        self.k_high = KpiCard('Área > 0.70')
        self.k_n = KpiCard('Píxeles válidos')
        for w in (self.k_mean, self.k_p90, self.k_high, self.k_n):
            k.addWidget(w)
        c3.add(k)
        self.root.addWidget(c3)

    def refresh(self):
        keys = [k for k in (self.state.get('idx_norm') or {}) if k != 'ndvi']
        if set(keys) == set(self.rows):
            return
        saved = {k: (r['chk'].isChecked(), r['w'].value()) for k, r in self.rows.items()}
        self.tbl.setRowCount(0)
        self.rows = {}
        colors = self.state.setdefault('colors', {})
        for k in keys:
            d = idx_mod.INDEX_BY_KEY[k]
            r = self.tbl.rowCount()
            self.tbl.insertRow(r)
            chk = QCheckBox()
            cw = QWidget()
            cl = QHBoxLayout(cw)
            cl.setContentsMargins(6, 0, 0, 0)
            cl.addWidget(chk)
            color = ColorButton(colors.get(k, d.color))
            color.colorChanged.connect(lambda c, kk=k: colors.__setitem__(kk, c))
            w = QDoubleSpinBox()
            w.setRange(0, 1)
            w.setSingleStep(0.05)
            w.setDecimals(2)
            bar = WeightBar()
            self.tbl.setCellWidget(r, 0, cw)
            self.tbl.setCellWidget(r, 1, color)
            it = _ro(d.name_es)
            it.setToolTip(d.tooltip())
            self.tbl.setItem(r, 2, it)
            f = _ro(d.formula)
            f.setToolTip(d.tooltip())
            self.tbl.setItem(r, 3, f)
            self.tbl.setCellWidget(r, 4, w)
            self.tbl.setCellWidget(r, 5, bar)
            self.rows[k] = {'chk': chk, 'w': w, 'bar': bar, 'color': color}
            chk.toggled.connect(self._weights_changed)
            w.valueChanged.connect(self._on_manual)
        if saved:
            self._loading = True
            for k, (on, v) in saved.items():
                if k in self.rows:
                    self.rows[k]['chk'].setChecked(on)
                    self.rows[k]['w'].setValue(v)
            self._loading = False
        else:
            self._apply_preset()
        self._weights_changed()

    def _apply_preset(self):
        key = self.cmb_preset.currentData()
        if key == 'custom' or key not in prosp.PRESETS:
            return
        w = prosp.PRESETS[key]['weights']
        self._loading = True
        for k, r in self.rows.items():
            r['chk'].setChecked(k in w)
            r['w'].setValue(w.get(k, 0.0))
        self._loading = False
        self._weights_changed()

    def _on_manual(self):
        if not getattr(self, '_loading', False):
            idx = self.cmb_preset.findData('custom')
            self.cmb_preset.blockSignals(True)
            self.cmb_preset.setCurrentIndex(idx)
            self.cmb_preset.blockSignals(False)
        self._weights_changed()

    def weights(self):
        return {k: r['w'].value() for k, r in self.rows.items() if r['chk'].isChecked() and r['w'].value() > 0}

    def _weights_changed(self):
        w = self.weights()
        tot = sum(w.values())
        for k, r in self.rows.items():
            r['bar'].set_fraction(w.get(k, 0) / tot if tot else 0)
            r['w'].setEnabled(r['chk'].isChecked())
        missing = [k for k in (prosp.PRESETS.get(self.cmb_preset.currentData(), {}).get('weights') or {})
                   if k not in self.rows]
        txt = 'Σ pesos = %.2f → se re-normaliza a 1.00 · %d evidencias' % (tot, len(w))
        if missing:
            txt += ' · índices del modelo no calculados: ' + ', '.join(missing)
        self.lbl_sum.setText(txt)

    def check(self):
        if not self.state.get('idx_norm'):
            return False, 'Calcule primero los índices (paso 2).'
        if not self.weights():
            return False, 'Active al menos un índice con peso mayor que cero.'
        return True, ''

    def run(self):
        w = self.weights()
        norm = self.state['idx_norm']
        grid = self.state['grid']
        strict = self.chk_strict.isChecked()
        path = self.out('Favorabilidad_Mineral.tif')

        def work(job):
            layers = []
            for n, (k, v) in enumerate(w.items()):
                job.progress(int(80 * n / len(w)), 'Leyendo ' + k)
                layers.append((rio.read_band(norm[k]), v))
            f = prosp.weighted_overlay(layers, strict)
            rio.write_float(path, f, grid, 'favorabilidad_mineral')
            return prosp.stats(f)

        def done(s):
            self.state['fav_path'] = path
            self.state['weights'] = w
            self.state['model'] = self.cmb_preset.currentText()
            self.k_mean.set('%.3f' % s['mean'])
            self.k_p90.set('%.3f' % s['p90'])
            self.k_high.set('%.1f %%' % s['high_pct'], 'warn' if s['high_pct'] > 15 else 'ok')
            self.k_n.set('{:,}'.format(s['n']))
            lyr.add_raster(path, 'Favorabilidad mineral', 'fav')
            self.dlg.log('OK', 'Favorabilidad mineral: media %.3f, P90 %.3f.' % (s['mean'], s['p90']))
            for key in ('integrated', 'targets', 'validation'):
                self.dlg.mark_done(key, False)

        self.dlg.start(self, work, done, 'Calculando favorabilidad mineral…')

    def save_settings(self):
        return {'preset': self.cmb_preset.currentData(), 'strict': self.chk_strict.isChecked(),
                'weights': {k: [r['chk'].isChecked(), r['w'].value()] for k, r in self.rows.items()},
                'colors': self.state.get('colors', {})}

    def load_settings(self, d):
        i = self.cmb_preset.findData(d.get('preset', 'epitermal_as'))
        if i >= 0:
            self.cmb_preset.setCurrentIndex(i)
        self.chk_strict.setChecked(bool(d.get('strict', False)))
        self.state.setdefault('colors', {}).update(d.get('colors') or {})


# =============================================================================
# 6. Prospectividad integrada
# =============================================================================

class IntegratedPage(BasePage):
    key = 'integrated'
    title = 'Prosp. integrada'
    subtitle = 'Integración de evidencia mineral y estructural'
    run_text = 'Calcular prospectividad'
    help_text = ('<p>La evidencia estructural se deriva del DEM: derivadas direccionales Sobel '
                 'en 4 azimuts, bordes sobre un percentil y densidad en una ventana circular '
                 '(radio en metros). La pendiente usa el tamaño real del píxel en metros.</p>'
                 '<p>Puede añadir otras evidencias raster (geoquímica, geofísica); todas se '
                 'alinean con GDAL a la grilla de trabajo y se normalizan por percentiles.</p>')

    def build(self):
        c = Card('Evidencias', 'Pesos editables; la barra muestra la contribución relativa.')
        self.grid = QGridLayout()
        self.grid.setHorizontalSpacing(10)
        for col, h in enumerate(['Usar', 'Evidencia', 'Fuente', 'Peso', 'Peso relativo']):
            l = QLabel(h)
            l.setObjectName('KpiLabel')
            self.grid.addWidget(l, 0, col)
        self.ev = []
        self._add_row('Favorabilidad mineral', 'Paso 5', 0.60, fixed='mineral')
        self._add_row('Densidad de lineamientos (DEM)', 'DEM del paso 1', 0.40, fixed='struct')
        c.add(self.grid)
        self.cb_extra = QgsMapLayerComboBox()
        self.cb_extra.setFilters(RASTER)
        self.cb_extra.setAllowEmptyLayer(True)
        self.cb_extra.setLayer(None)
        b = QPushButton('Añadir evidencia')
        b.clicked.connect(self._add_extra)
        c.add(self.hrow(QLabel('Otra evidencia raster'), self.cb_extra, b))
        self.root.addWidget(c)

        c2 = Card('Parámetros estructurales')
        self.sp_edge = QDoubleSpinBox()
        self.sp_edge.setRange(50, 99)
        self.sp_edge.setValue(85)
        self.sp_edge.setSuffix(' percentil')
        self.sp_rad = QDoubleSpinBox()
        self.sp_rad.setRange(30, 5000)
        self.sp_rad.setValue(500)
        self.sp_rad.setSuffix(' m')
        c2.add(self.hrow(QLabel('Umbral de borde'), self.sp_edge, QLabel('Radio de densidad'), self.sp_rad))
        self.root.addWidget(c2)

        row = QHBoxLayout()
        c3 = Card('Distribución de prospectividad')
        self.hist = HistogramWidget()
        c3.add(self.hist)
        row.addWidget(c3, 3)
        c4 = Card('Resultado')
        g = QGridLayout()
        self.k_mean = KpiCard('Media')
        self.k_max = KpiCard('Máximo')
        self.k_high = KpiCard('Área > 0.70')
        self.k_mid = KpiCard('Área 0.50–0.70')
        for i, w in enumerate((self.k_mean, self.k_max, self.k_high, self.k_mid)):
            g.addWidget(w, i // 2, i % 2)
        c4.add(g)
        row.addWidget(c4, 2)
        self.root.addLayout(row)

    def _add_row(self, name, source, weight, fixed=None, layer=None):
        r = len(self.ev) + 1
        chk = QCheckBox()
        chk.setChecked(True)
        sp = QDoubleSpinBox()
        sp.setRange(0, 1)
        sp.setSingleStep(0.05)
        sp.setValue(weight)
        bar = WeightBar()
        self.grid.addWidget(chk, r, 0)
        self.grid.addWidget(QLabel(name), r, 1)
        self.grid.addWidget(muted(source, False), r, 2)
        self.grid.addWidget(sp, r, 3)
        self.grid.addWidget(bar, r, 4)
        self.grid.setColumnStretch(4, 1)
        self.ev.append({'name': name, 'chk': chk, 'w': sp, 'bar': bar, 'fixed': fixed, 'layer': layer})
        chk.toggled.connect(self._bars)
        sp.valueChanged.connect(self._bars)
        self._bars()

    def _add_extra(self):
        l = self.cb_extra.currentLayer()
        p = _layer_path(l)
        if not p:
            self.dlg.notify('Warning', 'Seleccione una capa raster basada en archivo (GDAL).')
            return
        self._add_row(l.name(), os.path.basename(p), 0.2, layer=p)

    def _bars(self):
        tot = sum(e['w'].value() for e in self.ev if e['chk'].isChecked())
        for e in self.ev:
            e['bar'].set_fraction(e['w'].value() / tot if tot and e['chk'].isChecked() else 0)

    def on_theme(self, pal):
        self.hist.set_theme(pal)

    def check(self):
        if not self.state.get('fav_path'):
            return False, 'Calcule primero la favorabilidad mineral (paso 5).'
        struct = next(e for e in self.ev if e['fixed'] == 'struct')
        if struct['chk'].isChecked() and not self.cfg().dem_path():
            return False, 'Seleccione un DEM en el paso 1 o desactive la evidencia estructural.'
        if not any(e['chk'].isChecked() and e['w'].value() > 0 for e in self.ev):
            return False, 'Active al menos una evidencia con peso > 0.'
        return True, ''

    def run(self):
        grid = self.state['grid']
        fav = self.state['fav_path']
        dem = self.cfg().dem_path()
        edge, rad = self.sp_edge.value(), self.sp_rad.value()
        evs = [(e['fixed'], e['layer'], e['name'], e['w'].value()) for e in self.ev
               if e['chk'].isChecked() and e['w'].value() > 0]
        p_out = self.out('Prospectividad_Integrada.tif')
        p_struct = self.out('Favorabilidad_Estructural.tif')
        p_slope = self.out('Pendiente_grados.tif')

        def work(job):
            layers, used = [], {}
            fav_arr = rio.read_band(fav)
            mineral_mask = np.isfinite(fav_arr)
            for fixed, path, name, w in evs:
                if fixed == 'mineral':
                    layers.append((fav_arr, w))
                elif fixed == 'struct':
                    job.progress(15, 'Alineando DEM a la grilla de trabajo')
                    d = rio.warp_band_to_grid(dem, 1, grid, 'bilinear')
                    rio.write_float(p_slope, structural.slope_deg(d, grid), grid, 'pendiente_grados')
                    job.progress(35, 'Densidad de lineamientos')
                    dens, _e = structural.lineament_density(d, grid, edge, rad)
                    s = norm_mod.normalize(dens, 'percentile', 2, 98)
                    rio.write_float(p_struct, s, grid, 'favorabilidad_estructural')
                    layers.append((s, w))
                else:
                    job.progress(50, 'Alineando ' + name)
                    a = rio.warp_band_to_grid(path, 1, grid, 'bilinear')
                    layers.append((norm_mod.normalize(a, 'percentile', 2, 98), w))
                used[name] = w
            job.progress(80, 'Superposición ponderada')
            f = prosp.weighted_overlay(layers, strict=False)
            # Sin evidencia mineral válida (fuera de la imagen, nubes, vegetación) no hay
            # prospectividad: evita que la estructura sola genere falsos targets en bordes.
            if mineral_mask is not None:
                f[~mineral_mask] = np.nan
            rio.write_float(p_out, f, grid, 'prospectividad_integrada')
            v = f[np.isfinite(f)]
            counts, edges = np.histogram(v, bins=50, range=(0, 1)) if v.size else ([], [])
            return prosp.stats(f), used, counts, edges

        def done(res):
            s, used, counts, edges = res
            self.state['prosp_path'] = p_out
            self.state['w_integration'] = used
            self.state['prosp_hist'] = (list(counts), list(edges))
            self.hist.set_data(counts, edges, 'Prospectividad integrada (0–1)', self.dlg.pal['accent'])
            self.k_mean.set('%.3f' % s['mean'])
            self.k_max.set('%.3f' % s['max'])
            self.k_high.set('%.1f %%' % s['high_pct'])
            self.k_mid.set('%.1f %%' % s['mid_pct'])
            if os.path.exists(p_struct):
                lyr.add_raster(p_struct, 'Favorabilidad estructural', 'fav')
            lyr.add_raster(p_out, 'Prospectividad integrada', 'fav')
            self.dlg.log('OK', 'Prospectividad integrada: media %.3f, %.1f %% del área > 0.70.'
                         % (s['mean'], s['high_pct']))
            for key in ('targets', 'validation'):
                self.dlg.mark_done(key, False)

        self.dlg.start(self, work, done, 'Calculando prospectividad integrada…')

    def save_settings(self):
        return {'edge': self.sp_edge.value(), 'radius': self.sp_rad.value(),
                'weights': [[e['name'], e['chk'].isChecked(), e['w'].value(), e['layer']] for e in self.ev]}

    def load_settings(self, d):
        self.sp_edge.setValue(float(d.get('edge', 85)))
        self.sp_rad.setValue(float(d.get('radius', 500)))
        for i, row in enumerate(d.get('weights') or []):
            name, on, w, layer = row
            if i < len(self.ev):
                self.ev[i]['chk'].setChecked(on)
                self.ev[i]['w'].setValue(w)
            elif layer and os.path.exists(layer):
                self._add_row(name, os.path.basename(layer), w, layer=layer)
