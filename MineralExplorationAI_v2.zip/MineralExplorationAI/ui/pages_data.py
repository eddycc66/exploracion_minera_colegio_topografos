# -*- coding: utf-8 -*-
"""Pasos 1-3: Configuración, cálculo de índices + normalización, Stack multibanda."""
import datetime
import os

import numpy as np
from qgis.PyQt.QtCore import Qt, QDate
from qgis.PyQt.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel,
                                 QLineEdit, QPushButton, QComboBox, QSpinBox, QDoubleSpinBox,
                                 QCheckBox, QTableWidget, QTableWidgetItem, QHeaderView,
                                 QAbstractItemView, QTreeWidget, QTreeWidgetItem, QFileDialog,
                                 QDateEdit, QListWidget, QListWidgetItem)
from qgis.core import (QgsProject, QgsRasterLayer, QgsCoordinateReferenceSystem,
                       QgsCoordinateTransform)
from qgis.gui import QgsMapLayerComboBox

from ..compat import RASTER, POINT, POLYGON, is_raster
from ..i18n import tr
from ..core import aster, raster_io as rio, indices as idx_mod, normalize as norm_mod
from ..core.constants import ASTER_BANDS, BAND_ORDER, UNITS_DN, UNITS_RADIANCE, UNITS_REFLECTANCE
from .widgets import Card, KpiCard, HistogramWidget, PercentileRange, set_invalid, muted
from .icons import icon
from . import layers as lyr


def _ro(text):
    it = QTableWidgetItem(str(text))
    it.setFlags(it.flags() & ~Qt.ItemFlag.ItemIsEditable)
    return it


def _layer_path(layer):
    if layer is None or not layer.isValid():
        return None
    if is_raster(layer) and layer.providerType() != 'gdal':
        return None
    return rio.clean_source(layer.source())


class BasePage(QWidget):
    key = ''
    title = ''
    subtitle = ''
    run_text = 'Ejecutar'
    help_text = ''

    def __init__(self, dlg):
        super(BasePage, self).__init__()
        self.dlg = dlg
        self.state = dlg.state
        self.root = QVBoxLayout(self)
        self.root.setContentsMargins(0, 8, 8, 8)
        self.root.setSpacing(10)
        self.build()
        self.root.addStretch(1)
        # Combos con textos largos: permitir que se encojan (evita scroll horizontal)
        for cb in self.findChildren(QComboBox):
            cb.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
            cb.setMinimumContentsLength(8)

    # interfaz de página
    def build(self):
        pass

    def check(self):
        return True, ''

    def run(self):
        pass

    def refresh(self):
        pass

    def on_theme(self, pal):
        pass

    def save_settings(self):
        return {}

    def load_settings(self, d):
        pass

    def help_html(self):
        return '<h3>%s</h3><p>%s</p>%s' % (tr(self.title), tr(self.subtitle), self.help_text)

    # utilidades
    def cfg(self):
        return self.dlg.page_by_key['config']

    def out(self, *parts):
        base = self.cfg().out_dir()
        path = os.path.join(base, *parts)
        os.makedirs(path if not os.path.splitext(path)[1] else os.path.dirname(path), exist_ok=True)
        return path

    @staticmethod
    def hrow(*items, stretch=True):
        h = QHBoxLayout()
        h.setSpacing(8)
        for it in items:
            if isinstance(it, QWidget):
                h.addWidget(it)
            else:
                h.addLayout(it)
        if stretch:
            h.addStretch()
        return h


# =============================================================================
# 1. Configuración
# =============================================================================

class ConfigPage(BasePage):
    key = 'config'
    title = 'Configuración'
    subtitle = 'Imagen ASTER, radiometría, área de estudio y capas auxiliares'
    run_text = 'Validar configuración'
    help_text = ('<p>Asigne cada banda ASTER a una capa y número de banda. '
                 '<b>Autodetectar capas ASTER</b> reconoce stacks de 14/19 bandas (GEE), '
                 'productos separados VNIR/SWIR/TIR y subdatasets HDF (ImageData1…14).</p>'
                 '<p><b>Radiometría:</b> los cocientes calculados sobre DN mezclan ganancias y '
                 'coeficientes distintos por banda. Si trabaja con L1T en DN, use '
                 '<i>Calibrar a radiancia</i> (UCC del ASTER User Handbook) o reflectancia TOA. '
                 'Lo ideal es AST_07XT (reflectancia con corrección de crosstalk).</p>'
                 '<p>El SWIR de ASTER falló en abril de 2008: escenas posteriores no sirven '
                 'para índices B4–B9.</p>')

    def build(self):
        # --- Proyecto
        c = Card(tr('Proyecto y salida'))
        g = QGridLayout()
        g.setHorizontalSpacing(10)
        self.ed_project = QLineEdit('Proyecto_Au_1')
        self.ed_analyst = QLineEdit()
        self.ed_analyst.setPlaceholderText('Nombre del geólogo responsable')
        self.ed_out = QLineEdit(os.path.join(os.path.expanduser('~'), 'GeoMineralAI_salidas'))
        self.btn_out = QPushButton(tr('Examinar…'))
        self.btn_out.clicked.connect(self._pick_out)
        g.addWidget(QLabel(tr('Nombre del proyecto') + ' *'), 0, 0)
        g.addWidget(self.ed_project, 0, 1, 1, 2)
        g.addWidget(QLabel(tr('Analista')), 1, 0)
        g.addWidget(self.ed_analyst, 1, 1, 1, 2)
        g.addWidget(QLabel(tr('Carpeta de salida') + ' *'), 2, 0)
        g.addWidget(self.ed_out, 2, 1)
        g.addWidget(self.btn_out, 2, 2)
        g.setColumnStretch(1, 1)
        c.add(g)
        self.root.addWidget(c)
        for w in (self.ed_project, self.ed_out):
            w.textChanged.connect(self._live_validate)
        self.ed_out.textChanged.connect(lambda *_: self.dlg._update_project_label()
                                        if hasattr(self.dlg, 'page_by_key') else None)

        # --- Bandas
        c = Card(tr('Bandas ASTER'), 'Asigne capa y número de banda. Las bandas sin capa se omiten; '
                                     'los índices que las necesiten se desactivan.')
        self.btn_detect = QPushButton(tr('Autodetectar capas ASTER'))
        self.btn_detect.setObjectName('Primary')
        self.btn_detect.clicked.connect(self.autodetect)
        self.btn_add = QPushButton(tr('Añadir archivo…'))
        self.btn_add.clicked.connect(self._add_files)
        self.lbl_groups = QLabel()
        self.lbl_groups.setWordWrap(True)
        c.add(self.hrow(self.btn_detect, self.btn_add, self.lbl_groups))
        self.tbl = QTableWidget(len(BAND_ORDER), 5)
        self.tbl.setHorizontalHeaderLabels(['Banda', 'λ (µm)', 'Subsistema', 'Capa', 'Nº banda'])
        self.tbl.verticalHeader().setVisible(False)
        self.tbl.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection)
        hh = self.tbl.horizontalHeader()
        for i in (0, 1, 2, 4):
            hh.setSectionResizeMode(i, QHeaderView.ResizeMode.ResizeToContents)
        hh.setSectionResizeMode(3, QHeaderView.ResizeMode.Stretch)
        self.band_cb, self.band_sp = {}, {}
        for r, b in enumerate(BAND_ORDER):
            info = ASTER_BANDS[b]
            self.tbl.setItem(r, 0, _ro(b if b != 'B3' else 'B3N'))
            self.tbl.setItem(r, 1, _ro('%.3f' % info['center']))
            self.tbl.setItem(r, 2, _ro('%s %d m' % (info['sub'], info['res'])))
            cb = QgsMapLayerComboBox()
            cb.setFilters(RASTER)
            cb.setAllowEmptyLayer(True)
            cb.setLayer(None)
            sp = QSpinBox()
            sp.setRange(1, 99)
            cb.layerChanged.connect(lambda l, s=sp: self._layer_changed(l, s))
            self.tbl.setCellWidget(r, 3, cb)
            self.tbl.setCellWidget(r, 4, sp)
            self.band_cb[b], self.band_sp[b] = cb, sp
        rh = int(self.fontMetrics().height() * 2.2)
        self.tbl.verticalHeader().setDefaultSectionSize(rh)
        self.tbl.setMinimumHeight(rh * 8)
        c.add(self.tbl)
        self.root.addWidget(c)

        # --- Radiometría
        c = Card(tr('Radiometría'))
        g = QGridLayout()
        self.cmb_units = QComboBox()
        self.cmb_units.addItem('DN (L1A / L1B / L1T)', UNITS_DN)
        self.cmb_units.addItem('Radiancia en sensor', UNITS_RADIANCE)
        self.cmb_units.addItem('Reflectancia (AST_07 / AST_07XT)', UNITS_REFLECTANCE)
        self.cmb_cal = QComboBox()
        self.cmb_cal.addItem('Sin calibrar (cocientes sobre DN)', None)
        self.cmb_cal.addItem('Radiancia (UCC, ASTER User Handbook)', UNITS_RADIANCE)
        self.cmb_cal.addItem('Reflectancia TOA (requiere fecha y elevación solar)', UNITS_REFLECTANCE)
        self.cmb_cal.setCurrentIndex(1)
        self.cmb_gain = QComboBox()
        for gname, lbl in (('NOR', 'Normal'), ('HGH', 'Alta'), ('LO1', 'Baja 1'), ('LO2', 'Baja 2')):
            self.cmb_gain.addItem(lbl, gname)
        self.de_date = QDateEdit(QDate(2005, 6, 15))
        self.de_date.setCalendarPopup(True)
        self.de_date.setDisplayFormat('yyyy-MM-dd')
        self.sp_sun = QDoubleSpinBox()
        self.sp_sun.setRange(0, 90)
        self.sp_sun.setValue(55.0)
        self.sp_sun.setSuffix(' °')
        self.chk_zero = QCheckBox('Enmascarar DN = 0 (relleno de escena)')
        self.chk_zero.setChecked(True)
        self.lbl_swir = QLabel()
        self.lbl_swir.setWordWrap(True)
        g.addWidget(QLabel('Unidades de entrada'), 0, 0)
        g.addWidget(self.cmb_units, 0, 1)
        g.addWidget(QLabel('Calibrar a'), 0, 2)
        g.addWidget(self.cmb_cal, 0, 3)
        g.addWidget(QLabel('Ganancia SWIR'), 1, 0)
        g.addWidget(self.cmb_gain, 1, 1)
        g.addWidget(QLabel('Fecha de adquisición'), 1, 2)
        g.addWidget(self.de_date, 1, 3)
        g.addWidget(QLabel('Elevación solar'), 2, 0)
        g.addWidget(self.sp_sun, 2, 1)
        g.addWidget(self.chk_zero, 2, 2, 1, 2)
        g.setColumnStretch(1, 1)
        g.setColumnStretch(3, 1)
        c.add(g)
        c.add(self.lbl_swir)
        self.root.addWidget(c)
        self.cmb_units.currentIndexChanged.connect(self._radiometry_ui)
        self.cmb_cal.currentIndexChanged.connect(self._radiometry_ui)
        self.de_date.dateChanged.connect(self._radiometry_ui)

        # --- Área y auxiliares
        c = Card(tr('Área de estudio y auxiliares'))
        g = QGridLayout()
        self.cb_aoi = QgsMapLayerComboBox()
        self.cb_aoi.setFilters(POLYGON)
        self.cb_aoi.setAllowEmptyLayer(True)
        self.cb_aoi.setLayer(None)
        self.chk_crop = QCheckBox('Recortar a la extensión del AOI')
        self.chk_crop.setChecked(True)
        self.cb_dem = QgsMapLayerComboBox()
        self.cb_dem.setFilters(RASTER)
        self.cb_dem.setAllowEmptyLayer(True)
        self.cb_dem.setLayer(None)
        self.cb_occ = QgsMapLayerComboBox()
        self.cb_occ.setFilters(POINT)
        self.cb_occ.setAllowEmptyLayer(True)
        self.cb_occ.setLayer(None)
        g.addWidget(QLabel('AOI (polígono)'), 0, 0)
        g.addWidget(self.cb_aoi, 0, 1)
        g.addWidget(self.chk_crop, 0, 2)
        g.addWidget(QLabel('DEM'), 1, 0)
        g.addWidget(self.cb_dem, 1, 1, 1, 2)
        g.addWidget(QLabel('Ocurrencias conocidas'), 2, 0)
        g.addWidget(self.cb_occ, 2, 1, 1, 2)
        g.setColumnStretch(1, 1)
        c.add(g)
        c.add(muted('El DEM alimenta la favorabilidad estructural (paso 6); las ocurrencias, la '
                    'validación (paso 8).'))
        self.root.addWidget(c)

        # --- Máscaras
        c = Card(tr('Máscaras'), 'Excluyen píxeles que generan falsos positivos en los cocientes.')
        self.chk_veg = QCheckBox('Excluir vegetación: NDVI mayor que')
        self.chk_veg.setChecked(True)
        self.sp_ndvi = QDoubleSpinBox()
        self.sp_ndvi.setRange(0.05, 0.9)
        self.sp_ndvi.setSingleStep(0.05)
        self.sp_ndvi.setValue(0.30)
        self.chk_dark = QCheckBox('Excluir sombras: albedo VNIR bajo el percentil')
        self.chk_dark.setChecked(True)
        self.sp_dark = QDoubleSpinBox()
        self.sp_dark.setRange(0.5, 20)
        self.sp_dark.setValue(3.0)
        self.sp_dark.setSuffix(' %')
        c.add(self.hrow(self.chk_veg, self.sp_ndvi))
        c.add(self.hrow(self.chk_dark, self.sp_dark))
        self.root.addWidget(c)

        # --- GEE opcional
        from ..core import gee
        c = Card('Descarga desde Google Earth Engine (opcional)')
        self.ed_gee_project = QLineEdit()
        self.ed_gee_project.setPlaceholderText('ID de proyecto de Google Cloud (ee.Initialize)')
        self.de_gee_a = QDateEdit(QDate(2000, 3, 1))
        self.de_gee_b = QDateEdit(QDate(2008, 3, 31))
        for d in (self.de_gee_a, self.de_gee_b):
            d.setCalendarPopup(True)
            d.setDisplayFormat('yyyy-MM-dd')
        self.sp_cloud = QSpinBox()
        self.sp_cloud.setRange(0, 100)
        self.sp_cloud.setValue(10)
        self.sp_cloud.setSuffix(' % nubes')
        self.btn_gee = QPushButton('Descargar escena ASTER L1T')
        self.btn_gee.clicked.connect(self._gee_download)
        self.btn_gee.setEnabled(gee.EE_AVAILABLE)
        gg = QGridLayout()
        gg.addWidget(QLabel('Proyecto GEE'), 0, 0)
        gg.addWidget(self.ed_gee_project, 0, 1, 1, 3)
        gg.addWidget(QLabel('Fechas'), 1, 0)
        gg.addWidget(self.de_gee_a, 1, 1)
        gg.addWidget(self.de_gee_b, 1, 2)
        gg.addWidget(self.sp_cloud, 1, 3)
        gg.addWidget(self.btn_gee, 2, 1, 1, 3)
        gg.setColumnStretch(1, 1)
        gg.setColumnStretch(2, 1)
        c.add(gg)
        c.add(muted('Estado: ' + ('earthengine-api disponible. Requiere haber ejecutado '
                                  '"earthengine authenticate" una vez fuera de QGIS.'
                                  if gee.EE_AVAILABLE else
                                  'earthengine-api no instalado (opcional). Ver README.')))
        self.root.addWidget(c)

        # --- Resumen
        c = Card(tr('Resumen'))
        k = QHBoxLayout()
        self.k_dims = KpiCard('Grilla de trabajo')
        self.k_res = KpiCard('Tamaño de píxel')
        self.k_bands = KpiCard('Bandas asignadas')
        self.k_idx = KpiCard('Índices disponibles')
        for w in (self.k_dims, self.k_res, self.k_bands, self.k_idx):
            k.addWidget(w)
        c.add(k)
        self.lbl_crs = muted('')
        c.add(self.lbl_crs)
        self.root.addWidget(c)
        self._radiometry_ui()
        self._live_validate()

    # ---------------------------------------------------------------- lógica UI
    def _pick_out(self):
        d = QFileDialog.getExistingDirectory(self, tr('Carpeta de salida'), self.ed_out.text())
        if d:
            self.ed_out.setText(d)

    def _live_validate(self):
        set_invalid(self.ed_project, not self.ed_project.text().strip(), 'Campo obligatorio')
        out = self.ed_out.text().strip()
        bad = not out or (os.path.exists(out) and not os.path.isdir(out))
        set_invalid(self.ed_out, bad, 'Indique una carpeta válida')

    def _layer_changed(self, layer, spin):
        if is_raster(layer):
            spin.setMaximum(max(1, layer.bandCount()))
        self._update_groups()

    def _radiometry_ui(self):
        dn = self.cmb_units.currentData() == UNITS_DN
        self.cmb_cal.setEnabled(dn)
        refl = dn and self.cmb_cal.currentData() == UNITS_REFLECTANCE
        self.sp_sun.setEnabled(refl)
        self.cmb_gain.setEnabled(dn and self.cmb_cal.currentData() is not None)
        self.chk_zero.setEnabled(dn)
        w = aster.swir_warning(self.acq_date())
        pal = self.dlg.pal if hasattr(self.dlg, 'pal') else {'accent': '#f39c12', 'muted': '#9aa3b2'}
        if w:
            self.lbl_swir.setText('⚠ ' + w)
            self.lbl_swir.setStyleSheet('color:%s;' % pal['accent'])
            set_invalid(self.de_date, True, w)
        else:
            self.lbl_swir.setText('Fecha anterior al fallo SWIR (abril 2008): B4–B9 utilizables.')
            self.lbl_swir.setStyleSheet('color:%s;' % pal['muted'])
            set_invalid(self.de_date, False)

    def _update_groups(self):
        keys = self.sources().keys()
        parts = []
        for name, group in (('VNIR', ['B1', 'B2', 'B3']), ('SWIR', ['B4', 'B5', 'B6', 'B7', 'B8', 'B9']),
                            ('TIR', ['B10', 'B11', 'B12', 'B13', 'B14'])):
            n = sum(1 for b in group if b in keys)
            mark = '✓' if n == len(group) else ('%d/%d' % (n, len(group)) if n else '—')
            parts.append('%s %s' % (name, mark))
        self.lbl_groups.setText('   '.join(parts))
        self.k_bands.set('%d / 14' % len(keys), 'ok' if len(keys) == 14 else ('warn' if keys else 'bad'))
        n_idx = len([i for i in idx_mod.available_indices(keys) if i.key != 'ndvi'])
        self.k_idx.set(str(n_idx), 'ok' if n_idx >= 8 else 'warn')

    def acq_date(self):
        d = self.de_date.date()
        return datetime.date(d.year(), d.month(), d.day())

    # ---------------------------------------------------------------- API para otras páginas
    def out_dir(self):
        return self.ed_out.text().strip()

    def sources(self):
        out = {}
        for b in BAND_ORDER:
            path = _layer_path(self.band_cb[b].currentLayer())
            if path:
                out[b] = (path, self.band_sp[b].value())
        return out

    def radiometry(self):
        return {'units': self.cmb_units.currentData(),
                'calibrate_to': self.cmb_cal.currentData() if self.cmb_units.currentData() == UNITS_DN else None,
                'gain': {b: self.cmb_gain.currentData() for b in ('B4', 'B5', 'B6', 'B7', 'B8', 'B9')},
                'sun_elev': self.sp_sun.value(), 'acq_date': self.acq_date(),
                'mask_zero': self.chk_zero.isChecked()}

    def masks(self):
        return {'ndvi_max': self.sp_ndvi.value() if self.chk_veg.isChecked() else None,
                'dark_percentile': self.sp_dark.value() if self.chk_dark.isChecked() else None}

    def aoi_bounds(self, sources):
        """Extensión del AOI en el CRS de la banda de referencia (hilo principal)."""
        layer = self.cb_aoi.currentLayer()
        if layer is None or not self.chk_crop.isChecked() or not sources:
            return None
        ref = aster.choose_reference(sources)
        grid = rio.Grid.from_path(sources[ref][0])
        dst = QgsCoordinateReferenceSystem.fromWkt(grid.wkt)
        ext = layer.extent()
        if layer.crs() != dst:
            ext = QgsCoordinateTransform(layer.crs(), dst, QgsProject.instance()).transformBoundingBox(ext)
        return (ext.xMinimum(), ext.yMinimum(), ext.xMaximum(), ext.yMaximum())

    def dem_path(self):
        return _layer_path(self.cb_dem.currentLayer())

    def image_name(self):
        s = self.sources()
        return os.path.basename(next(iter(s.values()))[0]) if s else '—'

    # ---------------------------------------------------------------- acciones
    def autodetect(self):
        per_layer = []
        for layer in QgsProject.instance().mapLayers().values():
            if not is_raster(layer) or layer.providerType() != 'gdal':
                continue
            path = _layer_path(layer)
            try:
                descs = rio.band_descriptions(path)
            except Exception:
                continue
            m = aster.guess_bands(descs, layer.name())
            if m:
                per_layer.append((layer, layer.name(), m))
        if not per_layer:
            self.dlg.notify('Warning', 'No se encontraron capas ASTER en el proyecto. Use "Añadir archivo…".')
            return
        merged = {}
        for layer, _n, m in sorted(per_layer, key=lambda t: -len(t[2])):
            for b, i in m.items():
                merged.setdefault(b, (layer, i))
        for b, (layer, i) in merged.items():
            self.band_cb[b].setLayer(layer)
            self.band_sp[b].setMaximum(max(1, layer.bandCount()))
            self.band_sp[b].setValue(i)
        self._update_groups()
        missing = [b for b in BAND_ORDER if b not in merged]
        self.dlg.log('OK', 'Autodetección: %d bandas asignadas desde %d capa(s).%s'
                     % (len(merged), len(set(id(v[0]) for v in merged.values())),
                        (' Faltan: ' + ', '.join(missing)) if missing else ''))
        self.dlg.notify('Success' if not missing else 'Warning',
                        '%d de 14 bandas ASTER asignadas.' % len(merged), 5)

    def _add_files(self):
        paths, _ = QFileDialog.getOpenFileNames(self, tr('Añadir archivo…'), '',
                                                'Raster (*.tif *.tiff *.hdf *.vrt *.img);;Todos (*)')
        for p in paths:
            layer = QgsRasterLayer(p, os.path.splitext(os.path.basename(p))[0], 'gdal')
            if layer.isValid():
                QgsProject.instance().addMapLayer(layer)
            else:
                self.dlg.log('WARN', 'No se pudo abrir %s (¿HDF con subdatasets? añádalo desde el '
                                     'Administrador de fuentes de datos).' % p)
        if paths:
            self.autodetect()

    def _gee_download(self):
        from ..core import gee
        layer = self.cb_aoi.currentLayer()
        if layer is None:
            self.dlg.notify('Warning', 'Seleccione un AOI para la descarga desde GEE.')
            return
        ext = layer.extent()
        wgs = QgsCoordinateReferenceSystem('EPSG:4326')
        if layer.crs() != wgs:
            ext = QgsCoordinateTransform(layer.crs(), wgs, QgsProject.instance()).transformBoundingBox(ext)
        bbox = (ext.xMinimum(), ext.yMinimum(), ext.xMaximum(), ext.yMaximum())
        project = self.ed_gee_project.text().strip() or None
        a = self.de_gee_a.date().toString('yyyy-MM-dd')
        b = self.de_gee_b.date().toString('yyyy-MM-dd')
        cloud = self.sp_cloud.value()
        out = self.out('GEE')

        def work(job):
            gee.initialize(project)
            return gee.download_aster(bbox, out, a, b, cloud, progress=job.progress)

        def done(res):
            path, meta = res
            layer = QgsRasterLayer(path, os.path.basename(path), 'gdal')
            QgsProject.instance().addMapLayer(layer)
            if meta.get('SOLAR_ELEVATION'):
                self.sp_sun.setValue(float(meta['SOLAR_ELEVATION']))
            if meta.get('system:time_start'):
                d = datetime.datetime.fromtimestamp(meta['system:time_start'] / 1000.0,
                                                    datetime.timezone.utc)
                self.de_date.setDate(QDate(d.year, d.month, d.day))
            self.autodetect()

        self.dlg.start(self, work, done, 'Descargando ASTER desde Earth Engine…')

    def check(self):
        self._live_validate()
        if not self.ed_project.text().strip():
            return False, 'Indique el nombre del proyecto.'
        if not self.out_dir():
            return False, 'Indique la carpeta de salida.'
        if len(self.sources()) < 2:
            return False, 'Asigne al menos dos bandas ASTER (use "Autodetectar capas ASTER").'
        return True, ''

    def run(self):
        sources = self.sources()
        bounds = self.aoi_bounds(sources)
        os.makedirs(self.out_dir(), exist_ok=True)

        def work(job):
            grid, ref = aster.build_grid(sources, bounds)
            job.progress(100, 'Grilla calculada')
            return grid, ref

        def done(res):
            grid, ref = res
            self.state['grid_preview'] = grid
            self.k_dims.set('%d × %d' % (grid.width, grid.height), 'ok')
            self.k_res.set('%.4g' % grid.res[0], 'ok')
            srs = grid.srs()
            name = srs.GetName() if grid.wkt else 'sin CRS'
            epsg = srs.GetAuthorityCode(None) if grid.wkt else None
            self.lbl_crs.setText('CRS: %s%s · referencia %s · %s' % (
                name, (' (EPSG:%s)' % epsg) if epsg else '', ref,
                'recortado al AOI' if bounds else 'escena completa'))
            if grid.is_geographic():
                self.dlg.log('WARN', 'CRS geográfico: áreas y pendientes se corrigen por latitud, '
                                     'pero se recomienda reproyectar a UTM.')
            w = aster.swir_warning(self.acq_date())
            if w:
                self.dlg.notify('Warning', w)
            self.dlg.log('OK', 'Configuración válida: %d bandas, grilla %d×%d.'
                         % (len(sources), grid.width, grid.height))

        self.dlg.start(self, work, done, 'Validando configuración…')

    # ---------------------------------------------------------------- persistencia
    def save_settings(self):
        bands = {}
        for b in BAND_ORDER:
            l = self.band_cb[b].currentLayer()
            if l is not None:
                bands[b] = [l.id(), _layer_path(l), self.band_sp[b].value()]
        def lid(cb):
            l = cb.currentLayer()
            return [l.id(), l.source()] if l is not None else None
        return {'project': self.ed_project.text(), 'analyst': self.ed_analyst.text(),
                'out_dir': self.ed_out.text(), 'bands': bands,
                'units': self.cmb_units.currentIndex(), 'cal': self.cmb_cal.currentIndex(),
                'gain': self.cmb_gain.currentIndex(), 'date': self.de_date.date().toString('yyyy-MM-dd'),
                'sun': self.sp_sun.value(), 'zero': self.chk_zero.isChecked(),
                'aoi': lid(self.cb_aoi), 'crop': self.chk_crop.isChecked(), 'dem': lid(self.cb_dem),
                'occ': lid(self.cb_occ), 'veg': self.chk_veg.isChecked(), 'ndvi': self.sp_ndvi.value(),
                'dark': self.chk_dark.isChecked(), 'dark_p': self.sp_dark.value(),
                'gee_project': self.ed_gee_project.text()}

    def _find_layer(self, ref):
        if not ref:
            return None
        prj = QgsProject.instance()
        l = prj.mapLayer(ref[0])
        if l is not None:
            return l
        for l in prj.mapLayers().values():
            if rio.clean_source(l.source()) == rio.clean_source(ref[1] or ''):
                return l
        return None

    def load_settings(self, d):
        self.ed_project.setText(d.get('project', self.ed_project.text()))
        self.ed_analyst.setText(d.get('analyst', ''))
        if d.get('out_dir'):
            self.ed_out.setText(d['out_dir'])
        for b, ref in (d.get('bands') or {}).items():
            l = self._find_layer(ref[:2])
            if l is not None and b in self.band_cb:
                self.band_cb[b].setLayer(l)
                self.band_sp[b].setMaximum(max(1, l.bandCount()))
                self.band_sp[b].setValue(int(ref[2]))
        self.cmb_units.setCurrentIndex(int(d.get('units', 0)))
        self.cmb_cal.setCurrentIndex(int(d.get('cal', 1)))
        self.cmb_gain.setCurrentIndex(int(d.get('gain', 0)))
        if d.get('date'):
            self.de_date.setDate(QDate.fromString(d['date'], 'yyyy-MM-dd'))
        self.sp_sun.setValue(float(d.get('sun', 55.0)))
        self.chk_zero.setChecked(bool(d.get('zero', True)))
        for key, cb in (('aoi', self.cb_aoi), ('dem', self.cb_dem), ('occ', self.cb_occ)):
            l = self._find_layer(d.get(key))
            if l is not None:
                cb.setLayer(l)
        self.chk_crop.setChecked(bool(d.get('crop', True)))
        self.chk_veg.setChecked(bool(d.get('veg', True)))
        self.sp_ndvi.setValue(float(d.get('ndvi', 0.3)))
        self.chk_dark.setChecked(bool(d.get('dark', True)))
        self.sp_dark.setValue(float(d.get('dark_p', 3.0)))
        self.ed_gee_project.setText(d.get('gee_project', ''))
        self._update_groups()
        self._radiometry_ui()

    def refresh(self):
        self._update_groups()


# =============================================================================
# 2. Índices + normalización
# =============================================================================

class NormalizePage(BasePage):
    key = 'normalize'
    title = 'Normalizar'
    subtitle = 'Cálculo de índices minerales y normalización a 0–1'
    run_text = 'Calcular índices'
    help_text = ('<p>Cada índice se calcula con división segura (NaN si |denominador| < 1e-6, '
                 'sin sumar épsilon), en float32, sobre la grilla común de 30 m. El TIR (90 m) '
                 'se remuestrea con interpolación bilineal y el VNIR (15 m) por promedio.</p>'
                 '<p><b>Percentil</b> (recomendado): (x − Pl)/(Ph − Pl) recortado a [0, 1]; '
                 'robusto frente a píxeles saturados o casi nulos. Pase el cursor sobre un índice '
                 'para ver fórmula, física, referencia y falsos positivos.</p>')

    def build(self):
        top = QHBoxLayout()
        top.setSpacing(10)
        # Árbol de índices
        c = Card(tr('Índices'), 'Marque los índices a calcular. Los que no tienen bandas asignadas '
                                'aparecen desactivados.')
        self.tree = QTreeWidget()
        self.tree.setHeaderLabels(['Índice', 'Fórmula', 'Objetivo'])
        self.tree.setRootIsDecorated(True)
        self.tree.setMinimumHeight(330)
        hh = self.tree.header()
        hh.setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        hh.setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        self.items = {}
        groups = {}
        for g, label in (('VNIR', 'VNIR · óxidos y hierro'), ('SWIR', 'SWIR · arcillas, micas, carbonatos'),
                         ('TIR', 'TIR · sílice y carbonatos')):
            gi = QTreeWidgetItem([label])
            gi.setFlags(Qt.ItemFlag.ItemIsEnabled)
            f = gi.font(0)
            f.setBold(True)
            gi.setFont(0, f)
            self.tree.addTopLevelItem(gi)
            groups[g] = gi
        for d in idx_mod.INDICES:
            it = QTreeWidgetItem([d.name_es, d.formula, d.target])
            it.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsUserCheckable | Qt.ItemFlag.ItemIsSelectable)
            it.setCheckState(0, Qt.CheckState.Checked if d.default_on else Qt.CheckState.Unchecked)
            it.setData(0, Qt.ItemDataRole.UserRole, d.key)
            for col in range(3):
                it.setToolTip(col, d.tooltip())
            groups[d.group].addChild(it)
            self.items[d.key] = it
        self.tree.expandAll()
        c.add(self.tree)
        b1 = QPushButton('Recomendados')
        b1.clicked.connect(lambda: self._select('default'))
        b2 = QPushButton('Todos')
        b2.clicked.connect(lambda: self._select('all'))
        b3 = QPushButton('Ninguno')
        b3.clicked.connect(lambda: self._select('none'))
        c.add(self.hrow(b1, b2, b3))
        top.addWidget(c, 3)

        # Normalización + histograma
        right = QVBoxLayout()
        c2 = Card(tr('Normalización'))
        self.cmb_method = QComboBox()
        self.cmb_method.addItem('Percentil (robusto a outliers)', 'percentile')
        self.cmb_method.addItem('Mín–Máx', 'minmax')
        self.cmb_method.addItem('Sin normalizar', 'none')
        self.range = PercentileRange(2.0, 98.0)
        self.chk_map = QCheckBox('Añadir al mapa')
        self.chk_map.setToolTip('Añade las capas normalizadas al proyecto QGIS')
        self.chk_map.setChecked(True)
        self.btn_renorm = QPushButton('Solo re-normalizar')
        self.btn_renorm.setToolTip('Aplica el método/percentiles actuales a los índices ya '
                                   'calculados, sin volver a leer la imagen.')
        self.btn_renorm.clicked.connect(self.renormalize)
        c2.add(self.hrow(QLabel('Método'), self.cmb_method, stretch=False))
        c2.add(self.range)
        c2.add(self.chk_map)
        c2.add(self.hrow(self.btn_renorm))
        right.addWidget(c2)
        c3 = Card(tr('Vista previa del histograma'))
        self.cmb_prev = QComboBox()
        self.cmb_prev.currentIndexChanged.connect(self._preview)
        self.hist = HistogramWidget()
        self.hist.setMinimumHeight(170)
        c3.add(self.cmb_prev)
        c3.add(self.hist)
        right.addWidget(c3)
        top.addLayout(right, 2)
        self.root.addLayout(top)
        self.cmb_method.currentIndexChanged.connect(self._method_ui)
        self.range.changed.connect(lambda *_: self._preview())

        c4 = Card(tr('Resultados'))
        self.tbl = QTableWidget(0, 7)
        self.tbl.setHorizontalHeaderLabels(['Índice', 'Mín', 'P2', 'Mediana', 'P98', 'Máx', 'NoData %'])
        self.tbl.verticalHeader().setVisible(False)
        self.tbl.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.tbl.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.tbl.setMinimumHeight(170)
        c4.add(self.tbl)
        self.root.addWidget(c4)

    def _method_ui(self):
        self.range.setEnabled(self.cmb_method.currentData() == 'percentile')
        self._preview()

    def _select(self, mode):
        for k, it in self.items.items():
            if not (it.flags() & Qt.ItemFlag.ItemIsEnabled):
                continue
            on = mode == 'all' or (mode == 'default' and idx_mod.INDEX_BY_KEY[k].default_on)
            it.setCheckState(0, Qt.CheckState.Checked if on else Qt.CheckState.Unchecked)

    def refresh(self):
        keys = self.cfg().sources().keys()
        for k, it in self.items.items():
            d = idx_mod.INDEX_BY_KEY[k]
            ok = d.available(keys)
            flags = Qt.ItemFlag.ItemIsUserCheckable | Qt.ItemFlag.ItemIsSelectable
            it.setFlags(flags | Qt.ItemFlag.ItemIsEnabled if ok else flags)
            miss = [b for b in d.bands if b not in keys]
            it.setToolTip(0, d.tooltip() + ('' if ok else '<br><b>Faltan bandas: %s</b>' % ', '.join(miss)))

    def selected(self):
        return [k for k, it in self.items.items()
                if it.checkState(0) == Qt.CheckState.Checked and (it.flags() & Qt.ItemFlag.ItemIsEnabled)]

    def check(self):
        if not self.cfg().check()[0]:
            return False, 'Complete primero la configuración (paso 1): ' + self.cfg().check()[1]
        self.refresh()
        if not self.selected():
            return False, 'Seleccione al menos un índice disponible.'
        return True, ''

    def _norm_params(self):
        lo, hi = self.range.values()
        return self.cmb_method.currentData(), lo, hi

    def run(self):
        cfg = self.cfg()
        sources = cfg.sources()
        bounds = cfg.aoi_bounds(sources)
        rad = cfg.radiometry()
        masks = cfg.masks()
        keys = self.selected()
        method, lo, hi = self._norm_params()
        d_raw, d_norm = self.out('indices'), self.out('normalizados')

        def work(job):
            grid, ref = aster.build_grid(sources, bounds)
            job.log('Grilla %d×%d, píxel %.4g, referencia %s' % (grid.width, grid.height, grid.res[0], ref))
            bands, log = aster.load_bands(sources, grid, rad['units'], rad['gain'], rad['sun_elev'],
                                          rad['acq_date'], rad['calibrate_to'], rad['mask_zero'],
                                          progress=lambda p, m: job.progress(int(p * 0.4), m),
                                          cancel=job.cancelled)
            for m in log:
                job.log(m)
            valid, info = aster.build_valid_mask(bands, masks['ndvi_max'], masks['dark_percentile'])
            for k, v in info.items():
                job.log('Máscara %s: %.1f %% de la escena' % (k, v))
            res = idx_mod.compute_indices(bands, keys, valid,
                                          progress=lambda p, m: job.progress(40 + int(p * 0.3), m),
                                          cancel=job.cancelled)
            del bands
            out = {'grid': grid, 'raw': {}, 'norm': {}, 'stats': {}, 'samples': {}}
            rng = np.random.default_rng(0)
            for n, (k, arr) in enumerate(res.items()):
                if job.cancelled():
                    break
                job.progress(70 + int(30 * n / max(1, len(res))), 'Guardando ' + k)
                rp = os.path.join(d_raw, 'idx_%s.tif' % k)
                npth = os.path.join(d_norm, 'norm_%s.tif' % k)
                rio.write_float(rp, arr, grid, idx_mod.INDEX_BY_KEY[k].name_es)
                rio.write_float(npth, norm_mod.normalize(arr, method, lo, hi), grid, k)
                v = arr[np.isfinite(arr)]
                out['samples'][k] = rng.choice(v, min(v.size, 150000), replace=False) if v.size else v
                out['stats'][k] = idx_mod.describe(arr)
                out['raw'][k], out['norm'][k] = rp, npth
                if out['stats'][k].get('n', 0) == 0:
                    job.log('%s: sin píxeles válidos (revise bandas y máscaras)' % k, 'WARN')
            return out

        self.dlg.start(self, work, self._done, 'Calculando %d índices…' % len(keys))

    def _done(self, out):
        self.state.update({'grid': out['grid'], 'idx_raw': out['raw'], 'idx_norm': out['norm'],
                           'idx_stats': out['stats'], 'samples': out['samples'],
                           'norm_params': self._norm_params()})
        self._fill(out)
        if self.chk_map.isChecked():
            for k, p in out['norm'].items():
                d = idx_mod.INDEX_BY_KEY[k]
                lyr.add_raster(p, d.name_es, 'norm', self.state.get('colors', {}).get(k, d.color),
                               sub='Índices normalizados')
        self.dlg.log('OK', '%d índices guardados en %s' % (len(out['raw']), self.out('indices')))
        for key in ('stack', 'kmeans', 'mineral', 'integrated', 'targets', 'validation'):
            self.dlg.mark_done(key, False)

    def _fill(self, out):
        self.tbl.setRowCount(0)
        self.cmb_prev.blockSignals(True)
        self.cmb_prev.clear()
        for k in out['raw']:
            s = out['stats'][k]
            r = self.tbl.rowCount()
            self.tbl.insertRow(r)
            vals = [idx_mod.INDEX_BY_KEY[k].name_es] + (
                ['%.4g' % s[x] for x in ('min', 'p2', 'p50', 'p98', 'max')] + ['%.1f' % s['nan_pct']]
                if s.get('n') else ['—'] * 6)
            for cidx, v in enumerate(vals):
                self.tbl.setItem(r, cidx, _ro(v))
            self.cmb_prev.addItem(idx_mod.INDEX_BY_KEY[k].name_es, k)
        self.cmb_prev.blockSignals(False)
        self._preview()

    def _preview(self):
        k = self.cmb_prev.currentData()
        smp = (self.state.get('samples') or {}).get(k)
        if k is None or smp is None or not len(smp):
            return
        counts, edges = norm_mod.histogram(smp, 60)
        d = idx_mod.INDEX_BY_KEY[k]
        self.hist.set_data(counts, edges, '%s  ·  %s' % (d.name_es, d.formula),
                           self.state.get('colors', {}).get(k, d.color))
        method, lo, hi = self._norm_params()
        if method == 'percentile':
            a, b = np.percentile(smp, [lo, hi])
        elif method == 'minmax':
            a, b = float(np.min(smp)), float(np.max(smp))
        else:
            a = b = None
        self.hist.set_cuts(a, b)

    def renormalize(self):
        raw = self.state.get('idx_raw')
        if not raw:
            self.dlg.notify('Warning', 'Primero calcule los índices.')
            return
        method, lo, hi = self._norm_params()
        grid = self.state['grid']
        d_norm = self.out('normalizados')

        def work(job):
            out = {}
            for n, (k, p) in enumerate(raw.items()):
                job.progress(int(100 * n / len(raw)), 'Normalizando ' + k)
                npth = os.path.join(d_norm, 'norm_%s.tif' % k)
                rio.write_float(npth, norm_mod.normalize(rio.read_band(p), method, lo, hi), grid, k)
                out[k] = npth
            return out

        def done(out):
            self.state['idx_norm'] = out
            self.state['norm_params'] = (method, lo, hi)
            if self.chk_map.isChecked():
                for k, p in out.items():
                    d = idx_mod.INDEX_BY_KEY[k]
                    lyr.add_raster(p, d.name_es, 'norm', d.color, sub='Índices normalizados')
            self.dlg.log('OK', 'Re-normalización aplicada (%s %.1f–%.1f).' % (method, lo, hi))

        self.dlg.start(self, work, done, 'Re-normalizando…')

    def on_theme(self, pal):
        self.hist.set_theme(pal)

    def save_settings(self):
        method, lo, hi = self._norm_params()
        return {'selected': self.selected(), 'method': self.cmb_method.currentIndex(),
                'lo': lo, 'hi': hi, 'map': self.chk_map.isChecked()}

    def load_settings(self, d):
        sel = d.get('selected')
        if sel:
            for k, it in self.items.items():
                it.setCheckState(0, Qt.CheckState.Checked if k in sel else Qt.CheckState.Unchecked)
        self.cmb_method.setCurrentIndex(int(d.get('method', 0)))
        self.range.set_values(float(d.get('lo', 2)), float(d.get('hi', 98)))
        self.chk_map.setChecked(bool(d.get('map', True)))
        self._method_ui()


# =============================================================================
# 3. Stack
# =============================================================================

class StackPage(BasePage):
    key = 'stack'
    title = 'Stack'
    subtitle = 'Selección y orden de bandas para el análisis multivariado'
    run_text = 'Crear stack'
    help_text = ('<p>Arrastre para reordenar y marque las bandas que entrarán al stack '
                 '<i>Stack_ML.tif</i> (Float32, NoData −9999, una banda por índice con su nombre). '
                 'Todas las bandas comparten la grilla del paso 2, así que no hay remuestreo '
                 'adicional.</p><p>Consejo: evite índices redundantes (p.ej. ALI y RBD5 miden la '
                 'misma absorción) para que K-Means no sobrepondere una familia.</p>')

    def build(self):
        c = Card('Bandas del stack', 'Arrastre para cambiar el orden. Solo se incluyen las marcadas.')
        self.list = QListWidget()
        self.list.setObjectName('BandList')
        self.list.setDragDropMode(QAbstractItemView.DragDropMode.InternalMove)
        self.list.setDefaultDropAction(Qt.DropAction.MoveAction)
        self.list.setMinimumHeight(260)
        self.list.itemChanged.connect(lambda *_: self._info())
        self.list.model().rowsMoved.connect(lambda *_: self._info())
        c.add(self.list)
        ball = QPushButton('Todas')
        ball.clicked.connect(lambda: self._check_all(True))
        bnone = QPushButton('Ninguna')
        bnone.clicked.connect(lambda: self._check_all(False))
        self.bup = QPushButton('Subir')
        self.bup.clicked.connect(lambda: self._move(-1))
        self.bdn = QPushButton('Bajar')
        self.bdn.clicked.connect(lambda: self._move(1))
        c.add(self.hrow(ball, bnone, self.bup, self.bdn))
        self.root.addWidget(c)

        c2 = Card('Stack_ML.tif')
        k = QHBoxLayout()
        self.k_n = KpiCard('Bandas seleccionadas')
        self.k_dim = KpiCard('Dimensiones')
        self.k_mb = KpiCard('Tamaño estimado')
        for w in (self.k_n, self.k_dim, self.k_mb):
            k.addWidget(w)
        c2.add(k)
        self.lbl_path = muted('')
        c2.add(self.lbl_path)
        self.root.addWidget(c2)

    def on_theme(self, pal):
        self.bup.setIcon(icon('up', pal['text']))
        self.bdn.setIcon(icon('down', pal['text']))

    def refresh(self):
        norm = self.state.get('idx_norm') or {}
        present = [self.list.item(i).data(Qt.ItemDataRole.UserRole) for i in range(self.list.count())]
        self.list.blockSignals(True)
        for i in reversed(range(self.list.count())):
            if self.list.item(i).data(Qt.ItemDataRole.UserRole) not in norm:
                self.list.takeItem(i)
        for k in norm:
            if k in present or k == 'ndvi':
                continue
            d = idx_mod.INDEX_BY_KEY[k]
            it = QListWidgetItem('%s    %s' % (d.name_es, d.formula))
            it.setData(Qt.ItemDataRole.UserRole, k)
            it.setFlags(it.flags() | Qt.ItemFlag.ItemIsUserCheckable | Qt.ItemFlag.ItemIsDragEnabled)
            it.setCheckState(Qt.CheckState.Checked if k != 'aaa_rbd5' else Qt.CheckState.Unchecked)
            it.setToolTip(d.tooltip())
            self.list.addItem(it)
        self.list.blockSignals(False)
        self._info()

    def _check_all(self, on):
        for i in range(self.list.count()):
            self.list.item(i).setCheckState(Qt.CheckState.Checked if on else Qt.CheckState.Unchecked)

    def _move(self, delta):
        r = self.list.currentRow()
        if r < 0:
            return
        n = r + delta
        if 0 <= n < self.list.count():
            it = self.list.takeItem(r)
            self.list.insertItem(n, it)
            self.list.setCurrentRow(n)
            self._info()

    def selected(self):
        return [self.list.item(i).data(Qt.ItemDataRole.UserRole) for i in range(self.list.count())
                if self.list.item(i).checkState() == Qt.CheckState.Checked]

    def _info(self):
        sel = self.selected()
        g = self.state.get('grid')
        self.k_n.set(str(len(sel)), 'ok' if len(sel) >= 2 else 'bad')
        if g:
            self.k_dim.set('%d × %d' % (g.width, g.height))
            self.k_mb.set('%.1f MB' % (g.width * g.height * 4 * len(sel) / 1048576.0))

    def check(self):
        if not self.state.get('idx_norm'):
            return False, 'Calcule primero los índices (paso 2).'
        if len(self.selected()) < 2:
            return False, 'Seleccione al menos dos bandas para el stack.'
        return True, ''

    def run(self):
        sel = self.selected()
        norm = self.state['idx_norm']
        grid = self.state['grid']
        path = self.out('Stack_ML.tif')

        def work(job):
            arrs = []
            for n, k in enumerate(sel):
                job.progress(int(90 * n / len(sel)), 'Leyendo ' + k)
                arrs.append(rio.read_band(norm[k]))
            rio.write_stack(path, arrs, sel, grid)
            return path

        def done(p):
            self.state['stack_path'] = p
            self.state['stack_names'] = sel
            self.lbl_path.setText(p)
            self.dlg.log('OK', 'Stack creado: %d bandas → %s' % (len(sel), p))
            self.dlg.mark_done('kmeans', False)

        self.dlg.start(self, work, done, 'Creando Stack_ML.tif…')

    def save_settings(self):
        return {'order': [self.list.item(i).data(Qt.ItemDataRole.UserRole) for i in range(self.list.count())],
                'selected': self.selected()}
