# -*- coding: utf-8 -*-
"""
Ejecución en segundo plano sin bloquear QGIS.

Cambios frente a v1:
  * Señales declaradas en la propia QThread (v1 creaba un QObject auxiliar).
  * Cancelación cooperativa (bandera consultada por el núcleo en cada bloque).
  * Al cerrar el diálogo se pide cancelar y se espera; nunca se destruye un hilo
    en ejecución (v1 llamaba quit()/wait(3000) y podía provocar
    "QThread: Destroyed while thread is still running" y cerrar QGIS).
  * Excepciones capturadas con traceback completo hacia el registro.
"""
import traceback

from qgis.PyQt.QtCore import QThread, pyqtSignal


class Job(object):
    """Contexto que recibe la función de trabajo."""

    def __init__(self, thread):
        self._t = thread

    def progress(self, pct, msg=''):
        self._t.progress.emit(int(max(0, min(100, pct))), str(msg))

    def log(self, msg, level='INFO'):
        self._t.message.emit(level, str(msg))

    def cancelled(self):
        return self._t.is_cancelled


class Worker(QThread):
    progress = pyqtSignal(int, str)
    message = pyqtSignal(str, str)       # nivel, texto
    done = pyqtSignal(object)
    failed = pyqtSignal(str, str)        # mensaje corto, traceback

    def __init__(self, fn, parent=None):
        super(Worker, self).__init__(parent)
        self._fn = fn
        self.is_cancelled = False

    def cancel(self):
        self.is_cancelled = True

    def run(self):
        try:
            result = self._fn(Job(self))
            if self.is_cancelled:
                self.failed.emit("Proceso cancelado por el usuario.", '')
            else:
                self.done.emit(result)
        except Exception as e:           # noqa: BLE001 — se reporta todo al usuario
            self.failed.emit('%s: %s' % (type(e).__name__, e), traceback.format_exc())
