# -*- coding: utf-8 -*-
"""Carga de la hoja QSS con sustitución de tokens de color por tema."""
import os

PALETTES = {
    'dark': {
        'bg': '#1e2229', 'panel': '#252a33', 'raised': '#2c323d', 'border': '#3a3f4b',
        'text': '#e6e6e6', 'muted': '#9aa3b2', 'accent': '#f39c12', 'accenthover': '#f5ab35',
        'ok': '#00b894', 'err': '#e74c3c', 'errbg': '#3a2528', 'selbg': '#3b3524',
        'info': '#74b9ff',
    },
    'light': {
        'bg': '#eef1f5', 'panel': '#ffffff', 'raised': '#f6f8fa', 'border': '#d3d8e0',
        'text': '#1e2229', 'muted': '#5c6370', 'accent': '#c77c0a', 'accenthover': '#dd8b10',
        'ok': '#00a383', 'err': '#d63031', 'errbg': '#fdecec', 'selbg': '#fdf1dc',
        'info': '#0984e3',
    },
}

_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'resources', 'styles')


def palette(name):
    return PALETTES.get(name, PALETTES['dark'])


def stylesheet(name='dark', compact=False):
    pal = palette(name)
    with open(os.path.join(_DIR, 'geomineral.qss'), 'r', encoding='utf-8') as fh:
        qss = fh.read()
    # Sustituir tokens largos primero (@accenthover antes que @accent)
    for k in sorted(pal, key=len, reverse=True):
        qss = qss.replace('@' + k, pal[k])
    if compact:
        with open(os.path.join(_DIR, 'compact.qss'), 'r', encoding='utf-8') as fh:
            qss += '\n' + fh.read()
    return qss
