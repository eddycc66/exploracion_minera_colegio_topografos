# -*- coding: utf-8 -*-
"""Componentes de interfaz reutilizables (dibujados con QPainter, sin matplotlib)."""
import datetime
import html

from qgis.PyQt.QtCore import Qt, pyqtSignal, QRectF, QPointF
from qgis.PyQt.QtGui import QColor, QPainter, QPen, QFont, QBrush
from qgis.PyQt.QtWidgets import (QFrame, QVBoxLayout, QHBoxLayout, QLabel, QWidget,
                                 QSlider, QDoubleSpinBox, QGridLayout, QTextEdit,
                                 QToolButton, QColorDialog, QSizePolicy, QProgressBar)


def set_invalid(widget, invalid, tip=None):
    """Marca un campo como inválido (borde rojo vía QSS [invalid="true"])."""
    widget.setProperty('invalid', bool(invalid))
    if tip is not None:
        widget.setToolTip(tip if invalid else '')
    st = widget.style()
    st.unpolish(widget)
    st.polish(widget)
    widget.update()


def muted(text, wrap=True):
    lbl = QLabel(text)
    lbl.setObjectName('CardHint')
    lbl.setWordWrap(wrap)
    return lbl


class Card(QFrame):
    """Panel con título opcional, pista y cuerpo."""

    def __init__(self, title=None, hint=None, parent=None):
        super(Card, self).__init__(parent)
        self.setObjectName('Card')
        self.lay = QVBoxLayout(self)
        self.lay.setContentsMargins(14, 12, 14, 14)
        self.lay.setSpacing(8)
        if title:
            head = QHBoxLayout()
            t = QLabel(title)
            t.setObjectName('CardTitle')
            head.addWidget(t)
            head.addStretch()
            self.head = head
            self.lay.addLayout(head)
        if hint:
            self.lay.addWidget(muted(hint))

    def add(self, w, stretch=0):
        if isinstance(w, QWidget):
            self.lay.addWidget(w, stretch)
        else:
            self.lay.addLayout(w, stretch)
        return w


class KpiCard(QFrame):
    def __init__(self, label, value='—', parent=None):
        super(KpiCard, self).__init__(parent)
        self.setObjectName('KpiCard')
        lay = QVBoxLayout(self)
        lay.setContentsMargins(12, 8, 12, 8)
        lay.setSpacing(0)
        self.value = QLabel(value)
        self.value.setObjectName('KpiValue')
        self.label = QLabel(label)
        self.label.setObjectName('KpiLabel')
        lay.addWidget(self.value)
        lay.addWidget(self.label)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)

    def set(self, value, tone=None):
        self.value.setText(value)
        self.value.setProperty('tone', tone or '')
        self.value.style().unpolish(self.value)
        self.value.style().polish(self.value)


class HistogramWidget(QWidget):
    """Histograma con marcas de corte inferior/superior (vista previa de normalización)."""

    def __init__(self, parent=None):
        super(HistogramWidget, self).__init__(parent)
        self.counts, self.edges = [], []
        self.lo = self.hi = None
        self.color = QColor('#f39c12')
        self.fg = QColor('#9aa3b2')
        self.title = ''
        self.setMinimumHeight(150)

    def set_theme(self, pal):
        self.fg = QColor(pal['muted'])
        self.update()

    def set_data(self, counts, edges, title='', color=None):
        self.counts, self.edges, self.title = list(counts), list(edges), title
        if color:
            self.color = QColor(color)
        self.update()

    def set_cuts(self, lo, hi):
        self.lo, self.hi = lo, hi
        self.update()

    def paintEvent(self, _ev):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        r = QRectF(self.rect()).adjusted(8, 18, -8, -18)
        p.setPen(self.fg)
        f = QFont(self.font())
        f.setPointSizeF(max(7.0, f.pointSizeF() - 1))
        p.setFont(f)
        if not self.counts:
            p.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter,
                       'Calcule los índices para ver el histograma')
            return
        p.drawText(QRectF(r.left(), 0, r.width(), 16),
                   Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, self.title)
        mx = max(self.counts) or 1
        n = len(self.counts)
        bw = r.width() / n
        c = QColor(self.color)
        c.setAlpha(190)
        for i, v in enumerate(self.counts):
            h = r.height() * v / mx
            p.fillRect(QRectF(r.left() + i * bw, r.bottom() - h, max(1.0, bw - 1), h), c)
        x0, x1 = self.edges[0], self.edges[-1]

        def xpos(val):
            return r.left() + r.width() * (val - x0) / (x1 - x0 if x1 != x0 else 1)

        p.setPen(self.fg)
        p.drawText(QRectF(r.left(), r.bottom() + 2, 80, 16), Qt.AlignmentFlag.AlignLeft, '%.3g' % x0)
        p.drawText(QRectF(r.right() - 80, r.bottom() + 2, 80, 16), Qt.AlignmentFlag.AlignRight, '%.3g' % x1)
        for val, lbl in ((self.lo, 'Pl'), (self.hi, 'Ph')):
            if val is None:
                continue
            x = min(max(xpos(val), r.left()), r.right())
            pen = QPen(QColor('#e6e6e6') if self.fg.lightness() > 120 else QColor('#1e2229'))
            pen.setStyle(Qt.PenStyle.DashLine)
            pen.setWidthF(1.5)
            p.setPen(pen)
            p.drawLine(QPointF(x, r.top()), QPointF(x, r.bottom()))
            txt = '%s %.3g' % (lbl, val)
            tw = p.fontMetrics().horizontalAdvance(txt) + 6
            if x + tw > r.right():                      # etiqueta a la izquierda de la línea
                p.drawText(QRectF(x - tw, r.top(), tw - 3, 14), Qt.AlignmentFlag.AlignRight, txt)
            else:
                p.drawText(QRectF(x + 3, r.top(), tw, 14), Qt.AlignmentFlag.AlignLeft, txt)


class BarChartWidget(QWidget):
    """Barras horizontales etiquetadas (distribución de clusters, pesos...)."""

    def __init__(self, parent=None):
        super(BarChartWidget, self).__init__(parent)
        self.items = []     # (label, value, QColor, texto_derecha)
        self.fg = QColor('#9aa3b2')
        self.setMinimumHeight(120)

    def set_theme(self, pal):
        self.fg = QColor(pal['muted'])
        self.update()

    def set_items(self, items):
        self.items = items
        self.setMinimumHeight(max(120, 22 * len(items) + 10))
        self.update()

    def paintEvent(self, _ev):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setPen(self.fg)
        if not self.items:
            p.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, 'Sin datos todavía')
            return
        mx = max(v for _, v, _, _ in self.items) or 1
        lw, rw = 44, 70
        r = QRectF(self.rect()).adjusted(4, 4, -4, -4)
        rh = min(22.0, r.height() / len(self.items))
        for i, (lbl, v, col, right) in enumerate(self.items):
            y = r.top() + i * rh
            p.setPen(self.fg)
            p.drawText(QRectF(r.left(), y, lw, rh), Qt.AlignmentFlag.AlignVCenter, lbl)
            w = (r.width() - lw - rw) * v / mx
            p.setBrush(QBrush(QColor(col)))
            p.setPen(Qt.PenStyle.NoPen)
            p.drawRoundedRect(QRectF(r.left() + lw, y + rh * 0.2, max(2.0, w), rh * 0.6), 3, 3)
            p.setPen(self.fg)
            p.drawText(QRectF(r.right() - rw, y, rw, rh),
                       Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignRight, right)


class PercentileRange(QWidget):
    """Par de deslizadores + spinbox sincronizados para Pl / Ph."""
    changed = pyqtSignal(float, float)

    def __init__(self, lo=2.0, hi=98.0, parent=None):
        super(PercentileRange, self).__init__(parent)
        g = QGridLayout(self)
        g.setContentsMargins(0, 0, 0, 0)
        self.s_lo, self.sp_lo = self._pair(g, 0, 'Percentil inferior', 0, 49.5, lo)
        self.s_hi, self.sp_hi = self._pair(g, 1, 'Percentil superior', 50.5, 100, hi)

    def _pair(self, g, row, text, a, b, v):
        s = QSlider(Qt.Orientation.Horizontal)
        s.setRange(int(a * 10), int(b * 10))
        s.setValue(int(v * 10))
        sp = QDoubleSpinBox()
        sp.setRange(a, b)
        sp.setDecimals(1)
        sp.setSingleStep(0.5)
        sp.setValue(v)
        sp.setSuffix(' %')
        sp.setFixedWidth(90)
        s.valueChanged.connect(lambda x: sp.setValue(x / 10.0))
        sp.valueChanged.connect(lambda x: (s.blockSignals(True), s.setValue(int(round(x * 10))),
                                           s.blockSignals(False), self._emit()))
        g.addWidget(QLabel(text), row, 0)
        g.addWidget(s, row, 1)
        g.addWidget(sp, row, 2)
        return s, sp

    def _emit(self):
        self.changed.emit(self.sp_lo.value(), self.sp_hi.value())

    def values(self):
        return self.sp_lo.value(), self.sp_hi.value()

    def set_values(self, lo, hi):
        self.sp_lo.setValue(lo)
        self.sp_hi.setValue(hi)

    def setEnabled(self, e):  # noqa: N802
        super(PercentileRange, self).setEnabled(e)


class ColorButton(QToolButton):
    """Muestra de color editable (clic -> selector de color)."""
    colorChanged = pyqtSignal(str)

    def __init__(self, color='#f39c12', parent=None):
        super(ColorButton, self).__init__(parent)
        self.setFixedSize(22, 22)
        self.set_color(color)
        self.clicked.connect(self._pick)
        self.setCursor(Qt.CursorShape.PointingHandCursor)

    def set_color(self, c):
        self._c = c
        self.setStyleSheet('QToolButton{background:%s;border:1px solid #3a3f4b;border-radius:4px;}' % c)

    def color(self):
        return self._c

    def _pick(self):
        c = QColorDialog.getColor(QColor(self._c), self)
        if c.isValid():
            self.set_color(c.name())
            self.colorChanged.emit(c.name())


class WeightBar(QProgressBar):
    """Barra delgada que muestra el peso relativo (%) de una evidencia."""

    def __init__(self, parent=None):
        super(WeightBar, self).__init__(parent)
        self.setObjectName('WeightBar')
        self.setRange(0, 1000)
        self.setTextVisible(False)
        self.setMinimumWidth(80)

    def set_fraction(self, f):
        self.setValue(int(round(1000 * max(0.0, min(1.0, f)))))
        self.setToolTip('%.1f %% del peso total' % (100 * f))


class ConfusionMatrix(QWidget):
    def __init__(self, parent=None):
        super(ConfusionMatrix, self).__init__(parent)
        g = QGridLayout(self)
        g.setSpacing(4)
        heads = ['', 'Predicho: target', 'Predicho: fondo']
        for c, h in enumerate(heads):
            lbl = QLabel(h)
            lbl.setObjectName('KpiLabel')
            lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
            g.addWidget(lbl, 0, c)
        self.cells = {}
        for r, name in enumerate(['Ocurrencia real', 'Fondo (pseudo-negativo)'], start=1):
            lbl = QLabel(name)
            lbl.setObjectName('KpiLabel')
            g.addWidget(lbl, r, 0)
            for c, key in enumerate((['tp', 'fn'] if r == 1 else ['fp', 'tn']), start=1):
                v = QLabel('—')
                v.setObjectName('KpiValue')
                v.setAlignment(Qt.AlignmentFlag.AlignCenter)
                v.setMinimumHeight(46)
                v.setStyleSheet('border-radius:6px;')
                g.addWidget(v, r, c)
                self.cells[key] = v
        self._pal = None

    def set_theme(self, pal):
        self._pal = pal

    def set_values(self, m, pal):
        tot = float(max(1, m['tp'] + m['fn'] + m['fp'] + m['tn']))
        for k, good in (('tp', True), ('tn', True), ('fn', False), ('fp', False)):
            c = QColor(pal['ok'] if good else pal['err'])
            c.setAlpha(int(40 + 160 * m[k] / tot))
            self.cells[k].setText(str(m[k]))
            self.cells[k].setStyleSheet('border-radius:6px;background:rgba(%d,%d,%d,%d);'
                                        % (c.red(), c.green(), c.blue(), c.alpha()))


class LogPanel(QTextEdit):
    """Registro en tiempo real con niveles coloreados."""
    COLORS = {'INFO': '#74b9ff', 'OK': '#00b894', 'WARN': '#f39c12', 'ERROR': '#e74c3c'}

    def __init__(self, parent=None):
        super(LogPanel, self).__init__(parent)
        self.setObjectName('LogPanel')
        self.setReadOnly(True)
        self.document().setMaximumBlockCount(2000)

    def add(self, level, msg):
        ts = datetime.datetime.now().strftime('%H:%M:%S')
        col = self.COLORS.get(level, '#9aa3b2')
        self.append('<span style="color:#9aa3b2">%s</span> <b style="color:%s">%-5s</b> %s'
                    % (ts, col, level, html.escape(msg).replace('\n', '<br>')))
        sb = self.verticalScrollBar()
        sb.setValue(sb.maximum())
