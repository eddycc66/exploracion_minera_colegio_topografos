# -*- coding: utf-8 -*-
"""
Iconos vectoriales (SVG en línea, trazo de 2 px, estilo lineal) que toman el color
del tema. Al ser vectoriales se ven nítidos en pantallas HiDPI.
"""
from qgis.PyQt.QtCore import QByteArray, QSize, Qt
from qgis.PyQt.QtGui import QIcon, QPixmap, QPainter
try:
    from qgis.PyQt.QtSvg import QSvgRenderer
except ImportError:          # instalación sin módulo QtSvg: iconos vacíos, la UI sigue funcionando
    QSvgRenderer = None

_P = {
    'config': '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M4.2 4.2l2.1 2.1M17.7 17.7l2.1 2.1M2 12h3M19 12h3M4.2 19.8l2.1-2.1M17.7 6.3l2.1-2.1"/>',
    'normalize': '<path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6"/>',
    'stack': '<path d="M12 2 2 7l10 5 10-5-10-5z"/><path d="m2 17 10 5 10-5"/><path d="m2 12 10 5 10-5"/>',
    'kmeans': '<circle cx="6" cy="7" r="2.5"/><circle cx="17" cy="6" r="2.5"/><circle cx="8" cy="17" r="2.5"/><circle cx="18" cy="16" r="2.5"/><path d="M8.3 8.6 16 14.6M15 7.5 9.5 15.4"/>',
    'mineral': '<path d="M6 3h12l4 6-10 12L2 9z"/><path d="M2 9h20M9 3l3 18M15 3l-3 18"/>',
    'integrated': '<circle cx="9" cy="9" r="6"/><circle cx="15" cy="15" r="6"/>',
    'targets': '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/><path d="M12 1v3M12 20v3M1 12h3M20 12h3"/>',
    'validation': '<path d="M22 11.1V12a10 10 0 1 1-5.9-9.1"/><path d="M22 4 12 14l-3-3"/>',
    'reports': '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M8 13h8M8 17h8M8 9h2"/>',
    'help': '<circle cx="12" cy="12" r="10"/><path d="M9.1 9a3 3 0 0 1 5.8 1c0 2-3 3-3 3M12 17h.01"/>',
    'sun': '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
    'moon': '<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/>',
    'compact': '<path d="M4 14h6v6M20 10h-6V4M14 10l7-7M3 21l7-7"/>',
    'play': '<path d="m6 3 14 9-14 9z"/>',
    'left': '<path d="m15 18-6-6 6-6"/>',
    'right': '<path d="m9 18 6-6-6-6"/>',
    'stop': '<rect x="5" y="5" width="14" height="14" rx="2"/>',
    'folder': '<path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>',
    'search': '<circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/>',
    'zoom': '<circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3M11 8v6M8 11h6"/>',
    'save': '<path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><path d="M17 21v-8H7v8M7 3v5h8"/>',
    'open': '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M17 8l-5-5-5 5M12 3v12"/>',
    'download': '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/>',
    'log': '<path d="M4 6h16M4 12h16M4 18h10"/>',
    'check': '<path d="M20 6 9 17l-5-5"/>',
    'plus': '<path d="M12 5v14M5 12h14"/>',
    'up': '<path d="m18 15-6-6-6 6"/>',
    'down': '<path d="m6 9 6 6 6-6"/>',
}

STEP_ICONS = ['config', 'normalize', 'stack', 'kmeans', 'mineral', 'integrated',
              'targets', 'validation', 'reports']


def svg(name, color='#e6e6e6', width=2.0):
    return ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" '
            'stroke="%s" stroke-width="%s" stroke-linecap="round" stroke-linejoin="round">%s</svg>'
            % (color, width, _P.get(name, _P['help'])))


def icon(name, color='#e6e6e6', size=48):
    """QIcon renderizado desde SVG (tamaño base alto para HiDPI)."""
    pm = QPixmap(QSize(size, size))
    pm.fill(Qt.GlobalColor.transparent)
    if QSvgRenderer is None:
        return QIcon(pm)
    renderer = QSvgRenderer(QByteArray(svg(name, color).encode('utf-8')))
    p = QPainter(pm)
    renderer.render(p)
    p.end()
    return QIcon(pm)
