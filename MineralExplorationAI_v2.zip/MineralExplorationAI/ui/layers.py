# -*- coding: utf-8 -*-
"""
Carga de resultados en el proyecto QGIS (siempre en el hilo principal) con
simbología consistente y agrupada. Reemplaza capas previas con la misma fuente
para no duplicar capas al re-ejecutar un paso (fuga de memoria en v1).
"""
import os

from qgis.PyQt.QtGui import QColor
from qgis.core import (QgsProject, QgsRasterLayer, QgsVectorLayer, QgsColorRampShader,
                       QgsRasterShader, QgsSingleBandPseudoColorRenderer,
                       QgsPalettedRasterRenderer, QgsCategorizedSymbolRenderer,
                       QgsRendererCategory, QgsSymbol)

from ..compat import ramp_type

GROUP = 'GeoMineral AI'

FAV_RAMP = [(0.0, '#2c3e70'), (0.25, '#3a7bd5'), (0.5, '#f1c40f'),
            (0.7, '#e67e22'), (0.85, '#e74c3c'), (1.0, '#8e1b1b')]
PRIO_COLORS = {'PRIORIDAD 1': '#e74c3c', 'PRIORIDAD 2': '#f39c12', 'PRIORIDAD 3': '#00b894'}


def _group(sub=None):
    root = QgsProject.instance().layerTreeRoot()
    g = root.findGroup(GROUP)
    if g is None:
        g = root.insertGroup(0, GROUP)
    if sub:
        s = g.findGroup(sub)
        if s is None:
            s = g.addGroup(sub)
        return s
    return g


def _remove_same_source(path):
    norm = os.path.normcase(os.path.abspath(path))
    prj = QgsProject.instance()
    for lyr in list(prj.mapLayers().values()):
        src = lyr.source().split('|')[0]
        try:
            if os.path.normcase(os.path.abspath(src)) == norm:
                prj.removeMapLayer(lyr.id())
        except Exception:
            pass


def _add(layer, sub=None):
    QgsProject.instance().addMapLayer(layer, False)
    _group(sub).insertLayer(0, layer)
    return layer


def _ramp(layer, items, vmin=0.0, vmax=1.0):
    shader_fn = QgsColorRampShader(vmin, vmax)
    shader_fn.setColorRampType(ramp_type('Interpolated'))
    shader_fn.setColorRampItemList([
        QgsColorRampShader.ColorRampItem(vmin + (vmax - vmin) * v, QColor(c), '%.2f' % (vmin + (vmax - vmin) * v))
        for v, c in items])
    sh = QgsRasterShader()
    sh.setRasterShaderFunction(shader_fn)
    layer.setRenderer(QgsSingleBandPseudoColorRenderer(layer.dataProvider(), 1, sh))


def styled_raster(path, name, style='fav', color=None, stats=None):
    """Capa raster con simbología, sin añadirla al proyecto (también para el reporte)."""
    lyr = QgsRasterLayer(path, name, 'gdal')
    if not lyr.isValid():
        return None
    if style == 'fav':
        _ramp(lyr, FAV_RAMP)
    elif style == 'index':
        c = QColor(color or '#f39c12')
        lo, hi = (stats or {}).get('p2', 0.0), (stats or {}).get('p98', 1.0)
        if not hi > lo:
            lo, hi = 0.0, 1.0
        _ramp(lyr, [(0.0, '#1e2229'), (0.5, c.darker(150).name()), (1.0, c.name())], lo, hi)
    elif style == 'norm':
        c = QColor(color or '#f39c12')
        _ramp(lyr, [(0.0, '#1e2229'), (0.6, c.darker(140).name()), (1.0, c.name())])
    lyr.triggerRepaint()
    return lyr


def add_raster(path, name, style='fav', color=None, sub=None, stats=None):
    if not path or not os.path.exists(path):
        return None
    _remove_same_source(path)
    lyr = styled_raster(path, name, style, color, stats)
    return _add(lyr, sub) if lyr is not None else None


def add_clusters(path, name, colors, labels):
    _remove_same_source(path)
    lyr = QgsRasterLayer(path, name, 'gdal')
    if not lyr.isValid():
        return None
    classes = [QgsPalettedRasterRenderer.Class(i, QColor(*colors[i]), labels[i])
               for i in range(len(colors))]
    lyr.setRenderer(QgsPalettedRasterRenderer(lyr.dataProvider(), 1, classes))
    lyr.triggerRepaint()
    return _add(lyr)


def add_targets(path, name='Targets'):
    _remove_same_source(path)
    lyr = styled_targets(path, name)
    return _add(lyr) if lyr is not None else None


def styled_targets(path, name='Targets'):
    lyr = QgsVectorLayer(path, name, 'ogr')
    if not lyr.isValid():
        return None
    cats = []
    for label, col in PRIO_COLORS.items():
        sym = QgsSymbol.defaultSymbol(lyr.geometryType())
        sym.setColor(QColor(col))
        sym.setOpacity(0.55)
        try:
            sym.symbolLayer(0).setStrokeColor(QColor(col).darker(140))
            sym.symbolLayer(0).setStrokeWidth(0.5)
        except Exception:
            pass
        cats.append(QgsRendererCategory(label, sym, label.title()))
    lyr.setRenderer(QgsCategorizedSymbolRenderer('prioridad', cats))
    lyr.triggerRepaint()
    return lyr
