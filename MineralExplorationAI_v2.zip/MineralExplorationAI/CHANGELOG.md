# Changelog

## 2.0.0 — 2026-09-22

### Corregido
- Instalación en QGIS 3.22+ (`qgisMinimumVersion` era 4.0).
- El plugin ya no falla al cargar sin scikit-learn (importación diferida; motor K-Means NumPy).
- Lectura raster: tipos de dato, buffers de solo lectura, NoData no declarado y DN 0.
- Fórmulas de índices: caolinita, sericita, propilítica, OH/Mg-OH, sílice y carbonatos
  (ver `docs/INDICES.md`).
- División por cero: NaN en lugar de `+0.001`.
- Alineación de grillas con GDAL (TIR 90→30 m bilineal, VNIR 15→30 m promedio).
- Pendiente y lineamientos con tamaño de píxel en metros.
- Área de targets por latitud; puntaje zonal; validación al borde del polígono y con reproyección.
- Cierre del diálogo con un hilo en ejecución.
- PDF sin datos o fallido sin ReportLab.
- La prospectividad integrada ya no puntúa zonas sin datos ASTER.

### Compatibilidad
- QGIS 3.22 → 4.x: tipos y filtros de capa, rampas de color, enums Qt con alcance, QAction/QShortcut,
  exec/print, márgenes PDF, códigos de QgsVectorFileWriter y driver OGR en memoria (GDAL 3.11+)
  resueltos en `compat.py`.
- Probado en QGIS 3.34.4 real (Qt 5.15) y en PyQt6 6.11 con la API de QGIS 4 simulada.
- Icono del plugin en SVG.

### Añadido
- Interfaz tipo dashboard con 9 pasos: tema claro/oscuro, modo compacto, ES/EN,
  atajos, persistencia y registro coloreado.
- Autodetección de bandas; calibración DN→radiancia→reflectancia; máscaras NDVI y de sombras.
- Índices ALI, RBD5, KLI, RBD6, RBD8, clorita, OHI, CLI, Fe²⁺, gossan, QI, SiO₂, CI, MI.
- Modelos de pesos: epitermal AS, epitermal BS y pórfido.
- Validación con matriz de confusión, OA, Kappa, precisión, recall, F1 y ganancia espacial.
- Reporte PDF/HTML con mapas renderizados; exportación GPKG/SHP/GeoJSON/CSV.
- Pruebas automatizadas (núcleo y UI) con escena ASTER sintética.

### Eliminado
- Dock heredado (sus funciones se integraron en los 9 pasos), inspector espectral
  (hoja de ruta), campo de contraseña sin uso, presupuestos USD/ha y dependencias de
  ReportLab, matplotlib y pandas.
