# -*- coding: utf-8 -*-
"""
Constantes físicas y de sensor para ASTER (Terra).

Fuentes:
  - ASTER User Handbook v2 (Abrams, Hook & Ramachandran, 2002): centros de banda,
    resolución y Unit Conversion Coefficients (UCC).
  - Thome et al. (2001) / Smith (2007): irradiancia solar exoatmosférica (ESUN).
"""

EPS = 1e-6            # Denominador mínimo para divisiones seguras
NODATA = -9999.0      # NoData de todas las salidas float32
NODATA_INT = -1       # NoData de rasters de clases (clusters)

# ---------------------------------------------------------------------------
# Bandas ASTER: centro (µm), subsistema, resolución nativa (m)
# ---------------------------------------------------------------------------
ASTER_BANDS = {
    'B1':  {'center': 0.556,  'sub': 'VNIR', 'res': 15},
    'B2':  {'center': 0.661,  'sub': 'VNIR', 'res': 15},
    'B3':  {'center': 0.807,  'sub': 'VNIR', 'res': 15},   # B3N (nadir)
    'B4':  {'center': 1.656,  'sub': 'SWIR', 'res': 30},
    'B5':  {'center': 2.167,  'sub': 'SWIR', 'res': 30},
    'B6':  {'center': 2.209,  'sub': 'SWIR', 'res': 30},
    'B7':  {'center': 2.262,  'sub': 'SWIR', 'res': 30},
    'B8':  {'center': 2.336,  'sub': 'SWIR', 'res': 30},
    'B9':  {'center': 2.400,  'sub': 'SWIR', 'res': 30},
    'B10': {'center': 8.291,  'sub': 'TIR',  'res': 90},
    'B11': {'center': 8.634,  'sub': 'TIR',  'res': 90},
    'B12': {'center': 9.075,  'sub': 'TIR',  'res': 90},
    'B13': {'center': 10.657, 'sub': 'TIR',  'res': 90},
    'B14': {'center': 11.318, 'sub': 'TIR',  'res': 90},
}
BAND_ORDER = ['B1', 'B2', 'B3', 'B4', 'B5', 'B6', 'B7', 'B8', 'B9',
              'B10', 'B11', 'B12', 'B13', 'B14']
VNIR = BAND_ORDER[0:3]
SWIR = BAND_ORDER[3:9]
TIR = BAND_ORDER[9:14]

# ---------------------------------------------------------------------------
# Unit Conversion Coefficients  L = (DN - 1) * UCC   [W m-2 sr-1 µm-1]
# Ganancias: HGH (alta), NOR (normal), LO1 (baja 1), LO2 (baja 2, solo SWIR)
# ---------------------------------------------------------------------------
UCC = {
    'B1':  {'HGH': 0.676,  'NOR': 1.688,  'LO1': 2.25},
    'B2':  {'HGH': 0.708,  'NOR': 1.415,  'LO1': 1.89},
    'B3':  {'HGH': 0.423,  'NOR': 0.862,  'LO1': 1.15},
    'B4':  {'HGH': 0.1087, 'NOR': 0.2174, 'LO1': 0.2900, 'LO2': 0.2900},
    'B5':  {'HGH': 0.0348, 'NOR': 0.0696, 'LO1': 0.0925, 'LO2': 0.4090},
    'B6':  {'HGH': 0.0313, 'NOR': 0.0625, 'LO1': 0.0830, 'LO2': 0.3900},
    'B7':  {'HGH': 0.0299, 'NOR': 0.0597, 'LO1': 0.0795, 'LO2': 0.3320},
    'B8':  {'HGH': 0.0209, 'NOR': 0.0417, 'LO1': 0.0556, 'LO2': 0.2450},
    'B9':  {'HGH': 0.0159, 'NOR': 0.0318, 'LO1': 0.0424, 'LO2': 0.2650},
    'B10': {'NOR': 0.006822},
    'B11': {'NOR': 0.006780},
    'B12': {'NOR': 0.006590},
    'B13': {'NOR': 0.005693},
    'B14': {'NOR': 0.005225},
}

# Irradiancia solar exoatmosférica media (W m-2 µm-1) — Thome et al. (2001)
ESUN = {
    'B1': 1845.99, 'B2': 1555.74, 'B3': 1119.47,
    'B4': 231.25, 'B5': 79.81, 'B6': 74.99,
    'B7': 68.66, 'B8': 59.74, 'B9': 56.92,
}

# Tipos de unidad de entrada
UNITS_DN = 'dn'                 # Números digitales L1A/L1B/L1T
UNITS_RADIANCE = 'radiance'     # Radiancia en sensor
UNITS_REFLECTANCE = 'reflectance'  # Reflectancia (AST_07/07XT o corregida)
