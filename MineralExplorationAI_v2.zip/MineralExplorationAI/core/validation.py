# -*- coding: utf-8 -*-
"""
Validación de targets contra ocurrencias conocidas.

Correcciones frente a v1:
  * La distancia se mide al BORDE del polígono (0 si la ocurrencia está dentro).
    v1 medía al centroide: una ocurrencia dentro de un target grande podía contar
    como "fallo".
  * Las ocurrencias se reproyectan al CRS de los targets (v1 no reproyectaba).
  * Distancias en metros en un CRS métrico (UTM local si los datos son geográficos).
  * Métricas de clasificación con puntos de fondo aleatorios como negativos:
    matriz de confusión, OA, Kappa de Cohen, precisión, recall (tasa de éxito), F1.
  * Eficiencia espacial: % de ocurrencias capturadas vs % del área marcada como target.

Advertencia: los puntos de fondo son "pseudo-negativos" (no se sabe si están
mineralizados). OA y Kappa deben leerse como indicadores relativos entre modelos.
"""
import math

import numpy as np
from osgeo import gdal, ogr, osr

from . import raster_io as rio

ogr.UseExceptions()


def _trad(s):
    s = s.Clone()
    s.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)
    return s


def _metric_srs(srs, lon, lat):
    if not srs.IsGeographic():
        return srs
    m = osr.SpatialReference()
    m.ImportFromEPSG((32600 if lat >= 0 else 32700) + int((lon + 180) // 6) + 1)
    return _trad(m)


def _read_points(path, dst_srs):
    ds = ogr.Open(path)
    lyr = ds.GetLayer(0)
    src = lyr.GetSpatialRef()
    ct = osr.CoordinateTransformation(_trad(src), dst_srs) if src is not None else None
    pts = []
    names = [lyr.GetLayerDefn().GetFieldDefn(i).GetName()
             for i in range(lyr.GetLayerDefn().GetFieldCount())]
    id_field = next((n for n in names if n.lower() in
                     ('name', 'nombre', 'id', 'codigo', 'code', 'occ_id')), None)
    for i, f in enumerate(lyr):
        g = f.GetGeometryRef()
        if g is None:
            continue
        g = g.Clone()
        if g.GetGeometryType() not in (ogr.wkbPoint, ogr.wkbPoint25D):
            g = g.Centroid()
        if ct is not None:
            g.Transform(ct)
        oid = f.GetField(id_field) if id_field else None
        pts.append((str(oid) if oid not in (None, '') else 'OCC_%03d' % (i + 1),
                    g.GetX(), g.GetY()))
    ds = None
    return pts


def _read_targets(path):
    ds = ogr.Open(path)
    lyr = ds.GetLayer(0)
    srs = _trad(lyr.GetSpatialRef())
    out = []
    for f in lyr:
        g = f.GetGeometryRef()
        if g is None:
            continue
        out.append({'target_id': f.GetField('target_id'),
                    'prioridad': f.GetField('prioridad'),
                    'geom': g.Clone()})
    ds = None
    return out, srs


def _nearest(pt, targets):
    best, dmin = None, float('inf')
    for t in targets:
        d = t['mgeom'].Distance(pt)
        if d < dmin:
            dmin, best = d, t
    return best, dmin


def kappa(tp, fn, fp, tn):
    n = float(tp + fn + fp + tn)
    if n == 0:
        return 0.0
    po = (tp + tn) / n
    pe = ((tp + fp) * (tp + fn) + (fn + tn) * (fp + tn)) / (n * n)
    return 0.0 if pe >= 1 else (po - pe) / (1 - pe)


def validate(targets_path, occ_path, prosp_path, buffer_m=250.0, neg_ratio=3.0,
             seed=42, target_label_path=None, progress=None):
    targets, tsrs = _read_targets(targets_path)
    if not targets:
        raise ValueError("La capa de targets está vacía.")
    occ = _read_points(occ_path, tsrs)
    if not occ:
        raise ValueError("La capa de ocurrencias no tiene geometrías.")

    # CRS métrico para distancias
    env = targets[0]['geom'].GetEnvelope()
    cx, cy = (env[0] + env[1]) / 2, (env[2] + env[3]) / 2
    if tsrs.IsGeographic():
        lon, lat = cx, cy
    else:
        to_w = osr.CoordinateTransformation(tsrs, _trad(osr.SpatialReference(osr.SRS_WKT_WGS84_LAT_LONG)))
        lon, lat = to_w.TransformPoint(cx, cy)[:2]
    msrs = _metric_srs(tsrs, lon, lat)
    ct = None if msrs is tsrs else osr.CoordinateTransformation(tsrs, msrs)
    for t in targets:
        g = t['geom'].Clone()
        if ct:
            g.Transform(ct)
        t['mgeom'] = g

    def mpoint(x, y):
        p = ogr.Geometry(ogr.wkbPoint)
        p.AddPoint_2D(x, y)
        if ct:
            p.Transform(ct)
        return p

    if progress:
        progress(20, "Distancias de %d ocurrencias" % len(occ))
    rows, occ_m = [], []
    for oid, x, y in occ:
        p = mpoint(x, y)
        occ_m.append(p)
        t, d = _nearest(p, targets)
        rows.append({'occ_id': oid, 'x': x, 'y': y,
                     'target': t['target_id'] if t else 'N/A',
                     'prioridad': t['prioridad'] if t else 'N/A',
                     'dist_m': round(d, 1), 'hit': d <= buffer_m})

    # Pseudo-negativos dentro del área válida del raster de prospectividad
    grid = rio.Grid.from_path(prosp_path)
    prosp = rio.read_band(prosp_path, 1)
    valid_idx = np.flatnonzero(np.isfinite(prosp.ravel()))
    rng = np.random.default_rng(seed)
    n_neg = int(max(20, round(neg_ratio * len(occ))))
    negs = []
    tries = 0
    if progress:
        progress(55, "Muestreando %d puntos de fondo" % n_neg)
    while len(negs) < n_neg and tries < n_neg * 20 and valid_idx.size:
        tries += 1
        k = valid_idx[rng.integers(valid_idx.size)]
        r, c = divmod(int(k), grid.width)
        x = grid.gt[0] + (c + 0.5) * grid.gt[1]
        y = grid.gt[3] + (r + 0.5) * grid.gt[5]
        # grid y targets comparten CRS (ambos provienen del raster de prospectividad)
        p = mpoint(x, y)
        if any(p.Distance(o) <= buffer_m for o in occ_m):
            continue
        _, d = _nearest(p, targets)
        negs.append(d <= buffer_m)

    tp = sum(1 for r in rows if r['hit'])
    fn = len(rows) - tp
    fp = sum(1 for h in negs if h)
    tn = len(negs) - fp
    n = tp + fn + fp + tn
    prec = tp / float(tp + fp) if (tp + fp) else 0.0
    rec = tp / float(tp + fn) if (tp + fn) else 0.0
    f1 = 2 * prec * rec / (prec + rec) if (prec + rec) else 0.0

    # Eficiencia espacial
    area_pct = None
    if target_label_path:
        lbl = rio.read_band(target_label_path, 1)
        valid = np.isfinite(prosp)
        area_pct = 100.0 * float(np.sum(np.isfinite(lbl) & (lbl > 0) & valid)) / max(1, valid.sum())
    success = 100.0 * rec
    metrics = {
        'tp': tp, 'fn': fn, 'fp': fp, 'tn': tn, 'n': n,
        'oa': (tp + tn) / float(n) if n else 0.0,
        'kappa': kappa(tp, fn, fp, tn),
        'precision': prec, 'recall': rec, 'f1': f1,
        'success_pct': success,
        'area_pct': area_pct,
        'gain': (success / area_pct) if area_pct else None,
        'buffer_m': buffer_m, 'n_occ': len(rows), 'n_bg': len(negs),
        'dist_mean_m': float(np.mean([r['dist_m'] for r in rows])) if rows else 0.0,
    }
    if progress:
        progress(100, "Validación completada")
    return rows, metrics


def interpret(m):
    k = m['kappa']
    if k >= 0.8:
        q = "Concordancia casi perfecta"
    elif k >= 0.6:
        q = "Concordancia sustancial"
    elif k >= 0.4:
        q = "Concordancia moderada"
    elif k >= 0.2:
        q = "Concordancia débil"
    else:
        q = "Concordancia pobre"
    txt = "%s (Kappa %.2f; Landis & Koch, 1977). Éxito %.0f %%." % (q, k, m['success_pct'])
    if m.get('gain'):
        txt += (" Los targets ocupan %.1f %% del área y capturan %.0f %% de las "
                "ocurrencias (ganancia x%.1f frente al azar)."
                % (m['area_pct'], m['success_pct'], m['gain']))
    return txt
