# -*- coding: utf-8 -*-
"""
E/S raster con GDAL: lectura con NoData -> NaN, alineación a una grilla de
referencia (CRS + extensión + tamaño de píxel), remuestreo explícito y escritura
Float32 con NoData = -9999.

Este módulo NO importa Qt ni QGIS: puede ejecutarse en hilos de trabajo.
"""
import math
import os

import numpy as np
from osgeo import gdal, osr

from .constants import NODATA

gdal.UseExceptions()

_RESAMPLE = {
    'nearest': gdal.GRA_NearestNeighbour,
    'bilinear': gdal.GRA_Bilinear,
    'cubic': gdal.GRA_Cubic,
    'average': gdal.GRA_Average,
    'mode': gdal.GRA_Mode,
}


class Grid(object):
    """Describe una grilla raster: tamaño, geotransform y CRS (WKT)."""

    def __init__(self, width, height, gt, wkt):
        self.width = int(width)
        self.height = int(height)
        self.gt = tuple(float(v) for v in gt)
        self.wkt = wkt or ''

    @classmethod
    def from_path(cls, path):
        ds = gdal.Open(path)
        try:
            return cls(ds.RasterXSize, ds.RasterYSize, ds.GetGeoTransform(),
                       ds.GetProjection())
        finally:
            ds = None

    @property
    def shape(self):
        return (self.height, self.width)

    @property
    def res(self):
        return (abs(self.gt[1]), abs(self.gt[5]))

    @property
    def bounds(self):
        """(xmin, ymin, xmax, ymax) para grillas sin rotación."""
        x0, dx, _, y0, _, dy = self.gt
        x1 = x0 + dx * self.width
        y1 = y0 + dy * self.height
        return (min(x0, x1), min(y0, y1), max(x0, x1), max(y0, y1))

    def srs(self):
        s = osr.SpatialReference()
        if self.wkt:
            s.ImportFromWkt(self.wkt)
        s.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)
        return s

    def is_geographic(self):
        return bool(self.wkt) and bool(self.srs().IsGeographic())

    def same_as(self, other, tol=1e-6):
        if (self.width, self.height) != (other.width, other.height):
            return False
        if any(abs(a - b) > tol * max(1.0, abs(a)) for a, b in zip(self.gt, other.gt)):
            return False
        if self.wkt and other.wkt:
            a, b = self.srs(), other.srs()
            return bool(a.IsSame(b))
        return True

    def cropped_to(self, bounds):
        """Nueva grilla alineada a la actual, recortada a bounds (mismo CRS)."""
        xmin, ymin, xmax, ymax = bounds
        x0, dx, _, y0, _, dy = self.gt
        c0 = max(0, int(math.floor((xmin - x0) / dx)))
        c1 = min(self.width, int(math.ceil((xmax - x0) / dx)))
        r0 = max(0, int(math.floor((ymax - y0) / dy)))
        r1 = min(self.height, int(math.ceil((ymin - y0) / dy)))
        if c1 <= c0 or r1 <= r0:
            raise ValueError("El AOI no se superpone con la imagen de referencia.")
        gt = (x0 + c0 * dx, dx, 0.0, y0 + r0 * dy, 0.0, dy)
        return Grid(c1 - c0, r1 - r0, gt, self.wkt)

    def resampled(self, pixel_size):
        """Nueva grilla con el tamaño de píxel pedido y la misma extensión."""
        xmin, ymin, xmax, ymax = self.bounds
        w = max(1, int(round((xmax - xmin) / pixel_size)))
        h = max(1, int(round((ymax - ymin) / pixel_size)))
        return Grid(w, h, (xmin, pixel_size, 0.0, ymax, 0.0, -pixel_size), self.wkt)


# ---------------------------------------------------------------------------
# Lectura
# ---------------------------------------------------------------------------

def clean_source(uri):
    """Quita sufijos de URI de QGIS ('|layername=..', '|option:..')."""
    if uri is None:
        return None
    return uri.split('|')[0]


def band_count(path):
    ds = gdal.Open(path)
    try:
        return ds.RasterCount
    finally:
        ds = None


def band_descriptions(path):
    ds = gdal.Open(path)
    try:
        return [ds.GetRasterBand(i).GetDescription() or ''
                for i in range(1, ds.RasterCount + 1)]
    finally:
        ds = None


def read_band(path, band=1, extra_nodata=None):
    """
    Lee una banda como float32 con NaN en NoData.

    extra_nodata: valores adicionales a enmascarar (p.ej. 0 = relleno en ASTER DN).
    """
    ds = gdal.Open(path)
    try:
        b = ds.GetRasterBand(int(band))
        arr = b.ReadAsArray().astype(np.float32, copy=True)   # copia escribible
        nd = b.GetNoDataValue()
        if nd is not None and not (isinstance(nd, float) and math.isnan(nd)):
            arr[arr == np.float32(nd)] = np.nan
        for v in (extra_nodata or []):
            arr[arr == np.float32(v)] = np.nan
        arr[~np.isfinite(arr)] = np.nan
        return arr
    finally:
        ds = None


def warp_band_to_grid(path, band, grid, resample='bilinear', extra_nodata=None):
    """
    Lee `band` de `path` reproyectada/remuestreada exactamente a `grid`.

    Todos los NoData de origen (valor declarado, `extra_nodata` como el DN=0 de
    relleno ASTER, NaN/Inf) se unifican ANTES de interpolar, de modo que el
    remuestreo bilineal/promedio nunca mezcla valores de relleno con datos.
    """
    src = gdal.Open(path)
    try:
        src_grid = Grid(src.RasterXSize, src.RasterYSize, src.GetGeoTransform(),
                        src.GetProjection())
        arr = read_band(path, band, extra_nodata)
        if src_grid.same_as(grid):
            return arr
        mem = gdal.GetDriverByName('MEM').Create('', src_grid.width, src_grid.height, 1,
                                                 gdal.GDT_Float32)
        mem.SetGeoTransform(src_grid.gt)
        if src_grid.wkt:
            mem.SetProjection(src_grid.wkt)
        mb = mem.GetRasterBand(1)
        mb.SetNoDataValue(float(NODATA))
        tmp = arr.copy()
        tmp[np.isnan(tmp)] = NODATA
        mb.WriteArray(tmp)
        del tmp, arr

        dst = gdal.GetDriverByName('MEM').Create('', grid.width, grid.height, 1,
                                                 gdal.GDT_Float32)
        dst.SetGeoTransform(grid.gt)
        if grid.wkt:
            dst.SetProjection(grid.wkt)
        db = dst.GetRasterBand(1)
        db.SetNoDataValue(float(NODATA))
        db.Fill(float(NODATA))
        opts = gdal.WarpOptions(resampleAlg=_RESAMPLE.get(resample, gdal.GRA_Bilinear),
                                srcNodata=float(NODATA), dstNodata=float(NODATA),
                                multithread=True, warpOptions=['INIT_DEST=NO_DATA'])
        gdal.Warp(dst, mem, options=opts)
        out = db.ReadAsArray().astype(np.float32, copy=True)
        out[out == np.float32(NODATA)] = np.nan
        out[~np.isfinite(out)] = np.nan
        mem = None
        dst = None
        return out
    finally:
        src = None


# ---------------------------------------------------------------------------
# Escritura
# ---------------------------------------------------------------------------

_CO_FLOAT = ['COMPRESS=DEFLATE', 'PREDICTOR=3', 'TILED=YES', 'BIGTIFF=IF_SAFER']
_CO_INT = ['COMPRESS=DEFLATE', 'PREDICTOR=2', 'TILED=YES', 'BIGTIFF=IF_SAFER']


def _prepare_out(path):
    d = os.path.dirname(os.path.abspath(path))
    os.makedirs(d, exist_ok=True)
    if os.path.exists(path):
        gdal.GetDriverByName('GTiff').Delete(path)


def write_float(path, arr, grid, description=None, nodata=NODATA):
    """Escribe un array 2D como GeoTIFF Float32 con NaN -> NoData."""
    _prepare_out(path)
    ds = gdal.GetDriverByName('GTiff').Create(path, grid.width, grid.height, 1,
                                              gdal.GDT_Float32, options=_CO_FLOAT)
    try:
        ds.SetGeoTransform(grid.gt)
        if grid.wkt:
            ds.SetProjection(grid.wkt)
        b = ds.GetRasterBand(1)
        b.SetNoDataValue(float(nodata))
        out = np.asarray(arr, dtype=np.float32).copy()
        out[~np.isfinite(out)] = nodata
        b.WriteArray(out)
        if description:
            b.SetDescription(description)
        b.ComputeStatistics(False)
    finally:
        ds = None
    return path


def write_stack(path, arrays, names, grid, nodata=NODATA):
    """Escribe un GeoTIFF multibanda Float32 (una banda por array)."""
    _prepare_out(path)
    ds = gdal.GetDriverByName('GTiff').Create(path, grid.width, grid.height, len(arrays),
                                              gdal.GDT_Float32,
                                              options=_CO_FLOAT + ['INTERLEAVE=BAND'])
    try:
        ds.SetGeoTransform(grid.gt)
        if grid.wkt:
            ds.SetProjection(grid.wkt)
        for i, (a, n) in enumerate(zip(arrays, names), start=1):
            b = ds.GetRasterBand(i)
            b.SetNoDataValue(float(nodata))
            out = np.asarray(a, dtype=np.float32).copy()
            out[~np.isfinite(out)] = nodata
            b.WriteArray(out)
            b.SetDescription(str(n))
    finally:
        ds = None
    return path


def write_int(path, arr, grid, nodata=-1, gdal_type=gdal.GDT_Int16, description=None):
    _prepare_out(path)
    ds = gdal.GetDriverByName('GTiff').Create(path, grid.width, grid.height, 1,
                                              gdal_type, options=_CO_INT)
    try:
        ds.SetGeoTransform(grid.gt)
        if grid.wkt:
            ds.SetProjection(grid.wkt)
        b = ds.GetRasterBand(1)
        b.SetNoDataValue(nodata)
        b.WriteArray(np.asarray(arr))
        if description:
            b.SetDescription(description)
    finally:
        ds = None
    return path


def read_stack(path):
    """Devuelve (array (n,h,w) float32 con NaN, nombres, Grid)."""
    ds = gdal.Open(path)
    try:
        arrs, names = [], []
        for i in range(1, ds.RasterCount + 1):
            arrs.append(read_band(path, i))
            names.append(ds.GetRasterBand(i).GetDescription() or 'Banda_%d' % i)
        grid = Grid(ds.RasterXSize, ds.RasterYSize, ds.GetGeoTransform(), ds.GetProjection())
        return np.stack(arrs, axis=0), names, grid
    finally:
        ds = None


# ---------------------------------------------------------------------------
# Métrica
# ---------------------------------------------------------------------------

def pixel_size_m(grid):
    """Tamaño de píxel (dx, dy) en metros; en CRS geográfico usa la latitud central."""
    dx, dy = grid.res
    if grid.is_geographic():
        _, ymin, _, ymax = grid.bounds
        lat = math.radians((ymin + ymax) / 2.0)
        return (dx * 111320.0 * math.cos(lat), dy * 110574.0)
    unit = grid.srs().GetLinearUnits() or 1.0
    return (dx * unit, dy * unit)


def pixel_area_rows_m2(grid):
    """Área (m²) de un píxel para cada fila (varía con la latitud en CRS geográfico)."""
    dx, dy = grid.res
    if grid.is_geographic():
        y0, gdy = grid.gt[3], grid.gt[5]
        lats = np.radians(y0 + gdy * (np.arange(grid.height) + 0.5))
        return (dx * 111320.0 * np.cos(lats)) * (dy * 110574.0)
    unit = grid.srs().GetLinearUnits() or 1.0
    return np.full(grid.height, dx * dy * unit * unit)
