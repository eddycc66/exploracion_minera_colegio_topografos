# -*- coding: utf-8 -*-
"""
Descarga opcional de ASTER L1T desde Google Earth Engine (requiere earthengine-api
y una cuenta autenticada fuera de QGIS con `earthengine authenticate`).

Cambios frente a v1:
  * No llama a ee.Authenticate() dentro de QGIS (bloqueaba la interfaz esperando
    una entrada de consola). Solo ee.Initialize(project=...).
  * Descarga UNA escena (la de menor nubosidad) en lugar de la mediana de escenas
    con ganancias distintas: la mediana de DN con ganancias diferentes no tiene
    sentido radiométrico.
  * No calcula índices en la nube: solo bandas crudas B1-B14; los índices se
    calculan localmente con las fórmulas corregidas.
  * Exige fechas anteriores al fallo SWIR (abril 2008) para las bandas B4-B9.
"""
import os
import io
import zipfile

try:
    import ee
    EE_AVAILABLE = True
except Exception:
    ee = None
    EE_AVAILABLE = False

GEE_BANDS = ['B01', 'B02', 'B3N', 'B04', 'B05', 'B06', 'B07', 'B08', 'B09',
             'B10', 'B11', 'B12', 'B13', 'B14']
OUT_BANDS = ['B1', 'B2', 'B3', 'B4', 'B5', 'B6', 'B7', 'B8', 'B9',
             'B10', 'B11', 'B12', 'B13', 'B14']


def initialize(project=None):
    if not EE_AVAILABLE:
        raise RuntimeError("earthengine-api no está instalado en el Python de QGIS.")
    try:
        if project:
            ee.Initialize(project=project)
        else:
            ee.Initialize()
    except Exception as e:
        raise RuntimeError("No se pudo inicializar Earth Engine (%s). Ejecute "
                           "'earthengine authenticate' en OSGeo4W Shell y reintente." % e)


def download_aster(bbox_wgs84, out_dir, date_start='2000-03-01', date_end='2008-03-31',
                   max_cloud=10, scale=30, progress=None):
    """bbox_wgs84 = (xmin, ymin, xmax, ymax). Devuelve (ruta_tif, metadatos)."""
    import requests
    region = ee.Geometry.Rectangle(list(bbox_wgs84))
    col = (ee.ImageCollection('ASTER/AST_L1T_003').filterBounds(region)
           .filterDate(date_start, date_end)
           .filter(ee.Filter.lt('CLOUDCOVER', max_cloud))
           .filter(ee.Filter.listContains('ORIGINAL_BANDS_PRESENT', 'B05'))
           .sort('CLOUDCOVER'))
    if col.size().getInfo() == 0:
        raise RuntimeError("No hay escenas ASTER con SWIR para ese AOI/fechas/nubosidad.")
    img = ee.Image(col.first())
    meta = img.toDictionary(['system:index', 'CLOUDCOVER', 'SOLAR_ELEVATION',
                             'system:time_start']).getInfo()
    if progress:
        progress(30, "Escena %s (nubes %.0f %%)" % (meta.get('system:index'),
                                                      meta.get('CLOUDCOVER', 0)))
    img = img.select(GEE_BANDS, OUT_BANDS).toFloat().clip(region)
    url = img.getDownloadURL({'scale': scale, 'region': region, 'format': 'GEO_TIFF',
                              'filePerBand': False})
    r = requests.get(url, timeout=600)
    r.raise_for_status()
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, 'ASTER_%s.tif' % meta.get('system:index', 'GEE'))
    data = r.content
    if data[:4] == b'PK\x03\x04':
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            name = [n for n in z.namelist() if n.lower().endswith('.tif')][0]
            data = z.read(name)
    elif not (data[:4] in (b'II*\x00', b'MM\x00*')):
        raise RuntimeError("Respuesta de GEE no válida: %s" % data[:200])
    with open(path, 'wb') as fh:
        fh.write(data)
    if progress:
        progress(100, "Descargado %s" % os.path.basename(path))
    return path, meta
