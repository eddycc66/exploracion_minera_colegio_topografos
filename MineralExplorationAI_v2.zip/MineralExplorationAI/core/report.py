# -*- coding: utf-8 -*-
"""
Reporte técnico en HTML. La UI lo convierte a PDF con QTextDocument + QPrinter,
por lo que ya no depende de ReportLab (v1 fallaba con NameError al importar el
módulo si ReportLab no estaba instalado, porque la clase usaba `colors` en su
cuerpo).

Las imágenes se referencian como <img src="res://clave"> y se entregan aparte
en `images` para registrarlas como recursos del documento; export_html() las
incrusta en base64 para un HTML autónomo.
"""
import base64
import datetime
import html
import os

from .indices import INDEX_BY_KEY

SECTIONS = [
    ('cover', 'Portada'), ('summary', 'Resumen ejecutivo'),
    ('method', 'Datos e índices'), ('maps', 'Mapas'), ('kmeans', 'K-Means'),
    ('favor', 'Favorabilidad'), ('targets', 'Targets'),
    ('validation', 'Validación'), ('recs', 'Recomendaciones'),
    ('limits', 'Limitaciones'),
]

_CSS = """
body { font-family: 'Segoe UI', Arial, sans-serif; font-size: 10pt; color: #1e2229; }
h1 { font-size: 22pt; color: #1e2229; margin-bottom: 2px; }
h2 { font-size: 13pt; color: #1e2229; border-bottom: 2px solid #f39c12;
     padding-bottom: 2px; margin-top: 18px; }
.sub { color: #5c6370; font-size: 11pt; }
table { border-collapse: collapse; width: 100%; }
th { background: #252a33; color: #ffffff; padding: 4px; font-size: 9pt; text-align: left; }
td { border-bottom: 1px solid #d0d4da; padding: 3px 4px; font-size: 9pt; }
.kpi { font-size: 16pt; font-weight: bold; color: #1e2229; }
.p1 { background: #e74c3c; color: #fff; } .p2 { background: #f39c12; color: #fff; }
.p3 { background: #00b894; color: #fff; }
.note { color: #5c6370; font-size: 8.5pt; }
"""


def _e(s):
    return html.escape(str(s))


def _table(headers, rows, classes=None):
    h = ''.join('<th>%s</th>' % _e(x) for x in headers)
    body = []
    for i, r in enumerate(rows):
        cls = (classes or {}).get(i, {})
        body.append('<tr>' + ''.join(
            '<td class="%s">%s</td>' % (cls.get(j, ''), _e(c)) for j, c in enumerate(r)) + '</tr>')
    # QTextDocument ignora width:100% en CSS: se usa el atributo HTML
    return '<table width="100%%" cellspacing="0" cellpadding="3"><tr>%s</tr>%s</table>' % (h, ''.join(body))


def build_report(ctx, sections=None, template='complete'):
    """
    ctx: dict con project, analyst, date, indices_used[], weights{}, w_integration{},
         kmeans{}, targets[], metrics{}, rows[], recs[], images{key: path}, notes[]
    Devuelve (html, images{key: path}).
    """
    sections = set(sections or [k for k, _ in SECTIONS])
    if template == 'executive':
        sections &= {'cover', 'summary', 'maps', 'targets', 'validation', 'recs'}
    images = {k: p for k, p in (ctx.get('images') or {}).items() if p and os.path.exists(p)}
    t = ctx.get('targets') or []
    m = ctx.get('metrics')
    parts = ['<html><head><style>%s</style></head><body>' % _CSS]

    if 'cover' in sections:
        parts.append('<h1>GeoMineral AI</h1><div class="sub">Reporte de prospectividad mineral '
                     'con ASTER</div><br>')
        parts.append(_table(['Campo', 'Valor'], [
            ['Proyecto', ctx.get('project', '—')], ['Analista', ctx.get('analyst', '—')],
            ['Fecha', ctx.get('date', datetime.datetime.now().strftime('%d/%m/%Y %H:%M'))],
            ['Imagen', ctx.get('image_name', '—')], ['Modelo', ctx.get('model', '—')],
            ['Umbral / área mínima', '%s / %s ha' % (ctx.get('threshold', '—'),
                                                      ctx.get('min_area', '—'))]]))

    if 'summary' in sections:
        n1 = sum(1 for x in t if x['prio_num'] == 1)
        n2 = sum(1 for x in t if x['prio_num'] == 2)
        txt = ('Se identificaron <b>%d targets</b> (%d de prioridad 1 y %d de prioridad 2) '
               'combinando %d índices espectrales ASTER con evidencia estructural. '
               % (len(t), n1, n2, len(ctx.get('indices_used') or [])))
        if m:
            txt += ('La validación contra %d ocurrencias conocidas da una tasa de éxito del '
                    '%.0f %% con Kappa %.2f.' % (m['n_occ'], m['success_pct'], m['kappa']))
        else:
            txt += 'La validación contra ocurrencias conocidas no se ejecutó.'
        parts.append('<h2>Resumen ejecutivo</h2><p>%s</p>' % txt)

    if 'method' in sections and ctx.get('indices_used'):
        rows = []
        for k in ctx['indices_used']:
            d = INDEX_BY_KEY.get(k)
            if d:
                rows.append([d.name_es, d.formula, d.target, d.reference])
        parts.append('<h2>Datos e índices</h2>')
        parts.append('<p>%s</p>' % _e(ctx.get('data_note', '')))
        parts.append(_table(['Índice', 'Fórmula', 'Objetivo', 'Referencia'], rows))

    if 'maps' in sections:
        maps = [(k, lbl) for k, lbl in (('map_prosp', 'Prospectividad integrada y targets'),
                                        ('map_clusters', 'Clusters K-Means'),
                                        ('hist_prosp', 'Distribución de prospectividad'))
                if k in images]
        if maps:
            parts.append('<h2>Mapas</h2>')
            for k, lbl in maps:
                parts.append('<p><b>%s</b><br><img src="res://%s" width="620"></p>' % (_e(lbl), k))

    if 'kmeans' in sections and ctx.get('kmeans'):
        km = ctx['kmeans']
        parts.append('<h2>K-Means</h2><p>%d clusters, backend %s, inicialización %s.</p>'
                     % (km.get('k', 0), _e(km.get('backend', '')), _e(km.get('init', ''))))
        parts.append(_table(['Cluster', 'Píxeles', 'Interpretación', 'Relevancia', 'Índices dominantes'],
                            [['C%d' % c['cluster'], '{:,}'.format(c['n_pixels']), c['label'],
                              c['relevancia'], c['top']] for c in km.get('interp', [])]))

    if 'favor' in sections and ctx.get('weights'):
        parts.append('<h2>Favorabilidad</h2>')
        rows = [[INDEX_BY_KEY[k].name_es if k in INDEX_BY_KEY else k, '%.2f' % w]
                for k, w in ctx['weights'].items() if w > 0]
        parts.append(_table(['Evidencia', 'Peso'], rows))
        wi = ctx.get('w_integration') or {}
        if wi:
            parts.append('<br>' + _table(['Evidencia integrada', 'Peso'],
                                         [[k, '%.2f' % v] for k, v in wi.items()]))

    if 'targets' in sections:
        parts.append('<h2>Targets</h2>')
        if t:
            cls = {i: {1: 'p%d' % x['prio_num']} for i, x in enumerate(t[:60])}
            parts.append(_table(['ID', 'Prioridad', 'Máx', 'Media', 'Área (ha)', 'Lon', 'Lat'],
                                [[x['target_id'], x['prioridad'], '%.3f' % x['score_max'],
                                  '%.3f' % x['score_mean'], '%.2f' % x['area_ha'],
                                  '%.5f' % x['lon'], '%.5f' % x['lat']] for x in t[:60]], cls))
            if len(t) > 60:
                parts.append('<p class="note">Se muestran 60 de %d targets; ver GPKG/CSV.</p>' % len(t))
        else:
            parts.append('<p>No se generaron targets con los parámetros actuales.</p>')

    if 'validation' in sections and m:
        parts.append('<h2>Validación</h2>')
        parts.append(_table(['OA', 'Kappa', 'Precisión', 'Recall (éxito)', 'F1'],
                            [['%.3f' % m['oa'], '%.3f' % m['kappa'], '%.3f' % m['precision'],
                              '%.3f' % m['recall'], '%.3f' % m['f1']]]))
        parts.append('<br>' + _table(['', 'Predicho target', 'Predicho fondo'],
                                     [['Ocurrencia', m['tp'], m['fn']],
                                      ['Fondo (pseudo-negativo)', m['fp'], m['tn']]]))
        parts.append('<p>%s</p>' % _e(ctx.get('validation_text', '')))

    if 'recs' in sections and ctx.get('recs'):
        parts.append('<h2>Recomendaciones</h2>')
        for r in ctx['recs'][:25]:
            parts.append('<p><b>%s — %s</b> (máx %.3f, %.1f ha, %.5f / %.5f). Confianza: %s<br>%s</p>'
                         % (_e(r['target_id']), _e(r['prioridad']), r['score_max'], r['area_ha'],
                            r['lon'], r['lat'], _e(r['confianza']),
                            '<br>'.join('%d. %s' % (i + 1, _e(f)) for i, f in enumerate(r['fases']))))

    if 'limits' in sections:
        notes = ctx.get('notes') or []
        notes = notes + [
            'Los índices por cociente son semicuantitativos; confirmar con espectrometría de campo (ASD/TerraSpec) y DRX.',
            'Se recomienda ASTER AST_07XT (reflectancia con corrección de crosstalk) para índices SWIR.',
            'Los pesos del modelo son de criterio experto y deben calibrarse con ocurrencias locales.',
        ]
        parts.append('<h2>Limitaciones</h2><ul>%s</ul>' % ''.join('<li>%s</li>' % _e(n) for n in notes))

    parts.append('<p class="note">GeoMineral AI v2.0 — Spatial Mind S.R.L. — documento técnico confidencial.</p>')
    parts.append('</body></html>')
    return ''.join(parts), images


def export_html(html_text, images, path):
    """HTML autónomo con imágenes incrustadas en base64."""
    for k, p in images.items():
        with open(p, 'rb') as fh:
            b64 = base64.b64encode(fh.read()).decode('ascii')
        html_text = html_text.replace('res://%s' % k, 'data:image/png;base64,' + b64)
    with open(path, 'w', encoding='utf-8') as fh:
        fh.write(html_text)
    return path


def export_csv(targets, path):
    import csv
    keys = ['target_id', 'prioridad', 'prio_num', 'score_max', 'score_mean', 'area_ha',
            'perim_m', 'n_pix', 'x', 'y', 'lon', 'lat']
    with open(path, 'w', newline='', encoding='utf-8-sig') as fh:
        w = csv.DictWriter(fh, fieldnames=keys, extrasaction='ignore')
        w.writeheader()
        w.writerows(targets)
    return path
