# -*- coding: utf-8 -*-
"""
Carga de bandas ASTER desde una o varias fuentes raster y alineación a una grilla
común de 30 m.

  * VNIR 15 m  -> 30 m con remuestreo por PROMEDIO (conserva radiometría)
  * SWIR 30 m  -> grilla de referencia (vecino más cercano si ya coincide)
  * TIR  90 m  -> 30 m con remuestreo BILINEAL antes de combinar
  * NoData: valor declarado + DN = 0 (relleno de escena) + NaN/Inf
  * Calibración opcional: DN -> radiancia (UCC) -> reflectancia TOA (VNIR/SWIR)
"""
import math
import re
import datetime

import numpy as np

from .constants import (ASTER_BANDS, BAND_ORDER, VNIR, SWIR, TIR, UCC, ESUN,
                        UNITS_DN, UNITS_RADIANCE, UNITS_REFLECTANCE)
from . import raster_io as rio

SWIR_FAILURE_DATE = datetime.date(2008, 4, 1)

# ---------------------------------------------------------------------------
# Autodetección
# ---------------------------------------------------------------------------

_DESC_RE = re.compile(
    r'(?i)(?:^|[^a-z0-9])(?:b|band|banda|imagedata)[\s_\-]*0*(\d{1,2})([nb])?(?![0-9])')


def guess_band_from_text(text):
    """'B01', 'ImageData3N', 'Band_13', 'B3N' -> 'B1', 'B3', 'B13'. 'B3B' -> None."""
    if not text:
        return None
    m = _DESC_RE.search(text)
    if not m:
        return None
    num, suffix = int(m.group(1)), (m.group(2) or '').lower()
    if suffix == 'b':           # 3B = backward (estéreo), no es la banda espectral
        return None
    key = 'B%d' % num
    return key if key in ASTER_BANDS else None


def guess_bands(descriptions, layer_name=''):
    """
    Devuelve {'B1': band_index(1-based), ...} para una capa raster.

    1) Por descripción de banda (B01, ImageData4, Band 13...).
    2) Por número de bandas + nombre de capa (VNIR/SWIR/TIR).
    """
    found = {}
    for i, d in enumerate(descriptions, start=1):
        k = guess_band_from_text(d)
        if k and k not in found:
            found[k] = i
    if len(found) >= 2:
        return found

    n = len(descriptions)
    name = (layer_name or '').lower()
    k = guess_band_from_text(layer_name)
    if n == 1 and k:
        return {k: 1}
    if n in (14, 15, 19):                 # stack completo (v1 GEE: 14 bandas + 5 índices)
        return {b: i for i, b in enumerate(BAND_ORDER, start=1)}
    if n == 9:
        return {b: i for i, b in enumerate(BAND_ORDER[:9], start=1)}
    if n == 6 or 'swir' in name:
        return {b: i for i, b in enumerate(SWIR, start=1) if i <= n}
    if n == 5 or 'tir' in name:
        return {b: i for i, b in enumerate(TIR, start=1) if i <= n}
    if n in (3, 4) or 'vnir' in name:
        return {b: i for i, b in enumerate(VNIR, start=1) if i <= n}
    return {}


def merge_detections(per_layer):
    """
    per_layer: lista de (path, layer_name, {'B1': idx,...}).
    Devuelve {'B1': (path, idx), ...} dando prioridad a capas con más bandas.
    """
    out = {}
    for path, _name, mapping in sorted(per_layer, key=lambda t: -len(t[2])):
        for b, idx in mapping.items():
            out.setdefault(b, (path, idx))
    return out


# ---------------------------------------------------------------------------
# Calibración
# ---------------------------------------------------------------------------

def earth_sun_distance(date):
    doy = date.timetuple().tm_yday
    return 1.0 - 0.01672 * math.cos(math.radians(0.9856 * (doy - 4)))


def dn_to_radiance(dn, band, gain='NOR'):
    ucc = UCC[band].get(gain) or UCC[band]['NOR']
    rad = (dn - 1.0) * ucc
    rad[rad <= 0] = np.nan          # DN 0/1 no tienen radiancia útil
    return rad.astype(np.float32)


def radiance_to_reflectance(rad, band, sun_elev_deg, date):
    if band not in ESUN:
        return rad                   # TIR: no aplica
    theta = math.radians(90.0 - float(sun_elev_deg))
    d = earth_sun_distance(date)
    refl = (math.pi * rad * d * d) / (ESUN[band] * math.cos(theta))
    return refl.astype(np.float32)


# ---------------------------------------------------------------------------
# Carga
# ---------------------------------------------------------------------------

def _resample_for(band, src_res, dst_res):
    if src_res is None or dst_res is None:
        return 'bilinear'
    ratio = src_res / dst_res
    if abs(ratio - 1.0) < 1e-3:
        return 'nearest'
    if ratio < 1.0:                  # de más fino a más grueso (VNIR 15 -> 30)
        return 'average'
    return 'bilinear'                # de más grueso a más fino (TIR 90 -> 30)


def choose_reference(sources):
    """Primera banda SWIR disponible; si no hay, VNIR; si no, TIR."""
    for group in (SWIR, VNIR, TIR):
        for b in group:
            if b in sources:
                return b
    raise ValueError("No hay bandas ASTER asignadas.")


def build_grid(sources, aoi_bounds=None, target_res=None):
    """Grilla común: la de la banda de referencia, recortada al AOI, a target_res."""
    ref_band = choose_reference(sources)
    path, _ = sources[ref_band]
    grid = rio.Grid.from_path(path)
    if target_res:
        if abs(grid.res[0] - target_res) > 1e-9 and not grid.is_geographic():
            grid = grid.resampled(float(target_res))
    elif ASTER_BANDS[ref_band]['sub'] == 'VNIR' and not grid.is_geographic():
        # Solo VNIR (15 m): llevar a 30 m para ser coherente con SWIR/TIR
        if grid.res[0] < 25:
            grid = grid.resampled(30.0)
    if aoi_bounds:
        grid = grid.cropped_to(aoi_bounds)
    return grid, ref_band


def load_bands(sources, grid, units=UNITS_DN, gain=None, sun_elev=None,
               acq_date=None, calibrate_to=None, mask_zero=True,
               progress=None, cancel=None):
    """
    sources: {'B1': (path, band_index), ...}
    units: unidades de entrada (dn | radiance | reflectance)
    calibrate_to: None | 'radiance' | 'reflectance'  (solo si units == dn)
    Devuelve (bands{}, log[list de str]).
    """
    gain = gain or {}
    bands, log = {}, []
    keys = [b for b in BAND_ORDER if b in sources]
    for n, b in enumerate(keys):
        if cancel and cancel():
            break
        path, idx = sources[b]
        src_grid = rio.Grid.from_path(path)
        same_crs = (not src_grid.wkt or not grid.wkt or
                    src_grid.srs().IsSame(grid.srs()))
        method = _resample_for(b, src_grid.res[0] if same_crs else None, grid.res[0])
        if progress:
            progress(int(100 * n / max(1, len(keys))),
                     "%s <- %s (banda %d, %s)" % (b, path.split('/')[-1].split('\\')[-1], idx, method))
        extra = [0.0] if (mask_zero and units == UNITS_DN) else None
        arr = rio.warp_band_to_grid(path, idx, grid, method, extra)
        if units == UNITS_DN and calibrate_to in (UNITS_RADIANCE, UNITS_REFLECTANCE):
            arr = dn_to_radiance(arr, b, gain.get(b, 'NOR'))
            if calibrate_to == UNITS_REFLECTANCE and b in ESUN:
                if sun_elev is None or acq_date is None:
                    raise ValueError("La reflectancia TOA requiere elevación solar y fecha.")
                arr = radiance_to_reflectance(arr, b, sun_elev, acq_date)
        bands[b] = arr
        if method != 'nearest':
            log.append("%s remuestreada %s: %.1f -> %.1f (unid. CRS)"
                       % (b, method, src_grid.res[0], grid.res[0]))
    return bands, log


def swir_warning(acq_date):
    if acq_date is not None and acq_date >= SWIR_FAILURE_DATE:
        return ("La escena es posterior a abril de 2008: el detector SWIR de ASTER "
                "(B4–B9) está saturado o degradado y los índices SWIR no son fiables.")
    return None


# ---------------------------------------------------------------------------
# Máscaras
# ---------------------------------------------------------------------------

def build_valid_mask(bands, ndvi_max=None, dark_percentile=None):
    """
    True = píxel utilizable.
      ndvi_max: excluye vegetación con NDVI > ndvi_max (requiere B2, B3)
      dark_percentile: excluye sombras (albedo VNIR bajo el percentil dado)
    Devuelve (mask, info{}).
    """
    shape = next(iter(bands.values())).shape
    mask = np.ones(shape, dtype=bool)
    info = {}
    if ndvi_max is not None and 'B2' in bands and 'B3' in bands:
        with np.errstate(all='ignore'):
            ndvi = (bands['B3'] - bands['B2']) / (bands['B3'] + bands['B2'])
        veg = np.isfinite(ndvi) & (ndvi > ndvi_max)
        mask &= ~veg
        info['vegetacion_pct'] = float(100.0 * veg.sum() / veg.size)
    vnir = [bands[b] for b in VNIR if b in bands]
    if dark_percentile and vnir:
        with np.errstate(all='ignore'):
            alb = np.nanmean(np.stack(vnir), axis=0)
        fin = np.isfinite(alb)
        if fin.any():
            thr = np.percentile(alb[fin], dark_percentile)
            dark = fin & (alb < thr)
            mask &= ~dark
            info['sombra_pct'] = float(100.0 * dark.sum() / dark.size)
    return mask, info
