# -*- coding: utf-8 -*-
"""
Targets de exploración a partir de un raster de prospectividad.

Correcciones frente a v1:
  * Área por píxel exacta según la latitud (v1 asumía el ecuador en CRS geográfico,
    con un error proporcional a 1/cos(lat)).
  * Puntaje del target = estadísticas zonales (máximo y media) sobre TODOS sus
    píxeles; v1 muestreaba solo el centroide, que en polígonos cóncavos puede caer
    fuera del target.
  * Punto representativo con PointOnSurface (siempre dentro del polígono).
  * Conectividad 8 coherente entre etiquetado y poligonización.
  * Coordenadas geográficas con orden de ejes tradicional (lon, lat) en GDAL >= 3.
  * GeoJSON exportado en EPSG:4326 (RFC 7946).
"""
import os

import numpy as np
from scipy import ndimage
from osgeo import gdal, ogr, osr

from . import raster_io as rio

gdal.UseExceptions()
ogr.UseExceptions()

PRIORITY_RULES = (
    # (etiqueta, número, condición sobre (max, mean, area_ha))
    ('PRIORIDAD 1', 1, lambda mx, mn, a: mx >= 0.80 or (mn >= 0.70 and a >= 5.0)),
    ('PRIORIDAD 2', 2, lambda mx, mn, a: mx >= 0.65 or mn >= 0.55),
    ('PRIORIDAD 3', 3, lambda mx, mn, a: True),
)


def _mem_vector_driver():
    """'Memory' (GDAL < 3.11) o 'MEM' (GDAL >= 3.11, QGIS 4)."""
    for name in ('MEM', 'Memory'):
        d = ogr.GetDriverByName(name)
        if d is not None and d.GetMetadataItem('DCAP_VECTOR') == 'YES':
            return d
    return ogr.GetDriverByName('Memory')


def classify(mx, mn, area):
    for label, num, cond in PRIORITY_RULES:
        if cond(mx, mn, area):
            return label, num
    return 'PRIORIDAD 3', 3


def _utm_srs(lon, lat):
    s = osr.SpatialReference()
    zone = int((lon + 180) // 6) + 1
    s.ImportFromEPSG((32600 if lat >= 0 else 32700) + zone)
    s.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)
    return s


def _wgs84():
    s = osr.SpatialReference()
    s.ImportFromEPSG(4326)
    s.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)
    return s


FIELDS = [('target_id', ogr.OFTString), ('prioridad', ogr.OFTString),
          ('prio_num', ogr.OFTInteger), ('score_max', ogr.OFTReal),
          ('score_mean', ogr.OFTReal), ('area_ha', ogr.OFTReal),
          ('perim_m', ogr.OFTReal), ('n_pix', ogr.OFTInteger),
          ('x', ogr.OFTReal), ('y', ogr.OFTReal), ('lon', ogr.OFTReal),
          ('lat', ogr.OFTReal)]


def generate_targets(prosp, grid, out_dir, threshold=0.6, min_area_ha=1.0,
                     basename='Targets', progress=None, cancel=None):
    """
    prosp: array 2D float32 (NaN = NoData) en `grid`.
    Devuelve dict(features=[...], gpkg=..., shp=..., geojson=..., label_path=...).
    """
    os.makedirs(out_dir, exist_ok=True)
    binary = np.isfinite(prosp) & (prosp >= threshold)
    lab, n = ndimage.label(binary, structure=np.ones((3, 3), dtype=int))
    if progress:
        progress(15, "%d regiones sobre el umbral %.2f" % (n, threshold))
    if n == 0:
        return {'features': [], 'gpkg': None, 'shp': None, 'geojson': None}

    # Área por píxel (m²) según fila -> área por región
    row_area = rio.pixel_area_rows_m2(grid)
    area_px = np.broadcast_to(row_area[:, None], prosp.shape)
    flat_lab = lab.ravel()
    area_m2 = np.bincount(flat_lab, weights=area_px.ravel(), minlength=n + 1)
    vals = np.where(binary, prosp, 0).ravel()
    n_pix = np.bincount(flat_lab, minlength=n + 1)
    s_sum = np.bincount(flat_lab, weights=vals, minlength=n + 1)
    s_max = ndimage.maximum(prosp, labels=lab, index=np.arange(n + 1))
    s_max = np.nan_to_num(np.asarray(s_max, dtype=np.float64))

    keep = [i for i in range(1, n + 1) if area_m2[i] / 1e4 >= min_area_ha]
    if progress:
        progress(35, "%d targets con área >= %.2f ha" % (len(keep), min_area_ha))
    if not keep:
        return {'features': [], 'gpkg': None, 'shp': None, 'geojson': None}

    # Orden: mayor puntaje máximo, luego media
    keep.sort(key=lambda i: (-s_max[i], -(s_sum[i] / max(1, n_pix[i]))))
    remap = np.zeros(n + 1, dtype=np.int32)
    for new_id, old in enumerate(keep, start=1):
        remap[old] = new_id
    lab2 = remap[lab]

    # Poligonizar etiquetas (8-conexo) en memoria
    mem = gdal.GetDriverByName('MEM').Create('', grid.width, grid.height, 1, gdal.GDT_Int32)
    mem.SetGeoTransform(grid.gt)
    if grid.wkt:
        mem.SetProjection(grid.wkt)
    mb = mem.GetRasterBand(1)
    mb.WriteArray(lab2)
    mb.SetNoDataValue(0)
    srs = grid.srs()
    vds = _mem_vector_driver().CreateDataSource('poly')
    vl = vds.CreateLayer('poly', srs=srs, geom_type=ogr.wkbPolygon)
    vl.CreateField(ogr.FieldDefn('lbl', ogr.OFTInteger))
    gdal.Polygonize(mb, mb, vl, 0, ['8CONNECTED=8'])
    if progress:
        progress(60, "Poligonizado")

    geoms = {}
    for f in vl:
        k = f.GetField('lbl')
        g = f.GetGeometryRef().Clone()
        geoms.setdefault(k, []).append(g)

    to_wgs = osr.CoordinateTransformation(srs, _wgs84()) if grid.wkt else None
    features = []
    for new_id, old in enumerate(keep, start=1):
        parts = geoms.get(new_id, [])
        if not parts:
            continue
        if len(parts) == 1:
            geom = parts[0]
        else:
            geom = ogr.Geometry(ogr.wkbMultiPolygon)
            for p in parts:
                geom.AddGeometry(p)
            geom = geom.UnionCascaded()
        pt = geom.PointOnSurface()
        x, y = pt.GetX(), pt.GetY()
        lon, lat = x, y
        if to_wgs is not None and not srs.IsGeographic():
            lon, lat = to_wgs.TransformPoint(x, y)[:2]
        # Perímetro en metros
        if srs.IsGeographic():
            gm = geom.Clone()
            gm.Transform(osr.CoordinateTransformation(srs, _utm_srs(lon, lat)))
            perim = gm.Boundary().Length()
        else:
            perim = geom.Boundary().Length() * (srs.GetLinearUnits() or 1.0)
        mn = float(s_sum[old] / max(1, n_pix[old]))
        mx = float(s_max[old])
        area_ha = float(area_m2[old] / 1e4)
        label, num = classify(mx, mn, area_ha)
        features.append({
            'target_id': 'TGT_%03d' % new_id, 'prioridad': label, 'prio_num': num,
            'score_max': round(mx, 4), 'score_mean': round(mn, 4),
            'area_ha': round(area_ha, 3), 'perim_m': round(perim, 1),
            'n_pix': int(n_pix[old]), 'x': x, 'y': y,
            'lon': round(lon, 6), 'lat': round(lat, 6), 'geom': geom,
        })
    if progress:
        progress(80, "Exportando %d targets" % len(features))

    paths = _export(features, srs, out_dir, basename)
    lbl_path = os.path.join(out_dir, basename + '_etiquetas.tif')
    rio.write_int(lbl_path, lab2, grid, nodata=0, gdal_type=gdal.GDT_Int32,
                  description='target_label')
    for f in features:
        f['wkt'] = f.pop('geom').ExportToWkt()
    paths.update({'features': features, 'label_path': lbl_path})
    mem = None
    vds = None
    return paths


def _write_layer(ds, name, srs, features, transform=None):
    lyr = ds.CreateLayer(name, srs=srs, geom_type=ogr.wkbMultiPolygon)
    for fname, ftype in FIELDS:
        fd = ogr.FieldDefn(fname, ftype)
        if ftype == ogr.OFTString:
            fd.SetWidth(20)
        lyr.CreateField(fd)
    for f in features:
        feat = ogr.Feature(lyr.GetLayerDefn())
        for fname, _ in FIELDS:
            feat.SetField(fname, f[fname])
        g = ogr.ForceToMultiPolygon(f['geom'].Clone())
        if transform is not None:
            g.Transform(transform)
        feat.SetGeometry(g)
        lyr.CreateFeature(feat)
    return lyr


def _export(features, srs, out_dir, basename):
    out = {}
    for key, drv, ext in (('gpkg', 'GPKG', '.gpkg'), ('shp', 'ESRI Shapefile', '.shp'),
                          ('geojson', 'GeoJSON', '.geojson')):
        path = os.path.join(out_dir, basename + ext)
        d = ogr.GetDriverByName(drv)
        if os.path.exists(path):
            d.DeleteDataSource(path)
        ds = d.CreateDataSource(path)
        if key == 'geojson' and not srs.IsGeographic():
            _write_layer(ds, basename, _wgs84(), features,
                         osr.CoordinateTransformation(srs, _wgs84()))
        else:
            _write_layer(ds, basename, srs, features)
        ds = None
        out[key] = path
    return out
