# -*- coding: utf-8 -*-
"""Normalización de rasters a [0, 1] conservando NoData (NaN)."""
import numpy as np

METHODS = ('percentile', 'minmax', 'none')


def normalize(arr, method='percentile', p_low=2.0, p_high=98.0):
    """
    percentile: (x - Pl) / (Ph - Pl), recortado a [0, 1]  (robusto a outliers)
    minmax:     (x - min) / (max - min)
    none:       devuelve el array tal cual (float32)
    NaN de entrada se conservan; si el rango es nulo devuelve 0 en píxeles válidos.
    """
    a = np.asarray(arr, dtype=np.float32)
    out = np.full(a.shape, np.nan, dtype=np.float32)
    ok = np.isfinite(a)
    if not ok.any():
        return out
    if method == 'none':
        out[ok] = a[ok]
        return out
    v = a[ok]
    if method == 'minmax':
        lo, hi = float(v.min()), float(v.max())
    else:
        lo, hi = (float(x) for x in np.percentile(v, [p_low, p_high]))
    if not hi > lo:
        out[ok] = 0.0
        return out
    out[ok] = np.clip((v - lo) / (hi - lo), 0.0, 1.0)
    return out


def histogram(arr, bins=64, clip_pct=(0.5, 99.5)):
    """Histograma de píxeles válidos para la vista previa (counts, edges)."""
    v = np.asarray(arr, dtype=np.float32)
    v = v[np.isfinite(v)]
    if v.size == 0:
        return np.zeros(bins), np.linspace(0, 1, bins + 1)
    if v.size > 500000:
        v = np.random.default_rng(0).choice(v, 500000, replace=False)
    lo, hi = np.percentile(v, clip_pct)
    if not hi > lo:
        lo, hi = float(v.min()), float(v.max()) + 1e-6
    return np.histogram(v, bins=bins, range=(lo, hi))
