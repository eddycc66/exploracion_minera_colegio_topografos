# -*- coding: utf-8 -*-
"""
Superposición ponderada (knowledge-driven) para favorabilidad mineral y
prospectividad integrada (Bonham-Carter, 1994).

  F = Σ wᵢ·xᵢ / Σ wᵢ      con xᵢ normalizados a [0, 1]

Cambios frente a v1:
  * NoData ya NO se convierte en 0 (v1 creaba falsos "fondos" y sesgaba la media).
  * Modo estricto (NaN si falta una evidencia) o tolerante (pesos re-normalizados
    por píxel con las evidencias disponibles).
  * Sin doble normalización final: F conserva su escala 0-1 comparable entre
    corridas; el estiramiento es opcional.
  * Todas las evidencias se alinean a la misma grilla con GDAL (v1 usaba
    scipy.zoom, que ignora extensión y CRS).
"""
import numpy as np

from .normalize import normalize

# Pesos por defecto por modelo de depósito (criterio experto; editar en la UI).
# Basados en la zonación de alteración de Corbett & Leach (1998),
# Hedenquist et al. (2000) y Sillitoe (2010).
PRESETS = {
    'epitermal_as': {
        'label': 'Epitermal alta sulfuración (Au-Cu)',
        'weights': {'alunita': 0.25, 'cuarzo': 0.20, 'aaa_rbd5': 0.15,
                    'caolinita': 0.15, 'fe3': 0.15, 'silice': 0.10},
    },
    'epitermal_bs': {
        'label': 'Epitermal baja sulfuración (Au-Ag)',
        'weights': {'cuarzo': 0.25, 'sericita': 0.20, 'silice': 0.15,
                    'fe3': 0.15, 'caolinita': 0.10, 'gossan': 0.10, 'carbonatos': 0.05},
    },
    'porfido': {
        'label': 'Pórfido Cu-Au(-Mo)',
        'weights': {'sericita': 0.25, 'clorita': 0.20, 'fe3': 0.15, 'aaa_rbd5': 0.10,
                    'alunita': 0.10, 'caolinita': 0.10, 'gossan': 0.10},
    },
}


def weighted_overlay(layers, strict=True):
    """
    layers: lista de (array_normalizado_0_1, peso)
    strict=True  -> NaN donde falte cualquier evidencia
    strict=False -> Σwx/Σw sobre las evidencias disponibles en cada píxel
    """
    layers = [(np.asarray(a, dtype=np.float32), float(w)) for a, w in layers if w > 0]
    if not layers:
        raise ValueError("No hay evidencias con peso > 0.")
    shape = layers[0][0].shape
    num = np.zeros(shape, dtype=np.float64)
    den = np.zeros(shape, dtype=np.float64)
    missing = np.zeros(shape, dtype=bool)
    for a, w in layers:
        ok = np.isfinite(a)
        num[ok] += w * a[ok]
        den[ok] += w
        missing |= ~ok
    with np.errstate(all='ignore'):
        f = (num / den).astype(np.float32)
    f[den == 0] = np.nan
    if strict:
        f[missing] = np.nan
    return f


def stretch(f, method='percentile'):
    return normalize(f, method, 2, 98)


def stats(f):
    v = f[np.isfinite(f)]
    if v.size == 0:
        return {'n': 0, 'mean': 0, 'max': 0, 'p90': 0, 'high_pct': 0, 'mid_pct': 0}
    return {
        'n': int(v.size),
        'mean': float(v.mean()),
        'max': float(v.max()),
        'p90': float(np.percentile(v, 90)),
        'high_pct': float(100.0 * (v > 0.70).sum() / v.size),
        'mid_pct': float(100.0 * ((v > 0.50) & (v <= 0.70)).sum() / v.size),
    }
