# -*- coding: utf-8 -*-
"""
Índices minerales ASTER (VNIR / SWIR / TIR) — versión 2.0 corregida.

Convención: TODOS los índices crecen con la abundancia del mineral objetivo
(la banda de absorción va en el denominador; los hombros en el numerador).

Centros de banda (µm): B1 0.556 · B2 0.661 · B3 0.807 · B4 1.656 · B5 2.167
B6 2.209 · B7 2.262 · B8 2.336 · B9 2.400 · B10 8.29 · B11 8.63 · B12 9.08
B13 10.66 · B14 11.32

Referencias principales
  [N03]  Ninomiya, Y. (2003). A stabilized vegetation index and several mineralogic
         indices defined for ASTER VNIR and SWIR data. IGARSS 2003, 3, 1552-1554.
  [N03t] Ninomiya, Y. (2003). Rock type mapping with indices defined for multispectral
         thermal infrared ASTER data: case studies. Proc. SPIE 4886, 123-132.
  [N05]  Ninomiya, Y., Fu, B. & Cudahy, T. (2005). Detecting lithology with ASTER
         multispectral TIR data. Remote Sens. Environ. 99, 127-139.
  [RM03] Rowan, L.C. & Mars, J.C. (2003). Lithologic mapping in the Mountain Pass,
         California area using ASTER data. Remote Sens. Environ. 84, 350-366.
  [R03]  Rowan, L.C., Hook, S.J., Abrams, M.J. & Mars, J.C. (2003). Mapping
         hydrothermally altered rocks at Cuprite, Nevada, using ASTER. Econ. Geol. 98.
  [KO04] Kalinowski, A. & Oliver, S. (2004). ASTER Mineral Index Processing Manual.
         Geoscience Australia.
  [S99]  Sabins, F.F. (1999). Remote sensing for mineral exploration. Ore Geol. Rev. 14.
  [CL98] Corbett, G.J. & Leach, T.M. (1998). SW Pacific Rim Gold-Copper Systems. SEG SP 6.
"""
import numpy as np

from .constants import EPS


# ---------------------------------------------------------------------------
# Aritmética segura
# ---------------------------------------------------------------------------

def sdiv(num, den):
    """
    num / den con protección total:
      - NaN si cualquiera es NaN/Inf
      - NaN si |den| < EPS (evita infinitos y signos espurios; no "suaviza" con +eps)
    Devuelve float32.
    """
    num = np.asarray(num, dtype=np.float32)
    den = np.asarray(den, dtype=np.float32)
    out = np.full(np.broadcast(num, den).shape, np.nan, dtype=np.float32)
    ok = np.isfinite(num) & np.isfinite(den) & (np.abs(den) > EPS)
    np.divide(num, den, out=out, where=ok)
    return out


def _f32(a):
    a = np.asarray(a, dtype=np.float32)
    a[~np.isfinite(a)] = np.nan
    return a


# ---------------------------------------------------------------------------
# Definición de índices
# ---------------------------------------------------------------------------

class IndexDef(object):
    def __init__(self, key, name_es, name_en, formula, bands, func, group, target,
                 physics, reference, false_positives, color, legacy=None,
                 default_on=True):
        self.key = key
        self.name_es = name_es
        self.name_en = name_en
        self.formula = formula
        self.bands = bands
        self.func = func
        self.group = group              # 'VNIR' | 'SWIR' | 'TIR'
        self.target = target            # alteración / mineral objetivo
        self.physics = physics
        self.reference = reference
        self.false_positives = false_positives
        self.color = color
        self.legacy = legacy            # fórmula v1 reemplazada (documentación)
        self.default_on = default_on

    def name(self, lang='es'):
        return self.name_en if lang == 'en' else self.name_es

    def available(self, band_keys):
        return all(b in band_keys for b in self.bands)

    def compute(self, b):
        with np.errstate(all='ignore'):
            return _f32(self.func(b))

    def tooltip(self, lang='es'):
        if lang == 'en':
            return ("<b>%s</b><br><code>%s</code><br><i>%s</i>"
                    % (self.name_en, self.formula, self.reference))
        return ("<b>%s</b><br><code>%s</code><br>%s<br><i>Ref.: %s</i>"
                "<br><span style='color:#f39c12'>Falsos positivos: %s</span>"
                % (self.name_es, self.formula, self.physics, self.reference,
                   self.false_positives))


INDICES = [
    # ------------------------------------------------------------- SWIR Al-OH
    IndexDef(
        'alunita', 'Alunita (ALI)', 'Alunite (ALI)',
        '(B7/B5) · (B7/B8)', ['B5', 'B7', 'B8'],
        lambda b: sdiv(b['B7'], b['B5']) * sdiv(b['B7'], b['B8']),
        'SWIR', 'Argílica avanzada (alta sulfuración)',
        'Alunita absorbe Al–OH a 2.165 µm (B5) y tiene rasgo secundario ~2.32 µm (B8); '
        'B7 (2.26 µm) es hombro reflectivo. El factor B7/B8 suprime respuestas '
        'que solo tienen absorción en B5.',
        'Ninomiya (2003) [ALI]', 'caolinita, dickita, pirofilita; jarosita',
        '#e84393', legacy='B7 / B5  (v1: sin supresión de B8)'),

    IndexDef(
        'aaa_rbd5', 'Argílica avanzada (RBD5)', 'Advanced argillic (RBD5)',
        '(B4 + B6) / (2·B5)', ['B4', 'B5', 'B6'],
        lambda b: sdiv(b['B4'] + b['B6'], 2.0 * b['B5']),
        'SWIR', 'Alunita + caolinita + pirofilita (profundidad de banda a 2.17 µm)',
        'Profundidad relativa de la absorción Al–OH a 2.17 µm (B5) respecto a los '
        'hombros B4 y B6. Integra todo el ensamble argílico avanzado.',
        'Rowan et al. (2003); Rowan & Mars (2003)', 'caolinita supergénica, montmorillonita',
        '#fd79a8', default_on=True),

    IndexDef(
        'caolinita', 'Caolinita (KLI)', 'Kaolinite (KLI)',
        '(B4/B5) · (B8/B6)', ['B4', 'B5', 'B6', 'B8'],
        lambda b: sdiv(b['B4'], b['B5']) * sdiv(b['B8'], b['B6']),
        'SWIR', 'Argílica / argílica avanzada',
        'Doblete Al–OH de caolinita (2.165 y 2.205 µm): absorbe en B5 y B6 a la vez; '
        'B4 y B8 actúan como hombros. Un cociente simple B5/B6 o B6/B5 no puede '
        'separarla de sericita.',
        'Ninomiya (2003) [KLI]', 'alunita, dickita, halloysita',
        '#a29bfe', legacy='B6 / B5 (código v1) y B5 / B6 (tabla del encargo): ambos ambiguos'),

    IndexDef(
        'sericita', 'Sericita / Illita (RBD6)', 'Sericite / Illite (RBD6)',
        '(B5 + B7) / (2·B6)', ['B5', 'B6', 'B7'],
        lambda b: sdiv(b['B5'] + b['B7'], 2.0 * b['B6']),
        'SWIR', 'Fílica (sericítica)',
        'Muscovita/illita absorben Al–OH a ~2.20 µm (B6); B5 y B7 son los hombros. '
        'Usar ambos hombros evita que la caolinita (que baja B5) contamine el índice.',
        'Rowan & Mars (2003); Rowan et al. (2003) [RBD6]', 'montmorillonita/esmectita, caolinita mezclada',
        '#fdcb6e', legacy='B5 / B6 (un solo hombro)'),

    IndexDef(
        'ohi', 'Minerales OH (OHI)', 'OH-bearing (OHI)',
        '(B7/B6) · (B4/B6)', ['B4', 'B6', 'B7'],
        lambda b: sdiv(b['B7'], b['B6']) * sdiv(b['B4'], b['B6']),
        'SWIR', 'Halo de alteración con minerales hidroxilados',
        'Resalta absorción centrada en B6 (2.21 µm) respecto a B4 y B7.',
        'Ninomiya (2003) [OHI]', 'arcillas sedimentarias, suelos arcillosos',
        '#ffeaa7', default_on=False),

    # ------------------------------------------------------ SWIR Mg-OH / CO3
    IndexDef(
        'mgoh_co3', 'Mg–OH / Carbonatos (RBD8)', 'Mg–OH / Carbonate (RBD8)',
        '(B7 + B9) / (2·B8)', ['B7', 'B8', 'B9'],
        lambda b: sdiv(b['B7'] + b['B9'], 2.0 * b['B8']),
        'SWIR', 'Propilítica / carbonatos (clorita, epidota, calcita)',
        'Clorita, epidota, calcita y dolomita absorben a ~2.33 µm (B8); sus hombros '
        'inmediatos son B7 y B9.',
        'Rowan & Mars (2003) [RBD8]', 'calizas y mármoles, rocas máficas frescas',
        '#00b894', legacy='(B6 + B9) / (2·B8): B6 no es hombro de B8 (B7 está en medio) '
                          'y la illita absorbe en B6, así que el índice v1 penalizaba illita'),

    IndexDef(
        'clorita', 'Clorita / Epidota (propilítica)', 'Chlorite / Epidote (propylitic)',
        '(B6 + B9) / (B7 + B8)', ['B6', 'B7', 'B8', 'B9'],
        lambda b: sdiv(b['B6'] + b['B9'], b['B7'] + b['B8']),
        'SWIR', 'Propilítica',
        'Clorita absorbe Fe–OH (~2.25 µm, B7) y Mg–OH (~2.33 µm, B8); epidota a 2.34 µm. '
        'B6 y B9 quedan fuera de ambas absorciones.',
        'Rowan & Mars (2003); Kalinowski & Oliver (2004)', 'anfíboles, rocas máficas, calcita',
        '#55efc4', legacy='B4 / B5 (v1): mide la absorción Al–OH de 2.17 µm, es decir '
                          'alunita/caolinita, la zona de alteración opuesta'),

    IndexDef(
        'calcita', 'Calcita (CLI)', 'Calcite (CLI)',
        '(B6/B8) · (B9/B8)', ['B6', 'B8', 'B9'],
        lambda b: sdiv(b['B6'], b['B8']) * sdiv(b['B9'], b['B8']),
        'SWIR', 'Carbonatos',
        'Absorción CO₃ a 2.33–2.34 µm (B8) respecto a B6 y B9.',
        'Ninomiya (2003) [CLI]', 'clorita/epidota',
        '#81ecec', default_on=False),

    # ------------------------------------------------------------------ VNIR
    IndexDef(
        'fe3', 'Óxidos de Fe³⁺', 'Ferric iron (Fe³⁺)',
        'B2 / B1', ['B1', 'B2'],
        lambda b: sdiv(b['B2'], b['B1']),
        'VNIR', 'Gossan / oxidación supergénica (hematita, goethita, jarosita)',
        'Transferencia de carga Fe³⁺–O: fuerte absorción bajo ~0.55 µm (B1); '
        'reflectancia alta en el rojo (B2).',
        'Rowan & Mars (2003); Sabins (1999)', 'suelos rojos, lateritas, capas rojas',
        '#e17055'),

    IndexDef(
        'fe2', 'Hierro ferroso Fe²⁺', 'Ferrous iron (Fe²⁺)',
        '(B5/B3) + (B1/B2)', ['B1', 'B2', 'B3', 'B5'],
        lambda b: sdiv(b['B5'], b['B3']) + sdiv(b['B1'], b['B2']),
        'VNIR', 'Rocas con Fe²⁺ (máficas, clorita, siderita)',
        'Absorción amplia del Fe²⁺ en ~0.9–1.1 µm (baja B3) respecto a SWIR (B5).',
        'Kalinowski & Oliver (2004)', 'vegetación, sombras',
        '#6c5ce7', default_on=False),

    IndexDef(
        'gossan', 'Gossan', 'Gossan',
        'B4 / B2', ['B2', 'B4'],
        lambda b: sdiv(b['B4'], b['B2']),
        'VNIR', 'Gossan / sombreros de hierro',
        'Óxidos de Fe con alta reflectancia en 1.65 µm (B4) respecto al rojo (B2).',
        'Volesky et al. (2003); Kalinowski & Oliver (2004)', 'suelos secos brillantes',
        '#d35400', default_on=False),

    # ------------------------------------------------------------------- TIR
    IndexDef(
        'cuarzo', 'Cuarzo (QI)', 'Quartz (QI)',
        '(B11 · B11) / (B10 · B12)', ['B10', 'B11', 'B12'],
        lambda b: sdiv(b['B11'] * b['B11'], b['B10'] * b['B12']),
        'TIR', 'Silicificación / sílice oquerosa',
        'Doblete Reststrahlen del cuarzo (baja emisividad a ~8.3 µm = B10 y ~9.1 µm = B12); '
        'B11 (8.6 µm) queda entre ambos mínimos. TIR nativo 90 m, remuestreado a 30 m.',
        'Ninomiya (2003); Ninomiya et al. (2005) [QI]', 'arenas cuarzosas, cuarcitas, chert',
        '#dfe6e9', legacy='(B13/B12) + (B13/B14) (v1)'),

    IndexDef(
        'silice', 'Sílice SiO₂', 'Silica SiO₂',
        'B13 / B10', ['B10', 'B13'],
        lambda b: sdiv(b['B13'], b['B10']),
        'TIR', 'Contenido de SiO₂ (silicificación)',
        'La emisividad cae en 8.3 µm (B10) al aumentar SiO₂ y se mantiene alta en '
        '10.6 µm (B13).',
        'Kalinowski & Oliver (2004); Ninomiya (2003)', 'arenas cuarzosas, suelos silíceos',
        '#b2bec3', legacy='(B13/B12) + (B13/B14): B14 está fuera del Reststrahlen del cuarzo '
                          'y B13/B14 es el índice de carbonatos, así que la suma sumaba calizas'),

    IndexDef(
        'carbonatos', 'Carbonatos (CI)', 'Carbonate (CI)',
        'B13 / B14', ['B13', 'B14'],
        lambda b: sdiv(b['B13'], b['B14']),
        'TIR', 'Calcita / dolomita (skarn, reemplazo carbonatado)',
        'Calcita y dolomita tienen un mínimo de emisividad a ~11.3 µm (B14) y '
        'emisividad alta a 10.6 µm (B13).',
        'Ninomiya (2003); Ninomiya et al. (2005) [CI]', 'rocas máficas (bajo), suelos calcáreos',
        '#74b9ff', legacy='(B13 + B11) / (2·B12): B12 es el mínimo del cuarzo, así que '
                          'el índice v1 crecía con la sílice (falso positivo sistemático)'),

    IndexDef(
        'mafico', 'Máfico (MI)', 'Mafic (MI)',
        'B12 · B14³ / B13⁴', ['B12', 'B13', 'B14'],
        lambda b: sdiv(b['B12'] * b['B14'] ** 3, b['B13'] ** 4),
        'TIR', 'Rocas máficas / ultramáficas',
        'Desplazamiento del mínimo de emisividad hacia longitudes de onda mayores en '
        'rocas pobres en SiO₂.',
        'Ninomiya (2003) [MI]', 'carbonatos',
        '#636e72', default_on=False),

    # --------------------------------------------------------------- Máscara
    IndexDef(
        'ndvi', 'NDVI (máscara)', 'NDVI (mask)',
        '(B3 − B2) / (B3 + B2)', ['B2', 'B3'],
        lambda b: sdiv(b['B3'] - b['B2'], b['B3'] + b['B2']),
        'VNIR', 'Vegetación (se usa para enmascarar)',
        'Contraste rojo / infrarrojo cercano de la clorofila.',
        'Rouse et al. (1974)', '—',
        '#27ae60', default_on=False),
]

INDEX_BY_KEY = {i.key: i for i in INDICES}

# Compatibilidad con nombres v1 (proyectos .geominer antiguos)
LEGACY_KEYS = {
    'Alunita': 'alunita', 'Caolinita': 'caolinita', 'Sericita': 'sericita',
    'Silice': 'silice', 'Oxidos': 'fe3', 'OH': 'mgoh_co3', 'Propilitica': 'clorita',
}


def available_indices(band_keys):
    return [i for i in INDICES if i.available(band_keys)]


def compute_indices(bands, keys, valid_mask=None, progress=None, cancel=None):
    """
    Calcula los índices pedidos.

    bands: {'B1': array, ...} float32 alineados a la misma grilla (NaN = NoData)
    keys:  lista de claves del registro
    valid_mask: bool array opcional (False -> NaN: vegetación, sombra, nubes...)
    """
    out = {}
    keys = [k for k in keys if k in INDEX_BY_KEY]
    for n, k in enumerate(keys):
        if cancel and cancel():
            break
        idx = INDEX_BY_KEY[k]
        if not idx.available(bands.keys()):
            continue
        if progress:
            progress(int(100 * n / max(1, len(keys))), idx.name_es)
        arr = idx.compute(bands)
        if valid_mask is not None:
            arr[~valid_mask] = np.nan
        out[k] = arr
    return out


def describe(arr):
    """Estadísticos robustos para la UI y la validación."""
    v = arr[np.isfinite(arr)]
    if v.size == 0:
        return {'n': 0}
    p = np.percentile(v, [2, 5, 50, 95, 98])
    return {'n': int(v.size), 'min': float(v.min()), 'max': float(v.max()),
            'mean': float(v.mean()), 'std': float(v.std()), 'p2': float(p[0]),
            'p5': float(p[1]), 'p50': float(p[2]), 'p95': float(p[3]), 'p98': float(p[4]),
            'nan_pct': float(100.0 * (1 - v.size / float(arr.size)))}
