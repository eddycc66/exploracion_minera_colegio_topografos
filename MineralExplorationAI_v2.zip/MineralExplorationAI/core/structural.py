# -*- coding: utf-8 -*-
"""
Favorabilidad estructural a partir de un DEM.

Corrección respecto a v1: la pendiente y los gradientes se calculan con el
tamaño REAL del píxel en metros (np.gradient(dem, dy_m, dx_m)). En v1 se usaba
el espaciado 1 (píxel), lo que daba pendientes erróneas (x30 en SRTM 30 m y sin
sentido en CRS geográfico).
"""
import numpy as np
from scipy import ndimage

from . import raster_io as rio


def _fill_nan(a):
    """Rellena NaN con el vecino válido más cercano (solo para filtros)."""
    m = ~np.isfinite(a)
    if not m.any():
        return a
    if m.all():
        return np.zeros_like(a)
    idx = ndimage.distance_transform_edt(m, return_distances=False, return_indices=True)
    return a[tuple(idx)]


def slope_deg(dem, grid):
    dx_m, dy_m = rio.pixel_size_m(grid)
    filled = _fill_nan(dem.astype(np.float64))
    gy, gx = np.gradient(filled, dy_m, dx_m)
    s = np.degrees(np.arctan(np.hypot(gx, gy))).astype(np.float32)
    s[~np.isfinite(dem)] = np.nan
    return s


def lineament_density(dem, grid, edge_percentile=85.0, radius_m=500.0):
    """
    1) Derivadas direccionales Sobel en 4 azimuts (0°, 45°, 90°, 135°) sobre el DEM.
    2) Bordes = píxeles por encima del percentil `edge_percentile` de la magnitud máxima.
    3) Densidad = fracción de píxeles-borde en una ventana circular de radio `radius_m`.
    Devuelve (densidad 0-1 float32, bordes uint8).
    """
    valid = np.isfinite(dem)
    d = _fill_nan(dem.astype(np.float64))
    sx = ndimage.sobel(d, axis=1)
    sy = ndimage.sobel(d, axis=0)
    dirs = [np.abs(sx), np.abs(sy), np.abs(sx + sy) / np.sqrt(2), np.abs(sx - sy) / np.sqrt(2)]
    mag = np.max(np.stack(dirs), axis=0)
    thr = np.percentile(mag[valid], edge_percentile) if valid.any() else np.inf
    edges = (mag >= thr) & valid

    dx_m, dy_m = rio.pixel_size_m(grid)
    r_px = max(1, int(round(radius_m / max(1e-6, (dx_m + dy_m) / 2.0))))
    yy, xx = np.mgrid[-r_px:r_px + 1, -r_px:r_px + 1]
    kernel = ((xx * xx + yy * yy) <= r_px * r_px).astype(np.float64)
    num = ndimage.convolve(edges.astype(np.float64), kernel, mode='constant')
    den = ndimage.convolve(valid.astype(np.float64), kernel, mode='constant')
    with np.errstate(all='ignore'):
        dens = np.where(den > 0, num / den, np.nan).astype(np.float32)
    dens[~valid] = np.nan
    return dens, edges.astype(np.uint8)
