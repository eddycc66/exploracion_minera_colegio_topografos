# -*- coding: utf-8 -*-
"""
K-Means sobre un stack (n_bandas, alto, ancho).

- Estandariza cada banda (media 0, desv. 1) sobre píxeles válidos.
- Ajusta sobre una muestra aleatoria (por defecto 200 000 píxeles) y asigna
  todos los píxeles por bloques: escala a escenas ASTER completas sin agotar memoria.
- Usa scikit-learn si está instalado; si no, una implementación NumPy
  (Lloyd + inicialización k-means++), sin dependencias externas.
"""
import numpy as np

try:
    from sklearn.cluster import KMeans as _SKKMeans
    SKLEARN = True
except Exception:          # ImportError o binarios incompatibles
    SKLEARN = False


def _kmeanspp(X, k, rng):
    n = X.shape[0]
    centers = np.empty((k, X.shape[1]), dtype=np.float64)
    centers[0] = X[rng.integers(n)]
    d2 = ((X - centers[0]) ** 2).sum(1)
    for i in range(1, k):
        p = d2 / d2.sum() if d2.sum() > 0 else None
        centers[i] = X[rng.choice(n, p=p)]
        d2 = np.minimum(d2, ((X - centers[i]) ** 2).sum(1))
    return centers


def _assign(X, C):
    # ||x-c||² = ||x||² - 2x·c + ||c||²  (sin crear matrices n×k×d)
    d = (X * X).sum(1)[:, None] - 2.0 * X @ C.T + (C * C).sum(1)[None, :]
    return d.argmin(1), d.min(1)


def _numpy_kmeans(X, k, init, max_iter, seed, n_init=3, tol=1e-4):
    rng = np.random.default_rng(seed)
    best = None
    for _ in range(n_init):
        C = _kmeanspp(X, k, rng) if init == 'k-means++' else \
            X[rng.choice(X.shape[0], k, replace=False)].astype(np.float64)
        for _it in range(max_iter):
            lab, dist = _assign(X, C)
            newC = np.array([X[lab == j].mean(0) if np.any(lab == j) else C[j]
                             for j in range(k)])
            shift = np.abs(newC - C).max()
            C = newC
            if shift < tol:
                break
        lab, dist = _assign(X, C)
        inertia = float(dist.sum())
        if best is None or inertia < best[1]:
            best = (C, inertia)
    return best


def run_kmeans(stack, k=6, init='k-means++', max_iter=300, seed=42,
               sample_size=200000, progress=None, cancel=None):
    """
    Devuelve dict: labels (int16, -1 = NoData), centers (k × n, unidades originales),
    counts, pct, inertia, backend.
    """
    n, h, w = stack.shape
    flat = stack.reshape(n, -1).T.astype(np.float64)
    valid = np.all(np.isfinite(flat), axis=1)
    Xv = flat[valid]
    if Xv.shape[0] < k * 10:
        raise ValueError("Muy pocos píxeles válidos (%d) para %d clusters."
                         % (Xv.shape[0], k))
    mu, sd = Xv.mean(0), Xv.std(0)
    sd[sd == 0] = 1.0
    Z = (Xv - mu) / sd

    rng = np.random.default_rng(seed)
    sample = Z if Z.shape[0] <= sample_size else Z[rng.choice(Z.shape[0], sample_size, replace=False)]
    if progress:
        progress(15, "Ajustando K-Means sobre %d píxeles de muestra" % sample.shape[0])

    if SKLEARN:
        km = _SKKMeans(n_clusters=k, init=init, n_init=4, max_iter=max_iter,
                       random_state=seed).fit(sample)
        C, backend = km.cluster_centers_.astype(np.float64), 'scikit-learn'
    else:
        C, _ = _numpy_kmeans(sample, k, init, max_iter, seed)
        backend = 'numpy'

    # Ordenar clusters por el valor medio del centroide (C1 = más "anómalo")
    order = np.argsort(-C.mean(1))
    C = C[order]

    labels_v = np.empty(Z.shape[0], dtype=np.int16)
    inertia = 0.0
    step = 250000
    for s in range(0, Z.shape[0], step):
        if cancel and cancel():
            raise RuntimeError("Cancelado por el usuario.")
        lab, dist = _assign(Z[s:s + step], C)
        labels_v[s:s + step] = lab
        inertia += float(dist.sum())
        if progress:
            progress(40 + int(55 * min(1.0, (s + step) / Z.shape[0])), "Asignando píxeles")

    labels = np.full(h * w, -1, dtype=np.int16)
    labels[valid] = labels_v
    counts = np.bincount(labels_v, minlength=k)
    centers = C * sd + mu
    return {
        'labels': labels.reshape(h, w),
        'centers': centers.astype(np.float32),
        'counts': counts,
        'pct': 100.0 * counts / max(1, counts.sum()),
        'inertia': inertia,
        'backend': backend,
    }


def palette(k):
    """Colores bien separados (ángulo áureo en HSV) como tuplas RGB 0-255."""
    import colorsys
    cols = []
    for i in range(k):
        h = (i * 0.618033988749895) % 1.0
        r, g, b = colorsys.hsv_to_rgb(h, 0.70, 0.95)
        cols.append((int(r * 255), int(g * 255), int(b * 255)))
    return cols
