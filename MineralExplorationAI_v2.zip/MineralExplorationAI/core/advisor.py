# -*- coding: utf-8 -*-
"""
Interpretación geológica asistida (reglas explícitas, trazables).

Cambios frente a v1:
  * Los clusters se interpretan por la FIRMA de su centroide (qué índices están
    anómalos respecto al resto de clusters), no por su tamaño. En v1 un cluster
    pequeño se etiquetaba "anomalía hidrotermal" y uno grande "nieve o aluvial"
    sin mirar ningún dato espectral.
  * Se eliminó el "presupuesto estimado" (USD/ha fijos sin fundamento).
"""
import numpy as np

# Índice -> (familia de alteración, peso de relevancia para Au)
FAMILY = {
    'alunita': ('Argílica avanzada', 1.0), 'aaa_rbd5': ('Argílica avanzada', 1.0),
    'caolinita': ('Argílica', 0.7), 'sericita': ('Fílica', 0.8),
    'ohi': ('Fílica', 0.5), 'cuarzo': ('Silicificación', 1.0),
    'silice': ('Silicificación', 0.9), 'fe3': ('Óxidos de Fe / gossan', 0.7),
    'gossan': ('Óxidos de Fe / gossan', 0.7), 'fe2': ('Máfico / Fe²⁺', 0.2),
    'clorita': ('Propilítica', 0.4), 'mgoh_co3': ('Propilítica / carbonatos', 0.4),
    'calcita': ('Carbonatos', 0.3), 'carbonatos': ('Carbonatos', 0.3),
    'mafico': ('Máfico', 0.1),
}


def interpret_clusters(centers, names, counts):
    """
    centers: (k, n) valores medios de cada índice (normalizados 0-1) por cluster.
    names:   claves de índice de cada banda del stack.
    Devuelve una lista de dicts ordenada por relevancia.
    """
    C = np.asarray(centers, dtype=np.float64)
    k = C.shape[0]
    mu = C.mean(0)
    sd = C.std(0)
    sd[sd == 0] = 1.0
    Z = (C - mu) / sd
    out = []
    for i in range(k):
        order = np.argsort(-Z[i])
        top = [(names[j], float(Z[i, j]), float(C[i, j])) for j in order[:3]]
        fams, score = [], 0.0
        for key, z, v in top:
            if z > 0.5 and key in FAMILY:
                fam, w = FAMILY[key]
                if fam not in fams:
                    fams.append(fam)
                score += w * z * v
        if not fams:
            label, rel = 'Fondo / litología sin anomalía', 'BAJA'
        else:
            label = ' + '.join(fams)
            rel = 'ALTA' if score >= 1.0 else 'MEDIA' if score >= 0.4 else 'BAJA'
        out.append({'cluster': i + 1, 'n_pixels': int(counts[i]),
                    'label': label, 'relevancia': rel, 'score': round(score, 3),
                    'top': ', '.join('%s (z=%+.1f)' % (n, z) for n, z, _ in top)})
    return out


PHASES = {
    1: ['Mapeo geológico y de alteración 1:5 000 con verificación espectral de campo',
        'Muestreo de roca (chip/canal) multielemento: Au, Ag, Cu, As, Sb, Hg, Te, Mo',
        'Geofísica IP/resistividad y magnetometría terrestre',
        'Definición de blancos de perforación según resultados'],
    2: ['Verificación de campo y muestreo de roca de reconocimiento',
        'Geoquímica de suelos en malla 100 × 50 m',
        'Mapeo estructural de detalle', 'Reevaluar prioridad con resultados'],
    3: ['Revisión en gabinete e imágenes de mayor resolución',
        'Sedimentos de corriente / BLEG regional',
        'Incluir en la cartera de seguimiento', ''],
}


def recommendations(targets, metrics=None):
    conf = 'EN EVALUACIÓN (sin validación)'
    if metrics:
        k = metrics.get('kappa', 0)
        conf = ('ALTA' if k >= 0.6 else 'MEDIA' if k >= 0.4 else 'BAJA') + \
               ' (Kappa %.2f, éxito %.0f %%)' % (k, metrics.get('success_pct', 0))
    recs = []
    for t in sorted(targets, key=lambda t: (t['prio_num'], -t['score_max'])):
        recs.append({'target_id': t['target_id'], 'prioridad': t['prioridad'],
                     'score_max': t['score_max'], 'area_ha': t['area_ha'],
                     'lon': t['lon'], 'lat': t['lat'], 'confianza': conf,
                     'fases': [p for p in PHASES[t['prio_num']] if p]})
    return recs
