# -*- coding: utf-8 -*-
"""GeoMineral AI v2 — MineralExplorationAI (Spatial Mind S.R.L.)."""


def classFactory(iface):  # noqa: N802 (nombre exigido por QGIS)
    from .main import MineralExplorationAI
    return MineralExplorationAI(iface)
