# -*- coding: utf-8 -*-
"""
Crea MineralExplorationAI_v2.zip (instalable con "Instalar a partir de ZIP") a partir
de esta carpeta. Funciona con cualquier Python 3 (no requiere QGIS).

    python crear_zip.py                 # deja el ZIP junto a la carpeta del plugin
    python crear_zip.py --salida RUTA   # otra ubicación
"""
import argparse
import os
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
NAME = os.path.basename(HERE)            # debe ser MineralExplorationAI
EXCLUIR_DIRS = {'__pycache__', '.git', '.idea', '.vscode'}
EXCLUIR_EXT = {'.pyc', '.pyo', '.zip'}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--salida', default=os.path.join(os.path.dirname(HERE), 'MineralExplorationAI_v2.zip'))
    a = ap.parse_args()
    if NAME != 'MineralExplorationAI':
        print('ATENCIÓN: la carpeta se llama "%s"; QGIS espera "MineralExplorationAI". '
              'Se usará MineralExplorationAI como raíz del ZIP.' % NAME)
    n = 0
    with zipfile.ZipFile(a.salida, 'w', zipfile.ZIP_DEFLATED) as z:
        for root, dirs, files in os.walk(HERE):
            dirs[:] = [d for d in dirs if d not in EXCLUIR_DIRS]
            for f in files:
                if os.path.splitext(f)[1].lower() in EXCLUIR_EXT:
                    continue
                full = os.path.join(root, f)
                rel = os.path.relpath(full, HERE)
                z.write(full, os.path.join('MineralExplorationAI', rel))
                n += 1
    print('ZIP creado: %s (%d archivos)' % (a.salida, n))
    print('Instale en QGIS: Complementos → Administrar e instalar complementos → Instalar a partir de ZIP')


if __name__ == '__main__':
    main()
