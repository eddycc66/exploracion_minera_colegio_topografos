# -*- coding: utf-8 -*-
"""
Pruebas del núcleo de GeoMineral AI v2 con datos sintéticos.

Ejecutar (OSGeo4W Shell o terminal con el Python de QGIS):
    python -m tests.test_core            (desde la carpeta del plugin)
o   python tests/test_core.py
"""
import os
import sys
import tempfile

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.dirname(ROOT))
PKG = os.path.basename(ROOT)
core = __import__(PKG + '.core', fromlist=['aster'])
from importlib import import_module
aster = import_module(PKG + '.core.aster')
indices = import_module(PKG + '.core.indices')
rio = import_module(PKG + '.core.raster_io')
normalize = import_module(PKG + '.core.normalize')
kmeans = import_module(PKG + '.core.kmeans')
structural = import_module(PKG + '.core.structural')
prosp = import_module(PKG + '.core.prospectivity')
targets = import_module(PKG + '.core.targets')
validation = import_module(PKG + '.core.validation')
advisor = import_module(PKG + '.core.advisor')
synthetic = import_module(PKG + '.tests.synthetic')

RESULTS = []


def check(name, cond, detail=''):
    RESULTS.append((name, bool(cond), detail))
    print('[%s] %s %s' % ('OK ' if cond else 'FAIL', name, detail))


def zone_mean(arr, z):
    r0, r1, c0, c1 = synthetic.ZONES[z]
    return float(np.nanmean(arr[r0 + 2:r1 - 2, c0 + 2:c1 - 2]))


def bg_mean(arr):
    return float(np.nanmean(arr[70:90, 70:90]))


def main():
    tmp = tempfile.mkdtemp(prefix='gmai_')
    p = synthetic.make_scene(os.path.join(tmp, 'data'))

    # ---------------------------------------------------------------- carga
    per_layer = []
    for key in ('vnir', 'swir', 'tir'):
        per_layer.append((p[key], key, aster.guess_bands(rio.band_descriptions(p[key]), key)))
    sources = aster.merge_detections(per_layer)
    check('autodetección 14 bandas', len(sources) == 14, sorted(sources))
    check('B3N -> B3, B3B ignorada', aster.guess_band_from_text('ImageData3N') == 'B3'
          and aster.guess_band_from_text('B3B') is None)

    grid, ref = aster.build_grid(sources)
    check('grilla de referencia = SWIR 30 m', ref == 'B4' and grid.res == (30.0, 30.0),
          '%s %s' % (ref, grid.res))
    bands, log = aster.load_bands(sources, grid)
    check('TIR 90 m remuestreado a 30 m', bands['B13'].shape == grid.shape,
          str(bands['B13'].shape))
    check('VNIR 15 m promediado a 30 m', bands['B1'].shape == grid.shape)
    check('salida float32', all(a.dtype == np.float32 for a in bands.values()))
    check('DN=0 -> NaN (borde SWIR)', np.isnan(bands['B5'][:, -10:]).all())
    check('DN=0 -> NaN (borde TIR remuestreado)', np.isnan(bands['B13'][:, -12:]).all())
    check('sin mezcla de NoData en interpolación TIR',
          np.nanmin(bands['B13']) > 2000, 'min B13 = %.1f' % np.nanmin(bands['B13']))

    # ---------------------------------------------------------------- índices
    keys = [i.key for i in indices.INDICES]
    res = indices.compute_indices(bands, keys)
    check('todos los índices calculados', len(res) == len(keys), '%d/%d' % (len(res), len(keys)))
    check('sin Inf en ningún índice', all(not np.isinf(a).any() for a in res.values()))
    check('NoData preservado en índices', all(np.isnan(a[:, -10:]).all() for a in res.values()))

    expected = {'alunita': 'alunita', 'aaa_rbd5': 'alunita', 'caolinita': 'caolinita',
                'sericita': 'sericita', 'clorita': 'clorita', 'mgoh_co3': 'clorita',
                'fe3': 'fe3', 'cuarzo': 'cuarzo', 'silice': 'cuarzo',
                'carbonatos': 'carbonato'}
    print('\nMatriz de especificidad (media en zona / media de fondo):')
    zones = [z for z in synthetic.ZONES if z != 'sistema_as']
    print('%-12s' % '' + ''.join('%11s' % z[:10] for z in zones))
    matrix = {}
    for k in expected:
        row = [zone_mean(res[k], z) / bg_mean(res[k]) for z in zones]
        matrix[k] = row
        print('%-12s' % k + ''.join('%11.3f' % v for v in row))
        best = zones[int(np.argmax(row))]
        check('%s máximo en zona %s' % (k, expected[k]), best == expected[k], 'máx en ' + best)

    # Caolinita vs sericita: el KLI debe separarlas (v1 B5/B6 no podía)
    kli_k = zone_mean(res['caolinita'], 'caolinita') / zone_mean(res['caolinita'], 'sericita')
    check('KLI separa caolinita de sericita', kli_k > 1.2, 'ratio %.2f' % kli_k)

    # ------------------------------------------------ fórmulas v1 (regresión)
    b = bands
    legacy_prop = indices.sdiv(b['B4'], b['B5'])
    z = zones[int(np.argmax([zone_mean(legacy_prop, z) for z in zones]))]
    check('v1 "propilítica" B4/B5 detectaba alunita (error confirmado)', z == 'alunita', 'máx en ' + z)
    legacy_carb = indices.sdiv(b['B13'] + b['B11'], 2 * b['B12'])
    z = zones[int(np.argmax([zone_mean(legacy_carb, z) for z in zones]))]
    check('v1 "carbonatos" (B13+B11)/2B12 detectaba cuarzo (error confirmado)', z == 'cuarzo',
          'máx en ' + z)
    legacy_sil = indices.sdiv(b['B13'], b['B12']) + indices.sdiv(b['B13'], b['B14'])
    rc = zone_mean(legacy_sil, 'carbonato') / bg_mean(legacy_sil)
    check('v1 "sílice" respondía a carbonatos (error confirmado)', rc > 1.03, 'x%.3f' % rc)

    # ------------------------------------------- división por cero / extremos
    z0 = indices.sdiv(np.array([1.0, 1.0, np.nan, 5.0], np.float32),
                      np.array([0.0, 1e-9, 1.0, 2.0], np.float32))
    check('sdiv: 0 y ~0 -> NaN, NaN propaga', np.isnan(z0[:3]).all() and z0[3] == 2.5, str(z0))
    ext = res['alunita'][6, 6]
    check('píxel B5≈0 no genera Inf', np.isfinite(ext) or np.isnan(ext), 'valor %.2f' % ext)
    n = normalize.normalize(res['alunita'], 'percentile', 2, 98)
    check('normalización percentil en [0,1] con NaN', np.nanmin(n) >= 0 and np.nanmax(n) <= 1
          and np.isnan(n[:, -10:]).all())

    # --------------------------------------------------------- calibración
    rad = aster.dn_to_radiance(np.array([0, 1, 101], np.float32), 'B5', 'NOR')
    check('DN->radiancia: DN 0/1 -> NaN, (DN-1)*UCC',
          np.isnan(rad[:2]).all() and abs(rad[2] - 6.96) < 1e-4, str(rad))
    import datetime
    check('advertencia SWIR post-2008', aster.swir_warning(datetime.date(2010, 1, 1)) is not None
          and aster.swir_warning(datetime.date(2005, 1, 1)) is None)

    # --------------------------------------------------- stack + K-Means
    sel = ['alunita', 'caolinita', 'sericita', 'clorita', 'fe3', 'cuarzo', 'carbonatos']
    normed = [normalize.normalize(res[k]) for k in sel]
    stack_path = rio.write_stack(os.path.join(tmp, 'stack.tif'), normed, sel, grid)
    st, names, g2 = rio.read_stack(stack_path)
    check('stack multibanda con nombres', names == sel and st.shape[0] == len(sel))
    for backend in ('numpy', 'sklearn'):
        if backend == 'numpy':
            saved = kmeans.SKLEARN
            kmeans.SKLEARN = False
        km = kmeans.run_kmeans(st, k=8, sample_size=30000, seed=1)
        if backend == 'numpy':
            kmeans.SKLEARN = saved
        lab = km['labels']
        check('K-Means (%s): NoData = -1' % km['backend'], (lab[:, -10:] == -1).all())
        interp = advisor.interpret_clusters(km['centers'], sel, km['counts'])
        labels = ' | '.join(sorted(set(i['label'] for i in interp)))
        check('K-Means (%s): detecta argílica avanzada y silicificación' % km['backend'],
              'Argílica avanzada' in labels and 'Silicificación' in labels, labels)

    # ------------------------------------------------ favorabilidad
    w = prosp.PRESETS['epitermal_as']['weights']
    fav = prosp.weighted_overlay([(normalize.normalize(res[k]), v) for k, v in w.items()], strict=True)
    check('favorabilidad en [0,1] y NaN en NoData', np.nanmax(fav) <= 1 and np.isnan(fav[:, -10:]).all())
    check('favorabilidad AS mayor en alunita que en carbonato',
          zone_mean(fav, 'alunita') > zone_mean(fav, 'carbonato'))
    fav_l = prosp.weighted_overlay([(normalize.normalize(res['alunita']), 1),
                                    (np.full(grid.shape, np.nan, np.float32), 1)], strict=False)
    check('modo tolerante re-normaliza pesos', np.nanmax(fav_l) > 0.9)

    # ------------------------------------------------ estructural
    dem = rio.warp_band_to_grid(p['dem'], 1, grid, 'bilinear')
    s = structural.slope_deg(dem, grid)
    # Fondo: 300·sin(x/25) -> pendiente máx. atan(12/30) ≈ 21.8°; la falla (60 m en 30 m)
    # da ≈ 45-49°. Con espaciado de 1 píxel (v1) el fondo daría ≈ 85°.
    check('pendiente usa tamaño de píxel en metros', np.nanpercentile(s, 90) < 25
          and 40 < np.nanmax(s) < 60, 'p90 %.1f°, máx %.1f°' % (np.nanpercentile(s, 90), np.nanmax(s)))
    dens, edges = structural.lineament_density(dem, grid, 85, 300)
    check('densidad de lineamientos en [0,1]', np.nanmin(dens) >= 0 and np.nanmax(dens) <= 1)

    integ = prosp.weighted_overlay([(fav, 0.7), (normalize.normalize(dens), 0.3)])
    ip = os.path.join(tmp, 'prosp.tif')
    rio.write_float(ip, integ, grid)
    back = rio.read_band(ip)
    check('GeoTIFF float32 -9999 -> NaN ida y vuelta', np.allclose(np.nan_to_num(back),
                                                                     np.nan_to_num(integ), atol=1e-6))

    # ------------------------------------------------ targets
    out = targets.generate_targets(integ, grid, os.path.join(tmp, 'targets'), 0.6, 1.0)
    feats = out['features']
    check('targets generados', len(feats) > 0, '%d targets' % len(feats))
    # 50x50 px = 225 ha; el TIR (90 m -> 30 m bilineal) suaviza los bordes y el
    # target efectivo queda algo menor: se acepta 180-240 ha.
    check('target del sistema AS ≈ 225 ha (bordes suavizados por TIR 90 m)',
          any(180 < f['area_ha'] < 240 for f in feats),
          str(sorted(round(f['area_ha'], 1) for f in feats)[-3:]))
    check('GPKG/SHP/GeoJSON escritos', all(out.get(k) and os.path.exists(out[k])
                                            for k in ('gpkg', 'shp', 'geojson')))
    if not feats:
        return 1
    check('lon/lat en rango de La Paz', all(-70 < f['lon'] < -67 and -18 < f['lat'] < -15 for f in feats),
          '%.4f %.4f' % (feats[0]['lon'], feats[0]['lat']))

    # ------------------------------------------------ validación
    rows, m = validation.validate(out['gpkg'], p['occ'], ip, buffer_m=100, neg_ratio=5,
                                  target_label_path=out['label_path'])
    check('ocurrencia dentro de target -> distancia 0', rows[0]['dist_m'] == 0.0, str(rows[0]))
    check('métricas en rango', 0 <= m['oa'] <= 1 and -1 <= m['kappa'] <= 1 and 0 <= m['f1'] <= 1,
          'OA %.2f Kappa %.2f F1 %.2f éxito %.0f%% área %.1f%%'
          % (m['oa'], m['kappa'], m['f1'], m['success_pct'], m['area_pct']))
    print('\n' + validation.interpret(m))

    ok = sum(1 for r in RESULTS if r[1])
    print('\nRESULTADO: %d/%d pruebas OK' % (ok, len(RESULTS)))
    return 0 if ok == len(RESULTS) else 1


if __name__ == '__main__':
    sys.exit(main())
