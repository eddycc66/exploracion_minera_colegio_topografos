# -*- coding: utf-8 -*-
"""
Escena ASTER sintética para pruebas (sin datos reales).

Genera tres GeoTIFF en DN como un producto L1T separado por subsistema:
  VNIR_15m.tif (B1-B3N, 15 m, uint8)   SWIR_30m.tif (B4-B9, 30 m, uint8)
  TIR_90m.tif  (B10-B14, 90 m, uint16) DEM_30m.tif (float32)
y ocurrencias.gpkg (puntos). CRS: UTM 19S (EPSG:32719), región de La Paz.

Zonas (en píxeles SWIR, grilla 240 x 240) con firmas diseñadas según la física
de bandas: cada zona deprime SOLO las bandas de absorción de su mineral.
"""
import os
import numpy as np
from osgeo import gdal, ogr, osr

X0, Y0 = 580000.0, 8180000.0
N30 = 240

# (fila0, fila1, col0, col1) en grilla de 30 m
ZONES = {
    'alunita':   (20, 60, 20, 60),
    'caolinita': (20, 60, 90, 130),
    'sericita':  (20, 60, 160, 200),
    'clorita':   (100, 140, 20, 60),
    'fe3':       (100, 140, 90, 130),
    'cuarzo':    (100, 150, 160, 210),   # TIR: bloques de 90 m
    'carbonato': (170, 220, 160, 210),
    'sistema_as': (170, 220, 20, 70),    # ensamble epitermal AS completo
}

# DN de fondo por banda (reflectancia "gris" ≈ plana)
BG = {'B1': 90, 'B2': 90, 'B3': 90, 'B4': 120, 'B5': 120, 'B6': 120, 'B7': 120,
      'B8': 120, 'B9': 120, 'B10': 3000, 'B11': 3000, 'B12': 3000, 'B13': 3000, 'B14': 3000}

# Factor multiplicativo por banda en cada zona (absorción < 1)
SIG = {
    'alunita':   {'B5': 0.62, 'B8': 0.85},
    'caolinita': {'B5': 0.70, 'B6': 0.72},
    'sericita':  {'B6': 0.65},
    'clorita':   {'B7': 0.80, 'B8': 0.70},
    'fe3':       {'B1': 0.55},
    'cuarzo':    {'B10': 0.80, 'B12': 0.82},
    'carbonato': {'B14': 0.85},
    'sistema_as': {'B5': 0.62 * 0.95, 'B6': 0.95, 'B8': 0.85, 'B1': 0.60,
                   'B10': 0.80, 'B12': 0.82},
}


def _srs():
    s = osr.SpatialReference()
    s.ImportFromEPSG(32719)
    return s


def _write(path, arrays, res, dtype, names, nodata=0):
    h, w = arrays[0].shape
    ds = gdal.GetDriverByName('GTiff').Create(path, w, h, len(arrays), dtype)
    ds.SetGeoTransform((X0, res, 0, Y0, 0, -res))
    ds.SetProjection(_srs().ExportToWkt())
    for i, (a, n) in enumerate(zip(arrays, names), start=1):
        b = ds.GetRasterBand(i)
        b.WriteArray(a)
        b.SetDescription(n)
        if nodata is not None:
            b.SetNoDataValue(nodata)
    ds = None


def make_scene(out_dir, seed=1):
    os.makedirs(out_dir, exist_ok=True)
    rng = np.random.default_rng(seed)
    bands = {}
    for b, v in BG.items():
        bands[b] = np.full((N30, N30), float(v))
    for z, (r0, r1, c0, c1) in ZONES.items():
        for b, f in SIG[z].items():
            bands[b][r0:r1, c0:c1] *= f
    for b in bands:  # ruido 1 %
        bands[b] *= 1 + 0.01 * rng.standard_normal(bands[b].shape)

    # VNIR a 15 m (duplicar) ; TIR a 90 m (promedio 3x3)
    vnir = [np.kron(bands[b], np.ones((2, 2))) for b in ('B1', 'B2', 'B3')]
    swir = [bands[b] for b in ('B4', 'B5', 'B6', 'B7', 'B8', 'B9')]
    tir = [bands[b].reshape(N30 // 3, 3, N30 // 3, 3).mean((1, 3)) for b in
           ('B10', 'B11', 'B12', 'B13', 'B14')]

    # NoData de escena (DN 0) en el borde derecho y un píxel SWIR con DN extremo
    for a in vnir:
        a[:, -20:] = 0
    for a in swir:
        a[:, -10:] = 0
    swir[1][5, 5] = 255      # B5 saturado
    swir[1][6, 6] = 1        # B5 casi cero -> cociente enorme
    for a in tir:
        a[:, -4:] = 0

    p = {}
    p['vnir'] = os.path.join(out_dir, 'AST_VNIR_15m.tif')
    p['swir'] = os.path.join(out_dir, 'AST_SWIR_30m.tif')
    p['tir'] = os.path.join(out_dir, 'AST_TIR_90m.tif')
    _write(p['vnir'], [np.clip(a, 0, 255).astype(np.uint8) for a in vnir], 15.0,
           gdal.GDT_Byte, ['B1', 'B2', 'B3N'])
    _write(p['swir'], [np.clip(a, 0, 255).astype(np.uint8) for a in swir], 30.0,
           gdal.GDT_Byte, ['B4', 'B5', 'B6', 'B7', 'B8', 'B9'])
    _write(p['tir'], [np.clip(a, 0, 65535).astype(np.uint16) for a in tir], 90.0,
           gdal.GDT_UInt16, ['B10', 'B11', 'B12', 'B13', 'B14'])

    # DEM con relieve ondulado, una falla E-W y una falla N-S en el sistema AS
    yy, xx = np.mgrid[0:N30, 0:N30]
    dem = 4200 + 300 * np.sin(xx / 25.0) + 2.0 * yy
    dem[118:122, :] -= 60
    dem[150:, 44:47] -= 45          # falla N-S que controla el sistema AS (realista)
    p['dem'] = os.path.join(out_dir, 'DEM_30m.tif')
    _write(p['dem'], [dem.astype(np.float32)], 30.0, gdal.GDT_Float32, ['DEM'], nodata=-9999)

    # Ocurrencias: 4 dentro de zonas de alteración, 2 en fondo
    pts = [(195, 45), (180, 30), (40, 40), (40, 110), (125, 110), (80, 225 - 30)]
    p['occ'] = os.path.join(out_dir, 'ocurrencias.gpkg')
    drv = ogr.GetDriverByName('GPKG')
    if os.path.exists(p['occ']):
        drv.DeleteDataSource(p['occ'])
    ds = drv.CreateDataSource(p['occ'])
    lyr = ds.CreateLayer('ocurrencias', _srs(), ogr.wkbPoint)
    lyr.CreateField(ogr.FieldDefn('nombre', ogr.OFTString))
    for i, (r, c) in enumerate(pts):
        f = ogr.Feature(lyr.GetLayerDefn())
        f.SetField('nombre', 'Mina_%d' % (i + 1))
        g = ogr.Geometry(ogr.wkbPoint)
        g.AddPoint_2D(X0 + (c + 0.5) * 30, Y0 - (r + 0.5) * 30)
        f.SetGeometry(g)
        lyr.CreateFeature(f)
    ds = None
    return p


if __name__ == '__main__':
    import sys
    print(make_scene(sys.argv[1] if len(sys.argv) > 1 else 'synthetic_data'))
