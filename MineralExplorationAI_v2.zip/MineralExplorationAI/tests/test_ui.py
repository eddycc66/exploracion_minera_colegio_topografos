# -*- coding: utf-8 -*-
"""
Prueba de integración de la interfaz con QGIS (sin pantalla: QT_QPA_PLATFORM=offscreen).

Recorre los 9 pasos sobre la escena sintética y guarda capturas en docs/screenshots.
    QT_QPA_PLATFORM=offscreen python tests/test_ui.py
"""
import os
import sys
import tempfile
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.dirname(ROOT))
PKG = os.path.basename(ROOT)

from qgis.core import QgsApplication, QgsProject, QgsRasterLayer, QgsVectorLayer, QgsSettings
from qgis.gui import QgsMapCanvas

app = QgsApplication([], True)
app.initQgis()

from importlib import import_module
synthetic = import_module(PKG + '.tests.synthetic')
plugin_mod = import_module(PKG)

SHOTS = os.path.join(ROOT, 'docs', 'screenshots')
os.makedirs(SHOTS, exist_ok=True)
FAIL = []


class Iface(object):
    """Sustituto mínimo de QgisInterface para pruebas."""

    def __init__(self):
        self.canvas = QgsMapCanvas()
        self.added = []

    def mainWindow(self):
        return None

    def mapCanvas(self):
        return self.canvas

    def addRasterToolBarIcon(self, a):
        self.added.append(a)

    def addPluginToRasterMenu(self, m, a):
        pass

    def removePluginRasterMenu(self, m, a):
        pass

    def removeRasterToolBarIcon(self, a):
        pass


def wait(dlg, timeout=300):
    t0 = time.time()
    while dlg._worker is not None and time.time() - t0 < timeout:
        app.processEvents()
        time.sleep(0.02)
    for _ in range(20):
        app.processEvents()


def ok(name, cond, detail=''):
    print('[%s] %s %s' % ('OK ' if cond else 'FAIL', name, detail))
    if not cond:
        FAIL.append(name)


def shot(dlg, name):
    for _ in range(5):
        app.processEvents()
    dlg.grab().save(os.path.join(SHOTS, name + '.png'))


def main():
    QgsSettings().remove('GeoMineralAI')
    tmp = tempfile.mkdtemp(prefix='gmai_ui_')
    p = synthetic.make_scene(os.path.join(tmp, 'datos'))
    prj = QgsProject.instance()
    for key in ('vnir', 'swir', 'tir'):
        prj.addMapLayer(QgsRasterLayer(p[key], os.path.basename(p[key])[:-4], 'gdal'))
    dem = prj.addMapLayer(QgsRasterLayer(p['dem'], 'DEM_30m', 'gdal'))
    occ = prj.addMapLayer(QgsVectorLayer(p['occ'], 'Ocurrencias', 'ogr'))

    iface = Iface()
    plugin = plugin_mod.classFactory(iface)
    plugin.initGui()
    ok('plugin: acción registrada', len(iface.added) == 1)
    plugin.run()
    dlg = plugin.dlg
    ok('diálogo creado', dlg is not None)
    dlg.resize(1280, 860)
    dlg.show()

    cfg = dlg.page_by_key['config']
    cfg.ed_out.setText(os.path.join(tmp, 'salidas'))
    cfg.ed_analyst.setText('E. Calle')
    cfg.autodetect()
    ok('autodetección 14 bandas', len(cfg.sources()) == 14, str(len(cfg.sources())))
    cfg.cb_dem.setLayer(dem)
    cfg.cb_occ.setLayer(occ)
    cfg.chk_dark.setChecked(False)          # escena sintética sin sombras reales
    dlg.steps.setCurrentRow(0)
    dlg.run_current()
    wait(dlg)
    ok('paso 1 validado', 'config' in dlg.state['done'])
    shot(dlg, '01_configuracion')

    steps = ['normalize', 'stack', 'kmeans', 'mineral', 'integrated', 'targets', 'validation']
    for i, key in enumerate(steps, start=2):
        dlg.goto(key)
        if key == 'targets':
            dlg.page_by_key['targets'].sp_thr.setValue(0.55)
        dlg.run_current()
        wait(dlg)
        ok('paso %d %s' % (i, key), key in dlg.state['done'],
           dlg.lbl_status.text() if key not in dlg.state['done'] else '')
        shot(dlg, '%02d_%s' % (i, key))

    dlg.goto('reports')
    dlg.run_current()
    for _ in range(10):
        app.processEvents()
    rp = dlg.state.get('report_path', '')
    ok('PDF generado', rp.endswith('.pdf') and os.path.exists(rp) and os.path.getsize(rp) > 20000,
       '%s (%d bytes)' % (os.path.basename(rp), os.path.getsize(rp) if os.path.exists(rp) else 0))
    html = dlg.page_by_key['reports'].generate('html')
    ok('HTML generado', html and os.path.exists(html))
    shot(dlg, '09_reportes')

    t = dlg.state.get('targets') or []
    m = dlg.state.get('metrics') or {}
    print('Targets: %d | OA %.2f Kappa %.2f F1 %.2f' % (len(t), m.get('oa', 0), m.get('kappa', 0), m.get('f1', 0)))

    # Zoom al target (transformación a CRS del lienzo)
    dlg.goto('targets')
    dlg.page_by_key['targets'].zoom(0)
    ok('zoom a target', not iface.canvas.extent().isEmpty())

    # Tema claro y modo compacto
    dlg.goto('mineral')
    dlg.toggle_theme()
    shot(dlg, 'claro_05_mineral')
    dlg.goto('validation')
    shot(dlg, 'claro_08_validation')
    dlg.toggle_theme()
    dlg.btn_compact.setChecked(True)
    dlg.resize(1024, 700)
    dlg.goto('normalize')
    shot(dlg, 'compacto_02_normalize')
    dlg.btn_compact.setChecked(False)

    # Persistencia: cerrar, reabrir y comprobar
    dlg.close()
    plugin.dlg = None
    plugin.run()
    dlg2 = plugin.dlg
    ok('persistencia QgsSettings', dlg2.page_by_key['config'].ed_analyst.text() == 'E. Calle'
       and len(dlg2.page_by_key['config'].sources()) == 14)
    # Idioma EN
    dlg2.cmb_lang.setCurrentIndex(1)
    for _ in range(40):
        app.processEvents()
        time.sleep(0.01)
    ok('reconstrucción en inglés', plugin.dlg is not None and plugin.dlg.btn_run.text() != 'Ejecutar',
       plugin.dlg.btn_run.text() if plugin.dlg else '')
    plugin.dlg.resize(1280, 860)
    plugin.dlg.goto('kmeans')
    shot(plugin.dlg, 'en_04_kmeans')
    plugin.dlg.cmb_lang.setCurrentIndex(0)
    for _ in range(40):
        app.processEvents()
        time.sleep(0.01)
    plugin.unload()
    ok('unload limpio', plugin.dlg is None and plugin.action is None)
    print('\nRESULTADO UI: %s' % ('OK' if not FAIL else 'FALLOS: ' + ', '.join(FAIL)))
    return 1 if FAIL else 0


if __name__ == '__main__':
    code = main()
    app.exitQgis()
    sys.exit(code)
