# -*- coding: utf-8 -*-
"""
Simulación mínima de qgis.core con la API de QGIS 4 (Qt6), solo para pruebas.

Es deliberadamente ESTRICTA: no existen QgsMapLayerType ni QgsMapLayerProxyModel.Filter ni
QgsColorRampShader.Type (eliminados en QGIS 4), y los métodos verifican que reciben el
enum correcto. Los datos raster/vector se leen con GDAL/OGR reales.
"""
import enum
import os
import tempfile
import uuid

from PyQt6.QtCore import QSettings, QSize
from PyQt6.QtGui import QImage, QColor
from osgeo import gdal, ogr, osr


class Qgis(object):
    QGIS_VERSION_INT = 40000
    QGIS_VERSION = '4.0.0-sim'

    class MessageLevel(enum.Enum):
        Info = 0
        Warning = 1
        Critical = 2
        Success = 3
        NoLevel = 4

    class LayerFilter(enum.Flag):
        RasterLayer = 1
        VectorLayer = 2
        PointLayer = 4
        PolygonLayer = 8

    class LayerType(enum.Enum):
        Vector = 0
        Raster = 1

    class ShaderInterpolationMethod(enum.Enum):
        Linear = 0
        Discrete = 1
        Exact = 2

    class VectorFileWriterError(enum.Enum):
        NoError = 0
        ErrDriverNotFound = 1


def _check(value, enum_type, where):
    if not isinstance(value, enum_type):
        raise TypeError('%s espera %s, recibió %r' % (where, enum_type.__name__, value))


class QgsMapLayerProxyModel(object):
    pass            # QGIS 4: sin .Filter ni .RasterLayer


class QgsColorRampShader(object):
    class ColorRampItem(object):
        def __init__(self, value, color, label=''):
            self.value, self.color, self.label = value, color, label

    def __init__(self, vmin=0.0, vmax=1.0):
        self.items = []

    def setColorRampType(self, t):
        _check(t, Qgis.ShaderInterpolationMethod, 'QgsColorRampShader.setColorRampType')

    def setColorRampItemList(self, items):
        self.items = list(items)


class QgsRasterShader(object):
    def setRasterShaderFunction(self, f):
        self.f = f


class _Renderer(object):
    def __init__(self, *a, **k):
        self.args = a


QgsSingleBandPseudoColorRenderer = _Renderer
QgsCategorizedSymbolRenderer = _Renderer


class QgsPalettedRasterRenderer(_Renderer):
    class Class(object):
        def __init__(self, value, color, label=''):
            self.value, self.color, self.label = value, color, label


class QgsRendererCategory(_Renderer):
    pass


class _SymbolLayer(object):
    def setStrokeColor(self, c):
        pass

    def setStrokeWidth(self, w):
        pass


class QgsSymbol(object):
    @staticmethod
    def defaultSymbol(geom_type):
        return QgsSymbol()

    def setColor(self, c):
        pass

    def setOpacity(self, o):
        pass

    def symbolLayer(self, i):
        return _SymbolLayer()


class QgsSettings(object):
    _path = os.path.join(tempfile.gettempdir(), 'gmai_qt6sim_settings.ini')

    def __init__(self):
        self.s = QSettings(self._path, QSettings.Format.IniFormat)

    def value(self, key, default=None, type=None):
        v = self.s.value(key, default)
        if type is bool:
            return v in (True, 'true', 'True', 1, '1')
        if type is not None and v is not None:
            return type(v)
        return v

    def setValue(self, key, value):
        self.s.setValue(key, value)

    def remove(self, key):
        self.s.remove(key)


class QgsMessageLog(object):
    @staticmethod
    def logMessage(msg, tag='', level=None):
        if level is not None:
            _check(level, Qgis.MessageLevel, 'QgsMessageLog.logMessage')


class QgsRectangle(object):
    def __init__(self, *a):
        if len(a) == 1 and isinstance(a[0], QgsRectangle):
            a = (a[0].xmin, a[0].ymin, a[0].xmax, a[0].ymax)
        self.xmin, self.ymin, self.xmax, self.ymax = (a + (0, 0, 0, 0))[:4]

    def xMinimum(self): return self.xmin
    def yMinimum(self): return self.ymin
    def xMaximum(self): return self.xmax
    def yMaximum(self): return self.ymax
    def width(self): return self.xmax - self.xmin
    def height(self): return self.ymax - self.ymin
    def isEmpty(self): return self.width() <= 0 or self.height() <= 0

    def scale(self, f):
        cx, cy = (self.xmin + self.xmax) / 2, (self.ymin + self.ymax) / 2
        w, h = self.width() * f / 2, self.height() * f / 2
        self.xmin, self.xmax, self.ymin, self.ymax = cx - w, cx + w, cy - h, cy + h


class QgsCoordinateReferenceSystem(object):
    def __init__(self, definition=''):
        self.srs = osr.SpatialReference()
        if definition:
            self.srs.SetFromUserInput(definition)

    @staticmethod
    def fromWkt(wkt):
        c = QgsCoordinateReferenceSystem()
        c.srs.ImportFromWkt(wkt)
        return c

    def __eq__(self, o):
        return isinstance(o, QgsCoordinateReferenceSystem) and bool(self.srs.IsSame(o.srs))

    def __ne__(self, o):
        return not self.__eq__(o)


class QgsCoordinateTransform(object):
    def __init__(self, src, dst, ctx=None):
        self.src, self.dst = src, dst

    def transformBoundingBox(self, r):
        return r


class QgsGeometry(object):
    def __init__(self, g=None):
        self.g = g

    @staticmethod
    def fromWkt(wkt):
        return QgsGeometry(ogr.CreateGeometryFromWkt(wkt))

    def transform(self, ct):
        return 0

    def boundingBox(self):
        e = self.g.GetEnvelope()
        return QgsRectangle(e[0], e[2], e[1], e[3])


class _Provider(object):
    def __init__(self, layer):
        self.layer = layer


class QgsMapLayer(object):
    def __init__(self, source, name, provider):
        self._source, self._name, self._provider = source, name, provider
        self._id = '%s_%s' % (name, uuid.uuid4().hex[:8])
        self.renderer = None

    def source(self): return self._source
    def name(self): return self._name
    def id(self): return self._id
    def providerType(self): return self._provider
    def dataProvider(self): return _Provider(self)
    def setRenderer(self, r): self.renderer = r
    def triggerRepaint(self): pass


class QgsRasterLayer(QgsMapLayer):
    def __init__(self, source, name='', provider='gdal'):
        super().__init__(source, name, provider)
        try:
            ds = gdal.Open(source)
            self._n = ds.RasterCount
            self._wkt = ds.GetProjection()
            gt = ds.GetGeoTransform()
            self._ext = QgsRectangle(gt[0], gt[3] + gt[5] * ds.RasterYSize,
                                     gt[0] + gt[1] * ds.RasterXSize, gt[3])
            self._valid = True
        except Exception:
            self._valid = False

    def isValid(self): return self._valid
    def type(self): return Qgis.LayerType.Raster
    def bandCount(self): return self._n
    def crs(self): return QgsCoordinateReferenceSystem.fromWkt(self._wkt)
    def extent(self): return self._ext


class QgsVectorLayer(QgsMapLayer):
    def __init__(self, source, name='', provider='ogr'):
        super().__init__(source, name, provider)
        self._ds = ogr.Open(source.split('|')[0])
        self._valid = self._ds is not None

    def isValid(self): return self._valid
    def type(self): return Qgis.LayerType.Vector
    def featureCount(self): return self._ds.GetLayer(0).GetFeatureCount()
    def geometryType(self): return 2

    def crs(self):
        return QgsCoordinateReferenceSystem.fromWkt(self._ds.GetLayer(0).GetSpatialRef().ExportToWkt())

    def extent(self):
        e = self._ds.GetLayer(0).GetExtent()
        return QgsRectangle(e[0], e[2], e[1], e[3])


class QgsVectorFileWriter(object):
    class SaveVectorOptions(object):
        driverName = 'GPKG'
        fileEncoding = 'UTF-8'

    @staticmethod
    def writeAsVectorFormatV3(layer, path, ctx, opts):
        gdal.VectorTranslate(path, layer.source().split('|')[0], format=opts.driverName)
        return (Qgis.VectorFileWriterError.NoError, '', path, '')


class _Node(object):
    def __init__(self, name=''):
        self.name, self.children = name, []

    def findGroup(self, name):
        return next((c for c in self.children if isinstance(c, _Node) and c.name == name), None)

    def insertGroup(self, i, name):
        g = _Node(name)
        self.children.insert(i, g)
        return g

    def addGroup(self, name):
        g = _Node(name)
        self.children.append(g)
        return g

    def insertLayer(self, i, layer):
        self.children.insert(i, layer)


class QgsProject(object):
    _inst = None

    def __init__(self):
        self.layers, self.root = {}, _Node()

    @classmethod
    def instance(cls):
        if cls._inst is None:
            cls._inst = QgsProject()
        return cls._inst

    def addMapLayer(self, layer, add_to_legend=True):
        self.layers[layer.id()] = layer
        return layer

    def removeMapLayer(self, lid): self.layers.pop(lid, None)
    def mapLayers(self): return dict(self.layers)
    def mapLayer(self, lid): return self.layers.get(lid)
    def baseName(self): return ''
    def layerTreeRoot(self): return self.root
    def transformContext(self): return None


class QgsMapSettings(object):
    def __init__(self):
        self.size = QSize(100, 100)

    def setLayers(self, l): self.layers = l
    def setDestinationCrs(self, c): self.crs = c
    def destinationCrs(self): return getattr(self, 'crs', QgsCoordinateReferenceSystem())
    def setExtent(self, e): self.ext = e
    def setOutputSize(self, s): self.size = s
    def setBackgroundColor(self, c): self.bg = c


class QgsMapRendererSequentialJob(object):
    def __init__(self, ms): self.ms = ms
    def start(self): pass
    def waitForFinished(self): pass

    def renderedImage(self):
        img = QImage(self.ms.size, QImage.Format.Format_ARGB32)
        img.fill(QColor('#dfe6e9'))
        return img


class QgsApplication(object):
    pass
