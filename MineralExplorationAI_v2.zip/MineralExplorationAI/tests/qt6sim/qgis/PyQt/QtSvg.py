from PyQt6.QtSvg import *  # noqa
