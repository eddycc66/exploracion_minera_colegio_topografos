# Simulación mínima de la API de QGIS 4 sobre PyQt6 (solo para pruebas)
