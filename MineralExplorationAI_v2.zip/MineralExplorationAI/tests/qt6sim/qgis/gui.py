# -*- coding: utf-8 -*-
"""Simulación mínima de qgis.gui (QGIS 4 / Qt6) para pruebas."""
from PyQt6.QtCore import pyqtSignal
from PyQt6.QtWidgets import QFrame, QComboBox, QHBoxLayout, QLabel

from .core import Qgis, QgsProject, QgsRectangle, QgsMapSettings, _check


class QgsMessageBar(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.lbl = QLabel()
        QHBoxLayout(self).addWidget(self.lbl)
        self.messages = []

    def pushMessage(self, title, text, level=None, duration=0):
        _check(level, Qgis.MessageLevel, 'QgsMessageBar.pushMessage')
        self.messages.append((title, text, level))
        self.lbl.setText('%s: %s' % (title, text))

    def clearWidgets(self):
        self.lbl.setText('')


class QgsMapLayerComboBox(QComboBox):
    layerChanged = pyqtSignal(object)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._layer, self._filters = None, None

    def setFilters(self, f):
        _check(f, Qgis.LayerFilter, 'QgsMapLayerComboBox.setFilters')
        self._filters = f

    def setAllowEmptyLayer(self, allow, text=None, icon=None):
        pass

    def setLayer(self, layer):
        self._layer = layer
        self.clear()
        self.addItem(layer.name() if layer is not None else '')
        self.layerChanged.emit(layer)

    def currentLayer(self):
        return self._layer


class QgsMapCanvas(object):
    def __init__(self):
        self._ext = QgsRectangle()
        self.ms = QgsMapSettings()

    def extent(self): return self._ext
    def setExtent(self, e): self._ext = e
    def refresh(self): pass
    def mapSettings(self): return self.ms
    def flashGeometries(self, g, crs): pass
