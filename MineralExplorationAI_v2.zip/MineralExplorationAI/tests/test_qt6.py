# -*- coding: utf-8 -*-
"""
Prueba de compatibilidad Qt6 / QGIS 4 SIN QGIS 4 instalado.

Usa PyQt6 real y una simulación estricta de qgis.core / qgis.gui con la API de QGIS 4
(tests/qt6sim): sin QgsMapLayerType, sin QgsMapLayerProxyModel.Filter, enums con alcance
obligatorios y comprobación del tipo de enum en los métodos. Ejecuta los 9 pasos con GDAL
real sobre la escena sintética.

    pip install PyQt6            (en un entorno de pruebas, NO en el Python de QGIS 3)
    QT_QPA_PLATFORM=offscreen python tests/test_qt6.py

Para la validación definitiva, ejecute tests/test_ui.py dentro de QGIS 4.
"""
import os
import sys
import tempfile
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(HERE, 'qt6sim'))      # qgis simulado primero
sys.path.insert(1, os.path.dirname(ROOT))
for m in [m for m in sys.modules if m == 'qgis' or m.startswith('qgis.')]:
    del sys.modules[m]

from PyQt6.QtWidgets import QApplication  # noqa: E402
import qgis  # noqa: E402
assert 'qt6sim' in qgis.__file__, 'No se cargó la simulación de QGIS 4'

app = QApplication(sys.argv)
from importlib import import_module  # noqa: E402
PKG = os.path.basename(ROOT)
from qgis.core import QgsProject, QgsRasterLayer, QgsVectorLayer, QgsSettings, Qgis  # noqa: E402
from qgis.gui import QgsMapCanvas  # noqa: E402
synthetic = import_module(PKG + '.tests.synthetic')
plugin_mod = import_module(PKG)

FAIL = []
SHOTS = os.path.join(ROOT, 'docs', 'screenshots')


def ok(name, cond, detail=''):
    print('[%s] %s %s' % ('OK ' if cond else 'FAIL', name, detail))
    if not cond:
        FAIL.append(name)


class Iface(object):
    def __init__(self):
        self.canvas = QgsMapCanvas()
        self.added = []

    def mainWindow(self): return None
    def mapCanvas(self): return self.canvas
    def addRasterToolBarIcon(self, a): self.added.append(a)
    def addPluginToRasterMenu(self, m, a): pass
    def removePluginRasterMenu(self, m, a): pass
    def removeRasterToolBarIcon(self, a): pass


def wait(dlg, timeout=300):
    t0 = time.time()
    while dlg._worker is not None and time.time() - t0 < timeout:
        app.processEvents()
        time.sleep(0.02)
    for _ in range(20):
        app.processEvents()


def main():
    QgsSettings().remove('GeoMineralAI')
    compat = import_module(PKG + '.compat')
    ok('compat: filtro de capa = Qgis.LayerFilter', isinstance(compat.RASTER, Qgis.LayerFilter))
    ok('compat: tipo de capa = Qgis.LayerType', compat.RASTER_LAYER is Qgis.LayerType.Raster)
    ok('compat: rampa = Qgis.ShaderInterpolationMethod',
       isinstance(compat.ramp_type('Interpolated'), Qgis.ShaderInterpolationMethod))
    ok('compat: QAction desde QtGui (Qt6)', compat.QAction.__module__.startswith('PyQt6.QtGui'))

    tmp = tempfile.mkdtemp(prefix='gmai_qt6_')
    p = synthetic.make_scene(os.path.join(tmp, 'datos'))
    prj = QgsProject.instance()
    for key in ('vnir', 'swir', 'tir'):
        prj.addMapLayer(QgsRasterLayer(p[key], os.path.basename(p[key])[:-4], 'gdal'))
    dem = prj.addMapLayer(QgsRasterLayer(p['dem'], 'DEM_30m', 'gdal'))
    occ = prj.addMapLayer(QgsVectorLayer(p['occ'], 'Ocurrencias', 'ogr'))

    iface = Iface()
    plugin = plugin_mod.classFactory(iface)
    plugin.initGui()
    plugin.run()
    dlg = plugin.dlg
    ok('diálogo creado en Qt6', dlg is not None)
    dlg.resize(1280, 860)
    dlg.show()
    cfg = dlg.page_by_key['config']
    cfg.ed_out.setText(os.path.join(tmp, 'salidas'))
    cfg.autodetect()
    ok('autodetección 14 bandas', len(cfg.sources()) == 14, str(len(cfg.sources())))
    cfg.cb_dem.setLayer(dem)
    cfg.cb_occ.setLayer(occ)
    cfg.chk_dark.setChecked(False)
    for key in ['config', 'normalize', 'stack', 'kmeans', 'mineral', 'integrated', 'targets', 'validation']:
        dlg.goto(key)
        if key == 'targets':
            dlg.page_by_key['targets'].sp_thr.setValue(0.55)
        dlg.run_current()
        wait(dlg)
        ok('Qt6 paso %s' % key, key in dlg.state['done'], dlg.lbl_status.text())
    dlg.goto('reports')
    dlg.run_current()
    rp = dlg.state.get('report_path', '')
    ok('Qt6 PDF (QPrinter/QTextDocument)', rp.endswith('.pdf') and os.path.getsize(rp) > 10000,
       os.path.basename(rp))
    dlg.page_by_key['targets'].zoom(0)
    ok('Qt6 zoom a target', not iface.canvas.extent().isEmpty())
    dlg.toggle_theme()
    dlg.btn_compact.setChecked(True)
    dlg.goto('validation')
    for _ in range(5):
        app.processEvents()
    os.makedirs(SHOTS, exist_ok=True)
    dlg.grab().save(os.path.join(SHOTS, 'qt6_validacion_claro_compacto.png'))
    dlg.toggle_theme()
    dlg.btn_compact.setChecked(False)
    dlg.show_help()
    msgs = dlg.bar.messages
    ok('Qt6 QgsMessageBar con Qgis.MessageLevel', all(isinstance(m[2], Qgis.MessageLevel) for m in msgs),
       '%d mensajes' % len(msgs))
    m = dlg.state.get('metrics') or {}
    print('Qt6 → targets %d | OA %.2f Kappa %.2f' % (len(dlg.state.get('targets') or []),
                                                     m.get('oa', 0), m.get('kappa', 0)))
    plugin.unload()
    ok('Qt6 unload limpio', plugin.dlg is None)
    print('\nRESULTADO Qt6: %s' % ('OK' if not FAIL else 'FALLOS: ' + ', '.join(FAIL)))
    return 1 if FAIL else 0


if __name__ == '__main__':
    sys.exit(main())
