# -*- coding: utf-8 -*-
"""
Internacionalización ES/EN.

- Se instala un QTranslator si existe i18n/GeoMineralAI_<lang>.qm (flujo estándar
  de Qt: pylupdate -> Qt Linguist -> lrelease).
- Además, tr() usa un diccionario interno para que el inglés funcione sin compilar .qm.
"""
import os

from qgis.PyQt.QtCore import QCoreApplication, QTranslator

_LANG = 'es'
_TRANSLATOR = None
CONTEXT = 'GeoMineralAI'

EN = {
    # Estructura
    'Análisis avanzado de prospectividad · ASTER': 'Advanced prospectivity analysis · ASTER',
    'Ayuda': 'Help', 'Anterior': 'Back', 'Siguiente': 'Next', 'Ejecutar': 'Run',
    'Cancelar': 'Cancel', 'Registro': 'Log', 'Listo': 'Ready', 'Proyecto': 'Project',
    'sin guardar': 'unsaved', 'Tema claro': 'Light theme', 'Tema oscuro': 'Dark theme',
    'Modo compacto': 'Compact mode', 'Idioma': 'Language',
    # Pasos
    'Configuración': 'Setup', 'Normalizar': 'Normalize', 'Stack': 'Stack',
    'K-Means': 'K-Means', 'Fav. mineral': 'Mineral fav.', 'Prosp. integrada': 'Integrated prosp.',
    'Targets': 'Targets', 'Validación': 'Validation', 'Reportes': 'Reports',
    'Imagen ASTER, radiometría, área de estudio y capas auxiliares':
        'ASTER image, radiometry, study area and auxiliary layers',
    'Cálculo de índices minerales y normalización a 0–1':
        'Mineral index calculation and 0–1 normalization',
    'Selección y orden de bandas para el análisis multivariado':
        'Band selection and order for multivariate analysis',
    'Clasificación no supervisada del stack de índices':
        'Unsupervised classification of the index stack',
    'Suma ponderada de índices según el modelo de depósito':
        'Weighted sum of indices by deposit model',
    'Integración de evidencia mineral y estructural':
        'Integration of mineral and structural evidence',
    'Zonas de alta prospectividad clasificadas por prioridad':
        'High-prospectivity zones ranked by priority',
    'Contraste de targets con ocurrencias conocidas':
        'Targets checked against known occurrences',
    'Reporte técnico PDF/HTML y exportaciones': 'Technical PDF/HTML report and exports',
    # Acciones
    'Validar configuración': 'Check setup', 'Calcular índices': 'Compute indices',
    'Crear stack': 'Build stack', 'Ejecutar K-Means': 'Run K-Means',
    'Calcular favorabilidad': 'Compute favorability',
    'Calcular prospectividad': 'Compute prospectivity', 'Generar targets': 'Generate targets',
    'Validar targets': 'Validate targets', 'Generar PDF': 'Generate PDF',
    'Autodetectar capas ASTER': 'Auto-detect ASTER layers',
    'Añadir archivo…': 'Add file…', 'Examinar…': 'Browse…',
    'Guardar configuración': 'Save setup', 'Cargar configuración': 'Load setup',
    'Acercar al target': 'Zoom to target', 'Exportar CSV': 'Export CSV',
    'Abrir carpeta': 'Open folder', 'Exportar HTML': 'Export HTML',
    # Tarjetas
    'Proyecto y salida': 'Project and output', 'Nombre del proyecto': 'Project name',
    'Analista': 'Analyst', 'Carpeta de salida': 'Output folder',
    'Bandas ASTER': 'ASTER bands', 'Radiometría': 'Radiometry',
    'Área de estudio y auxiliares': 'Study area and auxiliary data',
    'Máscaras': 'Masks', 'Índices': 'Indices', 'Normalización': 'Normalization',
    'Vista previa del histograma': 'Histogram preview', 'Parámetros': 'Parameters',
    'Distribución de clusters': 'Cluster distribution', 'Resumen': 'Summary',
    'Evidencias': 'Evidence', 'Matriz de confusión': 'Confusion matrix',
    'Secciones del reporte': 'Report sections', 'Plantilla': 'Template',
    'Recomendaciones': 'Recommendations', 'Resultados': 'Results',
}


def set_language(lang, plugin_dir=None):
    global _LANG, _TRANSLATOR
    _LANG = 'en' if str(lang).lower().startswith('en') else 'es'
    app = QCoreApplication.instance()
    if _TRANSLATOR is not None and app is not None:
        app.removeTranslator(_TRANSLATOR)
        _TRANSLATOR = None
    if plugin_dir and _LANG != 'es':
        qm = os.path.join(plugin_dir, 'i18n', 'GeoMineralAI_%s.qm' % _LANG)
        if os.path.exists(qm):
            t = QTranslator()
            if t.load(qm) and app is not None:
                app.installTranslator(t)
                _TRANSLATOR = t


def language():
    return _LANG


def tr(text):
    if _LANG == 'es':
        return text
    translated = QCoreApplication.translate(CONTEXT, text)
    if translated != text:
        return translated
    return EN.get(text, text)
