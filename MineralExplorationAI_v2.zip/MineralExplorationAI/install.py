# -*- coding: utf-8 -*-
"""
Instalador manual de GeoMineral AI (alternativa a "Instalar a partir de ZIP").

Uso (con el Python de QGIS, p.ej. OSGeo4W Shell en Windows):
    python install.py                    # perfil 'default' de QGIS 3
    python install.py --profile otro     # otro perfil
    python install.py --qgis4            # carpeta de perfiles de QGIS 4
    python install.py --dest RUTA        # carpeta de plugins explícita
    python install.py --check            # solo verifica dependencias

Copia la carpeta del plugin a <perfil>/python/plugins/MineralExplorationAI
(reemplaza una versión previa) y verifica dependencias.
"""
import argparse
import os
import platform
import shutil
import sys

PLUGIN = 'MineralExplorationAI'
HERE = os.path.dirname(os.path.abspath(__file__))


def plugins_dir(profile='default', qgis4=False):
    ver = 'QGIS4' if qgis4 else 'QGIS3'
    system = platform.system()
    if system == 'Windows':
        base = os.path.join(os.environ.get('APPDATA', ''), 'QGIS', ver)
    elif system == 'Darwin':
        base = os.path.expanduser('~/Library/Application Support/QGIS/%s' % ver)
    else:
        base = os.path.expanduser('~/.local/share/QGIS/%s' % ver)
    return os.path.join(base, 'profiles', profile, 'python', 'plugins')


def check_deps():
    rows = []
    for mod, required in (('numpy', True), ('scipy', True), ('osgeo.gdal', True),
                          ('sklearn', False), ('ee', False)):
        try:
            __import__(mod)
            rows.append((mod, 'OK'))
        except Exception:
            rows.append((mod, 'FALTA (obligatorio)' if required else 'no instalado (opcional)'))
    for m, s in rows:
        print('  %-12s %s' % (m, s))
    return all(s == 'OK' for m, s in rows[:3])


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--profile', default='default')
    ap.add_argument('--qgis4', action='store_true')
    ap.add_argument('--dest')
    ap.add_argument('--check', action='store_true')
    a = ap.parse_args()
    print('Dependencias (Python %s):' % sys.version.split()[0])
    ok = check_deps()
    if a.check:
        return 0 if ok else 1
    dest_root = a.dest or plugins_dir(a.profile, a.qgis4)
    dest = os.path.join(dest_root, PLUGIN)
    os.makedirs(dest_root, exist_ok=True)
    if os.path.exists(dest):
        print('Eliminando versión previa en', dest)
        shutil.rmtree(dest)
    shutil.copytree(HERE, dest, ignore=shutil.ignore_patterns('__pycache__', '*.pyc', 'screenshots_tmp'))
    print('\nInstalado en:', dest)
    print('Reinicie QGIS y active "GeoMineral AI" en Complementos → Administrar e instalar complementos.')
    if not ok:
        print('\nATENCIÓN: faltan dependencias obligatorias (ver arriba). En OSGeo4W Shell:\n'
              '    python -m pip install numpy scipy')
    return 0


if __name__ == '__main__':
    sys.exit(main())
